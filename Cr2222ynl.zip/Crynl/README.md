# Cryndel Launcher

Minecraft launcher for cryndel.ru. Electron + vanilla ES modules. Offline profiles only. Modrinth API v2, isolated instances, lockfiles, backups, Fix My Instance.

## Stack

- Electron 27
- Node.js 18+
- Modrinth API v2 (`User-Agent: CryndelLauncher/1.0.0`)

## Features

- Offline nick (3-16, UUID v3-style)
- Instances with per-pack RAM / JVM / Quick Play (`--server cryndel.ru`)
- Modrinth search, install with required deps, pin, disable via `.disabled`
- `lock.json` per instance, integrity (SHA-512), update-by-hash
- Import / export `.mrpack`
- Health, crash pattern scan, timeline, snapshots
- Live nick over WebSocket `:21999`
- Discord RPC (optional)
- i18n RU / EN

## Run

```bash
npm install
npm start
```

Devtools:

```bash
npm run dev
```

Tests:

```bash
npm test
```

## Build

```bash
npm run build:windows
npm run build:linux
```

NSIS + portable on Windows, AppImage + deb on Linux.

## Layout

- `electron/` main process, IPC, managers
- `renderer/` UI (hash router)
- `resources/` builds catalog, JVM presets
- `tests/unit/` Jest

User data lives in the Electron userData folder under `cryndel/` (or `~/.cryndel` before app ready).

## License

MIT
