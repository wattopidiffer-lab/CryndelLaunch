export const I = {
  x: '<path d="M7 7l10 10M17 7 7 17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  folder: '<path d="M4 8h6l2 2h8v9H4z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4 8V6h5l1.5 2" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  dl: '<path d="M12 5v10M8 11l4 4 4-4M5 19h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  gear: '<circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6.2 6.2l1.6 1.6M16.2 16.2l1.6 1.6M6.2 17.8l1.6-1.6M16.2 7.8l1.6-1.6" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  pal: '<path d="M12 4a8 8 0 1 0 0 16 3 3 0 0 0 0-6 3 3 0 0 1 0-6 8 8 0 0 0 0-4z" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="8.5" cy="10" r="1" fill="currentColor"/><circle cx="10" cy="7.2" r="1" fill="currentColor"/><circle cx="14.5" cy="7.5" r="1" fill="currentColor"/>',
  plus: '<path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  play: '<path d="M8 6.5v11l9-5.5z" fill="currentColor"/>',
  copy: '<rect x="8" y="8" width="10" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6 16V6h10" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  open: '<path d="M14 5h5v5M19 5l-8 8M10 5H6v14h14v-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  inst: '<rect x="4" y="5" width="7" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="13" y="5" width="7" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="7" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  home: '<path d="M4 11.5 12 4l8 7.5V20H4z" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  // A puzzle piece reads as "mod" instantly and looks sharper in the rail
  // than the old crosshair-in-a-box glyph.
  mods: '<path d="M12 4.2 5.2 8v8L12 19.8 18.8 16V8z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 8.4 9 10.1v3.4l3 1.7 3-1.7v-3.4z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/>',
  scan: '<path d="M12 3.5 5 6.5V12c0 4.6 2.9 7.6 7 8.5 4.1-.9 7-3.9 7-8.5V6.5z" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 12.2l2.4 2.4 4.6-5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  mr: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  shots: '<rect x="4" y="7" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="12" r="1.6" fill="currentColor"/>',
  net: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4 12h16M12 4c3 3 3 13 0 16M12 4c-3 3-3 13 0 16" fill="none" stroke="currentColor" stroke-width="1.5"/>',
  cab: '<path d="M12 4 5 8v8l7 4 7-4V8z" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  ver: '<path d="M6 7h12M6 12h12M6 17h8" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  hp: '<path d="M4 12h4l2-4 4 8 2-4h4" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  chev: '<path d="M8 10l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  tab: '<rect x="4" y="6" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M4 10h16" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  google: '<circle cx="12" cy="12" r="7.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 8.5v7M9 12h7.5" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  install: '<path d="M12 4v10M8 10l4 4 4-4M6 18h12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  page: '<rect x="6" y="4" width="12" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9 8h6M9 12h6M9 16h4" fill="none" stroke="currentColor" stroke-width="1.5"/>',
  full: '<path d="M9 5H5v4M15 5h4v4M5 15v4h4M19 15v4h-4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  nick: '<circle cx="12" cy="9" r="3" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6 19c1.4-3 3.4-4.5 6-4.5S16.6 16 18 19" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  trash: '<path d="M5 7h14M9 7V5h6v2M8 7l1 12h6l1-12" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  edit: '<path d="M5 16.5V19h2.5L18 8.5 15.5 6 5 16.5z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  check: '<path d="M6 12.5l4 4 8-9" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>',
  pin: '<path d="M12 4v10M9 7h6M10 14l-2 6 4-3 4 3-2-6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  pause: '<path d="M9 6v12M15 6v12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
  prev: '<path d="M18 6v12L9 12zM6 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>',
  next: '<path d="M6 6v12l9-6zM18 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>',
  music: '<path d="M9 17V6l9-2v11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><ellipse cx="7" cy="17.5" rx="2.2" ry="1.9" fill="none" stroke="currentColor" stroke-width="1.6"/><ellipse cx="16" cy="15.5" rx="2.2" ry="1.9" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  refresh: '<path d="M5 12a7 7 0 0 1 12-4.5M19 12a7 7 0 0 1-12 4.5M17 4v4h-4M7 20v-4h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  file: '<path d="M7 4h7l4 4v12H7z" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M14 4v4h4" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  export: '<path d="M12 14V5M8 9l4-4 4 4M5 19h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  shield: '<path d="M12 4 5 7v5c0 5 3.2 8 7 9 3.8-1 7-4 7-9V7z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
  on: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 8v8" fill="none" stroke="currentColor" stroke-width="1.8"/>',
  off: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9 9l6 6M15 9l-6 6" fill="none" stroke="currentColor" stroke-width="1.7"/>'
};

export function svg(name, cls = '') {
  const d = I[name] || '';
  return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
}
