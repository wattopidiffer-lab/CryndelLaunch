import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { iconBtn, modal } from '../ui.js';

export async function mountShots(root) {
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: 'СКРИНШОТЫ' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Камера из сборок' }));

  const toolbar = el('div', { class: 'row', style: 'margin-bottom:14px' });
  const filter = el('select', { class: 'field' });
  filter.appendChild(el('option', { value: '', text: 'Все сборки' }));
  for (const i of store.instances) filter.appendChild(el('option', { value: i.id, text: i.name }));
  toolbar.appendChild(filter);
  toolbar.appendChild(iconBtn('dl', 'Обновить', () => load()));
  wrap.appendChild(toolbar);

  const grid = el('div', { class: 'shot-grid' });
  wrap.appendChild(grid);
  root.appendChild(wrap);

  async function load() {
    grid.replaceChildren(el('div', { class: 'hint', text: 'Ищу скриншоты…' }));
    try {
      const all = await api.screenshots.list(200);
      const id = filter.value;
      const items = id ? all.filter((s) => s.instanceId === id) : all;
      grid.replaceChildren();
      if (!items.length) {
        const empty = el('div', { class: 'empty' });
        empty.appendChild(el('h3', { text: 'Пока пусто' }));
        empty.appendChild(el('p', { text: 'F2 в игре — кадр появится здесь. Можно копировать и открывать папку.' }));
        grid.appendChild(empty);
        return;
      }
      for (const s of items) {
        const card = el('div', { class: 'shot-card' });
        const img = el('img', { alt: s.name });
        api.screenshots.dataUrl(s.path).then((url) => { if (url) img.setAttribute('src', url); }).catch(() => {});
        img.addEventListener('click', () => openShot(s, img.src));
        card.appendChild(img);
        card.appendChild(el('div', { class: 'shot-cap', text: (s.instanceName || '') + ' · ' + s.name }));
        const row = el('div', { class: 'row', style: 'padding:8px' });
        row.appendChild(iconBtn('open', 'Открыть', () => api.screenshots.open(s.path)));
        row.appendChild(iconBtn('folder', 'Папка', () => api.screenshots.openFolder(s.path)));
        row.appendChild(iconBtn('copy', 'Копировать фото', async () => {
          try {
            await api.screenshots.copy(s.path);
            toast('Скопировано');
          } catch (e) { toast(e.message || 'Не скопировалось', 'bad'); }
        }));
        card.appendChild(row);
        grid.appendChild(card);
      }
    } catch (e) {
      grid.replaceChildren(el('div', { class: 'card', text: e.message || 'Не удалось прочитать скриншоты' }));
    }
  }

  filter.addEventListener('change', load);
  await load();
}

function openShot(s, src) {
  const m = modal({ kicker: 'КАДР', class: 'shot-lightbox' });
  const img = el('img', { alt: s.name });
  img.src = src;
  m.body.appendChild(img);
  const row = el('div', { class: 'row', style: 'margin-top:10px' });
  row.appendChild(iconBtn('open', 'Открыть', () => api.screenshots.open(s.path)));
  row.appendChild(iconBtn('copy', 'Копировать', () => api.screenshots.copy(s.path)));
  m.body.appendChild(row);
}
