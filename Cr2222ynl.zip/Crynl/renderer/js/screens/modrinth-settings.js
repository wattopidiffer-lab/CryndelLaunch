import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { chk, field } from '../ui.js';
import { go } from '../router.js';

export async function mountMrSettings(root) {
  const s = await api.settings.getAll();
  store.settings = s;
  const mr = s.modrinth || {};
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: 'МОДРИНТ' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Настройки каталога' }));
  wrap.appendChild(el('button', { class: 'btn btn-ghost', text: 'Назад', onclick: () => go('#/modrinth'), style: 'margin-bottom:14px' }));

  const limit = el('input', { class: 'field', type: 'number', min: '8', max: '50', value: String(mr.listLimit || 20) });
  limit.addEventListener('change', async () => {
    await api.settings.set('modrinth.listLimit', Number(limit.value) || 20);
    toast('Сохранено');
  });
  wrap.appendChild(field('Сколько модов в списке', limit));

  wrap.appendChild(chk('Открывать страницу мода на весь экран', mr.fullscreen !== false, async (v) => {
    await api.settings.set('modrinth.fullscreen', v);
  }));
  wrap.appendChild(chk('Только SVG-иконки вместо «Установить» / «Страница»', mr.svgOnly !== false, async (v) => {
    await api.settings.set('modrinth.svgOnly', v);
  }));

  wrap.appendChild(el('h3', { text: 'Дизайн каталога', style: 'margin:18px 0 8px' }));
  const color = el('input', { type: 'color', value: (s.ui && s.ui.accent) || '#7c9cff' });
  color.addEventListener('change', async () => {
    await api.settings.set('ui.accent', color.value);
    document.documentElement.style.setProperty('--accent', color.value);
  });
  wrap.appendChild(field('Цвет текста и акцент', color));

  const radius = el('input', { class: 'field', type: 'range', min: '4', max: '28', value: String((s.ui && s.ui.radius) || 16) });
  radius.addEventListener('input', async () => {
    document.documentElement.style.setProperty('--radius', radius.value + 'px');
    await api.settings.set('ui.radius', Number(radius.value));
  });
  wrap.appendChild(field('Скругление рамок', radius));

  root.appendChild(wrap);
}
