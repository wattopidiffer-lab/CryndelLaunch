import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { chk, field, customSelect, paintSkinFace, drawSkinFront, iconBtn } from '../ui.js';
import { loadLocale } from '../i18n.js';
import { sound, setMusicVolume, playMusic, pauseMusic, nextTrack } from '../sound.js';

// Re-read the user's custom CSS and swap it into the live <style> node so
// changes are visible immediately, without reloading the window.
async function applyCustomCssLive() {
  const node = document.getElementById('userTheme');
  if (!node) return;
  try {
    node.textContent = (await api.theme.read()) || '';
  } catch (_) {
    node.textContent = '';
  }
}

const THEMES = [
  ['dark', 'Тёмный', '#07080c', '#7c9cff'],
  ['light', 'Светлый', '#f3f5fa', '#3b5bfd'],
  ['furry', 'Фурри', '#140918', '#ff9a4a'],
  ['girly', 'Девчачий', '#2a1020', '#ff7ab6'],
  ['professional', 'Профессиональный', '#0a0c10', '#c9a227'],
  ['glass', 'Стеклянный', '#081018', '#8ee7ff']
];

export async function mountSettings(root) {
  const s = await api.settings.getAll();
  store.settings = s;
  const ram = await api.ram.suggest().catch(() => ({ recommendedMb: 4096, totalMb: 0, freeMb: 0 }));
  const wrap = el('div');
  wrap.className = 'settings-pane';
  wrap.appendChild(el('p', { class: 'kicker', text: 'НАСТРОЙКИ' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Лаунчер под себя' }));

  function block(title) {
    wrap.appendChild(el('h3', { text: title, style: 'margin:18px 0 8px' }));
  }

  block('Тема');
  let colorInput = null;
  const grid = el('div', { class: 'theme-grid', style: 'margin-bottom:14px' });
  for (const [id, title, bg, accent] of THEMES) {
    const b = el('button', { class: 'theme-swatch' + (((s.ui && s.ui.theme) || 'dark') === id ? ' on' : ''), onclick: async () => {
      await api.settings.set('ui.theme', id);
      // An inline --accent from the colour picker wins over [data-theme], which
      // made every theme look identical. Clear it so the theme's own palette
      // actually shows; the colour picker can still set one afterwards.
      await api.settings.set('ui.accent', '');
      document.documentElement.style.removeProperty('--accent');
      if (colorInput) colorInput.value = accent;
      document.documentElement.setAttribute('data-theme', id);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.theme = id;
      store.settings.ui.accent = '';
      grid.querySelectorAll('.theme-swatch').forEach((n) => n.classList.remove('on'));
      b.classList.add('on');
      toast('Тема: ' + title);
    } });
    const prev = el('div', { class: 'preview' });
    prev.style.background = 'linear-gradient(90deg, ' + bg + ' 55%, ' + accent + ')';
    b.appendChild(prev);
    b.appendChild(el('strong', { text: title, style: 'display:block' }));
    grid.appendChild(b);
  }
  wrap.appendChild(grid);

  const themeAccent = (THEMES.find(([id]) => id === ((s.ui && s.ui.theme) || 'dark')) || THEMES[0])[3];
  const accent = el('input', { type: 'color', value: (s.ui && s.ui.accent) || themeAccent });
  colorInput = accent;
  accent.addEventListener('change', async () => {
    await api.settings.set('ui.accent', accent.value);
    document.documentElement.style.setProperty('--accent', accent.value);
  });
  wrap.appendChild(field('Цвет интерфейса (перекрывает тему)', accent));

  const radius = el('input', { class: 'field', type: 'range', min: '4', max: '28', value: String((s.ui && s.ui.radius) || 16) });
  radius.addEventListener('input', async () => {
    document.documentElement.style.setProperty('--radius', radius.value + 'px');
    await api.settings.set('ui.radius', Number(radius.value));
  });
  wrap.appendChild(field('Скругление рамок', radius));

  const nav = customSelect([
    { value: 'left', label: 'Слева' },
    { value: 'right', label: 'Справа' },
    { value: 'top', label: 'Сверху' },
    { value: 'bottom', label: 'Снизу' }
  ], (s.ui && s.ui.navPos) || 'left', async (v) => {
    await api.settings.set('ui.navPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.navPos = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Где навигация', nav));

  wrap.appendChild(field('Шрифт главной', customSelect([
    { value: 'default', label: 'Обычный' },
    { value: 'minecraft', label: 'Майнкрафтский' },
    { value: 'title', label: 'Minecraft Title' },
    { value: 'classic', label: 'Классический' }
  ], (s.ui && s.ui.homeFont) || 'default', async (v) => {
    await api.settings.set('ui.homeFont', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.homeFont = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  })));

  const lang = el('select', { class: 'field' });
  lang.appendChild(el('option', { value: 'ru', text: 'Русский' }));
  lang.appendChild(el('option', { value: 'en', text: 'English' }));
  lang.value = (s.ui && s.ui.language) || 'ru';
  lang.addEventListener('change', async () => {
    await api.settings.set('ui.language', lang.value);
    await api.settings.set('game.language', lang.value);
    await loadLocale(lang.value);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.language = lang.value;
    if (window.__cryndelRefresh) await window.__cryndelRefresh();
    toast(lang.value === 'en' ? 'Language saved' : 'Язык сохранён');
  });
  wrap.appendChild(field('Язык лаунчера и Minecraft', lang));

  block('Свой CSS');
  wrap.appendChild(el('p', { class: 'hint', text: 'Здесь можно переопределить любые стили лаунчера. Пиши обычный CSS — он применяется сразу и хранится между запусками.' }));
  const cssArea = el('textarea', {
    class: 'field css-editor',
    spellcheck: 'false',
    style: 'min-height:150px;font-family:var(--mono);font-size:12.5px;line-height:1.5',
    placeholder: ':root { --accent: #7c9cff; }\n.foot { backdrop-filter: blur(24px); }'
  });
  cssArea.value = await api.theme.read().catch(() => '');
  wrap.appendChild(cssArea);
  const cssRow = el('div', { class: 'row', style: 'margin-top:8px' });
  cssRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Применить CSS', onclick: async () => {
    try {
      await api.theme.write(cssArea.value);
      await applyCustomCssLive();
      toast('CSS применён');
    } catch (e) { toast(e.message || 'CSS отклонён', 'bad'); }
  } }));
  cssRow.appendChild(el('button', { class: 'btn', text: 'Из файла…', onclick: async () => {
    const r = await api.theme.import();
    if (r && r.ok) {
      cssArea.value = await api.theme.read().catch(() => '');
      await applyCustomCssLive();
      toast('CSS загружен');
    } else if (r && r.error) {
      toast(r.error, 'bad');
    }
  } }));
  cssRow.appendChild(el('button', { class: 'btn btn-danger', text: 'Очистить', onclick: async () => {
    await api.theme.clear();
    cssArea.value = '';
    await applyCustomCssLive();
    toast('Свой CSS удалён');
  } }));
  wrap.appendChild(cssRow);

  block('Главная и фон');
  wrap.appendChild(chk('Видео-обои зациклить', !s.ui || s.ui.bgLoop !== false, async (v) => {
    await api.settings.set('ui.bgLoop', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Всегда показывать анимацию первого открытия', Boolean(s.ui && s.ui.alwaysSplash), async (v) => {
    await api.settings.set('ui.alwaysSplash', v);
  }));
  wrap.appendChild(chk('Анимации интерфейса', !s.ui || s.ui.animations !== false, async (v) => {
    await api.settings.set('ui.animations', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.animations = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));

  const animDur = el('input', { class: 'field', type: 'range', min: '120', max: '1600', step: '20', value: String((s.ui && s.ui.animationDuration) || 450) });
  const animDurLab = el('span', { class: 'hint', text: ((s.ui && s.ui.animationDuration) || 450) + ' мс' });
  animDur.addEventListener('input', () => {
    animDurLab.textContent = animDur.value + ' мс';
    document.documentElement.style.setProperty('--anim-dur', animDur.value + 'ms');
  });
  animDur.addEventListener('change', async () => {
    await api.settings.set('ui.animationDuration', Number(animDur.value));
  });
  wrap.appendChild(field('Длительность анимации появления', animDur));
  wrap.appendChild(animDurLab);

  const splashDur = el('input', { class: 'field', type: 'number', min: '0', max: '30000', step: '500', value: String((s.ui && s.ui.splashDuration) || 0) });
  splashDur.addEventListener('change', async () => {
    await api.settings.set('ui.splashDuration', Number(splashDur.value) || 0);
  });
  wrap.appendChild(field('Длительность заставки, мс (0 — как в видео)', splashDur));

  const caroSec = el('input', { class: 'field', type: 'range', min: '3', max: '30', value: String((s.ui && s.ui.carouselSeconds) || 10) });
  const caroSecLab = el('span', { class: 'hint', text: ((s.ui && s.ui.carouselSeconds) || 10) + ' сек' });
  caroSec.addEventListener('input', () => { caroSecLab.textContent = caroSec.value + ' сек'; });
  caroSec.addEventListener('change', async () => {
    await api.settings.set('ui.carouselSeconds', Number(caroSec.value) || 10);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.carouselSeconds = Number(caroSec.value) || 10;
  });
  wrap.appendChild(field('Смена слайда обучения', caroSec));
  wrap.appendChild(caroSecLab);

  wrap.appendChild(chk('Показывать статистику на главной', !s.ui || s.ui.statCards !== false, async (v) => {
    await api.settings.set('ui.statCards', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Показывать кнопки действий на главной', !s.ui || s.ui.homeActions !== false, async (v) => {
    await api.settings.set('ui.homeActions', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Компактный интерфейс', Boolean(s.ui && s.ui.compact), async (v) => {
    await api.settings.set('ui.compact', v);
    document.documentElement.setAttribute('data-compact', v ? 'on' : 'off');
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.compact = v;
  }));
  wrap.appendChild(chk('Плавное свечение акцента', !s.ui || s.ui.accentGlow !== false, async (v) => {
    await api.settings.set('ui.accentGlow', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.accentGlow = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Приветствие по нику на главной', !s.ui || s.ui.homeGreeting !== false, async (v) => {
    await api.settings.set('ui.homeGreeting', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.homeGreeting = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  const scale = el('input', { class: 'field', type: 'range', min: '80', max: '130', step: '5', value: String((s.ui && s.ui.uiScale) || 100) });
  const scaleLab = el('span', { class: 'hint', text: ((s.ui && s.ui.uiScale) || 100) + '%' });
  scale.addEventListener('input', () => {
    scaleLab.textContent = scale.value + '%';
    const factor = Number(scale.value) / 100;
    document.documentElement.style.setProperty('--ui-scale', String(factor));
    if (api.window && api.window.setZoom) api.window.setZoom(factor).catch(() => {});
  });
  scale.addEventListener('change', async () => {
    await api.settings.set('ui.uiScale', Number(scale.value) || 100);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Масштаб интерфейса', scale));
  wrap.appendChild(scaleLab);

  const sideW = el('input', { class: 'field', type: 'range', min: '64', max: '132', step: '4', value: String((s.ui && s.ui.navWidth) || 92) });
  const sideWLab = el('span', { class: 'hint', text: ((s.ui && s.ui.navWidth) || 92) + ' px' });
  sideW.addEventListener('input', () => {
    sideWLab.textContent = sideW.value + ' px';
    // Write the *user* width, not the resolved --nav: --nav is capped by the
    // responsive breakpoints, so an inline --nav would fight the media queries.
    document.documentElement.style.setProperty('--nav-user', sideW.value + 'px');
  });
  sideW.addEventListener('change', async () => {
    await api.settings.set('ui.navWidth', Number(sideW.value) || 92);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Ширина панели навигации', sideW));
  wrap.appendChild(sideWLab);

  const radiusTop = el('input', { class: 'field', type: 'range', min: '0', max: '30', value: String((s.ui && s.ui.cardRadius) || 18) });
  const radiusTopLab = el('span', { class: 'hint', text: ((s.ui && s.ui.cardRadius) || 18) + ' px' });
  radiusTop.addEventListener('input', () => {
    radiusTopLab.textContent = radiusTop.value + ' px';
    document.documentElement.style.setProperty('--card-radius', radiusTop.value + 'px');
  });
  radiusTop.addEventListener('change', async () => {
    await api.settings.set('ui.cardRadius', Number(radiusTop.value) || 18);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Скругление карточек', radiusTop));
  wrap.appendChild(radiusTopLab);

  // Opacity + blur are applied straight to the root variables so the whole
  // window restyles on the spot, with the value persisted for next launch.
  const opac = el('input', { class: 'field', type: 'range', min: '30', max: '100', step: '5', value: String((s.ui && s.ui.panelOpacity) || 100) });
  const opacLab = el('span', { class: 'hint', text: ((s.ui && s.ui.panelOpacity) || 100) + '%' });
  opac.addEventListener('input', () => {
    opacLab.textContent = opac.value + '%';
    document.documentElement.style.setProperty('--panel-pct', opac.value + '%');
  });
  opac.addEventListener('change', async () => {
    await api.settings.set('ui.panelOpacity', Number(opac.value));
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Прозрачность панелей', opac));
  wrap.appendChild(opacLab);

  const blurRange = el('input', { class: 'field', type: 'range', min: '0', max: '40', step: '2', value: String((s.ui && s.ui.glassBlur) || 0) });
  const blurLab = el('span', { class: 'hint', text: ((s.ui && s.ui.glassBlur) || 0) ? ((s.ui && s.ui.glassBlur) || 0) + ' px' : 'как в теме' });
  blurRange.addEventListener('input', () => {
    const v = Number(blurRange.value);
    blurLab.textContent = v ? v + ' px' : 'как в теме';
    if (v > 0) document.documentElement.style.setProperty('--glass-blur', v + 'px');
    else document.documentElement.style.removeProperty('--glass-blur');
  });
  blurRange.addEventListener('change', async () => {
    await api.settings.set('ui.glassBlur', Number(blurRange.value) || 0);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Размытие стекла', blurRange));
  wrap.appendChild(blurLab);

  const navIcon = el('input', { class: 'field', type: 'range', min: '14', max: '28', step: '1', value: String((s.ui && s.ui.navIconSize) || 18) });
  const navIconLab = el('span', { class: 'hint', text: ((s.ui && s.ui.navIconSize) || 18) + ' px' });
  navIcon.addEventListener('input', () => {
    navIconLab.textContent = navIcon.value + ' px';
    document.documentElement.style.setProperty('--nav-icon', navIcon.value + 'px');
  });
  navIcon.addEventListener('change', async () => {
    await api.settings.set('ui.navIconSize', Number(navIcon.value) || 18);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Размер иконок навигации', navIcon));
  wrap.appendChild(navIconLab);

  wrap.appendChild(field('Позиция уведомлений', customSelect([
    { value: 'bottom', label: 'Снизу справа' },
    { value: 'top', label: 'Сверху справа' }
  ], (s.ui && s.ui.toastPos) || 'bottom', async (v) => {
    await api.settings.set('ui.toastPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.toastPos = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  const toastLife = el('input', { class: 'field', type: 'range', min: '1200', max: '12000', step: '200', value: String((s.ui && s.ui.toastDuration) || 4200) });
  const toastLifeLab = el('span', { class: 'hint', text: (((s.ui && s.ui.toastDuration) || 4200) / 1000).toFixed(1) + ' сек' });
  toastLife.addEventListener('input', () => { toastLifeLab.textContent = (Number(toastLife.value) / 1000).toFixed(1) + ' сек'; });
  toastLife.addEventListener('change', async () => {
    await api.settings.set('ui.toastDuration', Number(toastLife.value) || 4200);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.toastDuration = Number(toastLife.value) || 4200;
  });
  wrap.appendChild(field('Сколько висят уведомления', toastLife));
  wrap.appendChild(toastLifeLab);

  wrap.appendChild(field('Угол панели загрузок и уведомлений', customSelect([
    { value: 'right', label: 'Снизу справа' },
    { value: 'left', label: 'Снизу слева' }
  ], (s.ui && s.ui.dockPos) || 'right', async (v) => {
    await api.settings.set('ui.dockPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.dockPos = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  const bgBlur = el('input', { class: 'field', type: 'range', min: '0', max: '24', step: '1', value: String((s.ui && s.ui.bgBlur) || 0) });
  const bgBlurLab = el('span', { class: 'hint', text: ((s.ui && s.ui.bgBlur) || 0) + ' px' });
  bgBlur.addEventListener('input', () => {
    bgBlurLab.textContent = bgBlur.value + ' px';
    document.documentElement.style.setProperty('--bg-blur', bgBlur.value + 'px');
  });
  bgBlur.addEventListener('change', async () => {
    await api.settings.set('ui.bgBlur', Number(bgBlur.value) || 0);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.bgBlur = Number(bgBlur.value) || 0;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  });
  wrap.appendChild(field('Размытие обоев', bgBlur));
  wrap.appendChild(bgBlurLab);

  wrap.appendChild(chk('Подписи под иконками навигации', !s.ui || s.ui.navLabels !== false, async (v) => {
    await api.settings.set('ui.navLabels', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.navLabels = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  wrap.appendChild(chk('Подъём карточек при наведении', !s.ui || s.ui.hoverLift !== false, async (v) => {
    await api.settings.set('ui.hoverLift', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.hoverLift = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  wrap.appendChild(chk('Строка состояния (пинг и онлайн)', !s.ui || s.ui.showStatusBar !== false, async (v) => {
    await api.settings.set('ui.showStatusBar', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.showStatusBar = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));

  wrap.appendChild(field('Плотность интерфейса', customSelect([
    { value: 'cozy', label: 'Просторно' },
    { value: 'normal', label: 'Обычно' },
    { value: 'dense', label: 'Плотно' }
  ], (s.ui && s.ui.density) || 'normal', async (v) => {
    await api.settings.set('ui.density', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.density = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  wrap.appendChild(field('Позиция панели действий', customSelect([
    { value: 'auto', label: 'Как в теме' },
    { value: 'top', label: 'Сверху' },
    { value: 'bottom', label: 'Снизу' }
  ], (s.ui && s.ui.toolsPos) || 'auto', async (v) => {
    await api.settings.set('ui.toolsPos', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.toolsPos = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  })));

  block('Звук');
  wrap.appendChild(chk('Звуки интерфейса и заставки', !s.ui || s.ui.sounds !== false, async (v) => {
    await api.settings.set('ui.sounds', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.sounds = v;
    if (v) sound.ok();
  }));
  const vol = el('input', { class: 'field', type: 'range', min: '0', max: '100', value: String(Math.round(((s.ui && s.ui.soundVolume != null ? s.ui.soundVolume : 0.6)) * 100)) });
  const volLab = el('span', { class: 'hint', text: Math.round(((s.ui && s.ui.soundVolume != null ? s.ui.soundVolume : 0.6)) * 100) + '%' });
  vol.addEventListener('input', () => {
    volLab.textContent = vol.value + '%';
    document.documentElement.style.setProperty('--sound-volume', String(Number(vol.value) / 100));
  });
  vol.addEventListener('change', async () => {
    await api.settings.set('ui.soundVolume', Number(vol.value) / 100);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.soundVolume = Number(vol.value) / 100;
    sound.ok();
  });
  wrap.appendChild(field('Громкость звуков', vol));
  wrap.appendChild(volLab);

  wrap.appendChild(chk('Клики со звуком', !s.ui || s.ui.clickSounds !== false, async (v) => {
    await api.settings.set('ui.clickSounds', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.clickSounds = v;
  }));
  wrap.appendChild(chk('Звук при наборе текста', !s.ui || s.ui.typingSounds !== false, async (v) => {
    await api.settings.set('ui.typingSounds', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.typingSounds = v;
  }));

  // ---- Custom sounds ------------------------------------------------------
  // Every event gets its own volume, mute switch and file picker. Files live in
  // `muzick`; the picker copies nothing, it just remembers the path, so the
  // player can keep their own library where it already is.
  const SOUND_ROWS = [
    ['klick', 'Клик мыши'],
    ['knopka', 'Нажатие кнопки'],
    ['sew', 'Выбор в списке'],
    ['posluzunok', 'Движение ползунка'],
    ['zvukprinapisanii', 'Набор текста'],
    ['interfeyse', 'Открытие окна'],
    ['ura', 'Успех / готово'],
    ['eror', 'Ошибка'],
    ['warn', 'Предупреждение'],
    ['zastavka', 'Заставка / запуск']
  ];
  let soundFiles = await api.sounds.payload().catch(() => ({ sounds: {}, music: [] }));
  const soundList = el('div', { class: 'sound-list' });
  for (const [event, label] of SOUND_ROWS) {
    const row = el('div', { class: 'sound-row' });
    const name = el('div', { class: 'sound-name' });
    name.appendChild(el('strong', { text: label }));
    const state = el('span', { class: 'hint', text: (s.ui && s.ui.soundFiles && s.ui.soundFiles[event]) ? 'свой файл' : 'встроенный' });
    name.appendChild(state);
    row.appendChild(name);

    const own = el('input', {
      class: 'sound-vol', type: 'range', min: '0', max: '100',
      value: String(Math.round((((s.ui && s.ui.soundVolumes) || {})[event] != null ? s.ui.soundVolumes[event] : 1) * 100))
    });
    own.addEventListener('input', async () => {
      const v = Number(own.value) / 100;
      await api.settings.set(`ui.soundVolumes.${event}`, v);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.soundVolumes = store.settings.ui.soundVolumes || {};
      store.settings.ui.soundVolumes[event] = v;
    });
    row.appendChild(own);

    const muted = el('input', { type: 'checkbox' });
    muted.checked = Boolean(s.ui && s.ui.soundMuted && s.ui.soundMuted[event]);
    muted.addEventListener('change', async () => {
      await api.settings.set(`ui.soundMuted.${event}`, muted.checked);
      store.settings.ui = store.settings.ui || {};
      store.settings.ui.soundMuted = store.settings.ui.soundMuted || {};
      store.settings.ui.soundMuted[event] = muted.checked;
    });
    muted.setAttribute('aria-label', 'Выключить этот звук');
    row.appendChild(muted);

    row.appendChild(iconBtn('play', 'Послушать', () => sound.play(event)));
    row.appendChild(iconBtn('folder', 'Свой файл', async () => {
      const r = await api.sounds.pick(event);
      if (r && r.ok) {
        soundFiles = await api.sounds.payload().catch(() => soundFiles);
        state.textContent = 'свой файл';
        toast('Звук обновлён');
        sound.play(event);
      }
    }));
    row.appendChild(iconBtn('refresh', 'Вернуть встроенный', async () => {
      await api.sounds.clear(event);
      soundFiles = await api.sounds.payload().catch(() => soundFiles);
      state.textContent = 'встроенный';
      toast('Вернул встроенный звук');
    }));
    soundList.appendChild(row);
  }
  wrap.appendChild(soundList);
  const soundRow = el('div', { class: 'row', style: 'margin-top:8px' });
  soundRow.appendChild(el('button', { class: 'btn', text: 'Открыть папку muzick', onclick: () => api.system.openPath('muzick') }));
  soundRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Восстановить все звуки', onclick: async () => {
    await api.sounds.reset();
    await api.sounds.regenerate();
    soundFiles = await api.sounds.payload().catch(() => soundFiles);
    toast('Звуки сброшены');
  } }));
  wrap.appendChild(soundRow);

  block('Музыка (папка muzick/fon)');
  const musicTracks = (soundFiles && soundFiles.music) || [];
  wrap.appendChild(el('p', {
    class: 'hint',
    text: musicTracks.length
      ? `Найдено треков: ${musicTracks.length}. Играют в лаунчере фоном, настройки ниже.`
      : 'Положи mp3/ogg/wav в папку muzick/fon — и треки появятся здесь.'
  }));
  const musicVol = el('input', { class: 'field', type: 'range', min: '0', max: '100', value: String(Math.round(((s.ui && s.ui.musicVolume != null ? s.ui.musicVolume : 0.5)) * 100)) });
  const musicVolLab = el('span', { class: 'hint', text: Math.round(((s.ui && s.ui.musicVolume != null ? s.ui.musicVolume : 0.5)) * 100) + '%' });
  musicVol.addEventListener('input', () => {
    musicVolLab.textContent = musicVol.value + '%';
    setMusicVolume(Number(musicVol.value) / 100);
  });
  musicVol.addEventListener('change', async () => {
    await api.settings.set('ui.musicVolume', Number(musicVol.value) / 100);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicVolume = Number(musicVol.value) / 100;
  });
  wrap.appendChild(field('Громкость музыки', musicVol));
  wrap.appendChild(musicVolLab);
  wrap.appendChild(field('Режим музыки', customSelect([
    { value: 'playlist', label: 'Плейлист по кругу' },
    { value: 'single', label: 'Один трек повторять' },
    { value: 'once', label: 'Проиграть один раз' },
    { value: 'off', label: 'Выключена' }
  ], (s.ui && s.ui.musicMode) || 'playlist', async (v) => {
    await api.settings.set('ui.musicMode', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicMode = v;
    playMusic({ restart: true });
  })));
  wrap.appendChild(chk('Запускать музыку автоматически', !s.ui || s.ui.musicAutoplay !== false, async (v) => {
    await api.settings.set('ui.musicAutoplay', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.musicAutoplay = v;
    if (v) playMusic({});
  }));
  wrap.appendChild(chk('Показывать карточку музыки на главной', !s.ui || s.ui.showMusicCard !== false, async (v) => {
    await api.settings.set('ui.showMusicCard', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.showMusicCard = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));
  const musicRow = el('div', { class: 'row', style: 'margin-top:8px' });
  musicRow.appendChild(el('button', { class: 'btn', text: '▶ Играть', onclick: () => playMusic({}) }));
  musicRow.appendChild(el('button', { class: 'btn', text: '⏸ Пауза', onclick: () => pauseMusic() }));
  musicRow.appendChild(el('button', { class: 'btn', text: 'Следующий', onclick: () => nextTrack() }));
  musicRow.appendChild(el('button', { class: 'btn', text: 'Открыть папку', onclick: () => api.system.openPath('muzick/fon') }));
  wrap.appendChild(musicRow);

  wrap.appendChild(chk('3D-скин вместо обучения на главной', Boolean(s.ui && s.ui.showSkin3d), async (v) => {
    await api.settings.set('ui.showSkin3d', v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Частицы на фоне', Boolean(s.ui && s.ui.particles), async (v) => {
    await api.settings.set('ui.particles', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.particles = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Карусель обучения на главной', !s.ui || s.ui.hideCarousel !== true, async (v) => {
    await api.settings.set('ui.hideCarousel', !v);
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Виджеты на главной (по умолчанию выключены)', Boolean(s.ui && s.ui.showWidgets), async (v) => {
    await api.settings.set('ui.showWidgets', v);
    store.settings.ui = store.settings.ui || {};
    store.settings.ui.showWidgets = v;
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
  }));
  wrap.appendChild(chk('Фурри-виджет', s.ui && s.ui.furryWidget !== false, async (v) => {
    await api.settings.set('ui.furryWidget', v);
  }));
  wrap.appendChild(chk('Виджет скриншотов', s.ui && s.ui.shotsWidget !== false, async (v) => {
    await api.settings.set('ui.shotsWidget', v);
  }));

  const dim = el('input', { class: 'field', type: 'range', min: '20', max: '90', value: String(Math.round(((s.ui && s.ui.bgDim) || 0.55) * 100)) });
  dim.addEventListener('input', async () => {
    const v = Number(dim.value) / 100;
    document.documentElement.style.setProperty('--bg-dim', String(v));
    await api.settings.set('ui.bgDim', v);
  });
  wrap.appendChild(field('Затемнение фона', dim));

  const bgRow = el('div', { class: 'row', style: 'margin:8px 0 12px' });
  bgRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Загрузить фон', onclick: async () => {
    const r = await api.theme.pickBackground();
    if (r && r.ok) {
      // Apply immediately — the wallpaper used to only show up after a restart.
      if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
      toast('Фон применён');
    }
  } }));
  bgRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Сбросить фон', onclick: async () => {
    await api.settings.set('ui.backgroundFile', '');
    await api.settings.set('ui.backgroundKind', 'video');
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
    toast('Фон сброшен');
  } }));
  bgRow.appendChild(el('button', { class: 'btn', text: 'Видео заставки', onclick: async () => {
    const r = await api.theme.pickSplash();
    if (r && r.ok) toast('Заставка сохранена');
  } }));
  wrap.appendChild(bgRow);

  const furRow = el('div', { class: 'row', style: 'margin-bottom:12px' });
  furRow.appendChild(el('button', { class: 'btn', text: 'Картинка фурри', onclick: async () => {
    const r = await api.theme.pickFurryImage();
    if (r && r.ok) toast('Картинка сохранена');
  } }));
  furRow.appendChild(el('button', { class: 'btn', text: '3 своих звука', onclick: async () => {
    const r = await api.theme.pickFurrySounds();
    if (r && r.ok) toast('Звуки сохранены');
  } }));
  wrap.appendChild(furRow);

  block('Память и картинка');
  const mode = el('select', { class: 'field' });
  mode.appendChild(el('option', { value: 'auto', text: 'Автоматически под систему' }));
  mode.appendChild(el('option', { value: 'manual', text: 'Задать вручную' }));
  mode.value = (s.game && s.game.memoryMode) || 'auto';
  const mem = el('input', { class: 'field', type: 'range', min: '2048', max: String(Math.max(4096, ram.totalMb - 1024 || 8192)), step: '256', value: String((s.game && s.game.defaultMemoryMb) || ram.recommendedMb) });
  const memLab = el('p', { class: 'hint', text: mem.value + ' МБ  ·  в ПК ' + ram.totalMb + ' МБ' });
  mem.addEventListener('input', () => { memLab.textContent = mem.value + ' МБ'; });
  async function saveRam() {
    await api.settings.set('game.memoryMode', mode.value);
    await api.settings.set('game.defaultMemoryMb', Number(mem.value));
    if (store.selectedId) await api.instances.update(store.selectedId, { memoryMb: Number(mem.value), memoryMode: mode.value });
    toast('RAM сохранена');
  }
  mode.addEventListener('change', saveRam);
  mem.addEventListener('change', saveRam);
  wrap.appendChild(field('Оперативка для игры', mode));
  wrap.appendChild(mem);
  wrap.appendChild(memLab);

  const w = el('input', { class: 'field', type: 'number', value: String((s.game && s.game.defaultResolution && s.game.defaultResolution.width) || 1280) });
  const h = el('input', { class: 'field', type: 'number', value: String((s.game && s.game.defaultResolution && s.game.defaultResolution.height) || 720) });
  const resRow = el('div', { class: 'row' });
  resRow.appendChild(w); resRow.appendChild(h);
  wrap.appendChild(field('Разрешение окна', resRow));
  w.addEventListener('change', () => api.settings.set('game.defaultResolution', { width: Number(w.value) || 1280, height: Number(h.value) || 720 }));
  h.addEventListener('change', () => api.settings.set('game.defaultResolution', { width: Number(w.value) || 1280, height: Number(h.value) || 720 }));

  wrap.appendChild(chk('Полный экран', s.game && s.game.defaultFullscreen, (v) => api.settings.set('game.defaultFullscreen', v)));
  block('Java и рендер');
  const javaCmd = el('input', { class: 'field', placeholder: 'Полный путь java.exe', value: (s.game && s.game.javaCommand) || '' });
  javaCmd.addEventListener('change', () => api.settings.set('game.javaCommand', javaCmd.value.trim()));
  wrap.appendChild(field('Своя команда Java', javaCmd));
  const jvm = el('input', { class: 'field', placeholder: '-XX:+UseG1GC', value: (s.game && s.game.customJvmArgs) || '' });
  jvm.addEventListener('change', () => api.settings.set('game.customJvmArgs', jvm.value.trim()));
  wrap.appendChild(field('Доп. аргументы JVM', jvm));

  const gpu = el('select', { class: 'field' });
  gpu.appendChild(el('option', { value: 'auto', text: 'Авто' }));
  const gpus = await api.system.gpus().catch(() => []);
  for (const g of gpus) gpu.appendChild(el('option', { value: g.id, text: g.name }));
  gpu.value = (s.game && s.game.gpu) || 'auto';
  gpu.addEventListener('change', () => api.settings.set('game.gpu', gpu.value));
  wrap.appendChild(field('Видеокарта', gpu));

  const render = customSelect([
    { value: 'default', label: 'По умолчанию' },
    { value: 'fabulous', label: 'Fabulous' },
    { value: 'fancy', label: 'Fancy' },
    { value: 'fast', label: 'Fast' }
  ], (s.game && s.game.graphics) || 'default', (v) => api.settings.set('game.graphics', v));
  wrap.appendChild(field('Рендер игры', render));

  block('Игра: графика и мир');
  const g = (s.game || {});
  const numRow = (label, key, opts) => {
    const input = el('input', { class: 'field', type: 'range', min: String(opts.min), max: String(opts.max), step: String(opts.step || 1), value: String(g[key] != null ? g[key] : opts.def) });
    const lab = el('span', { class: 'hint', text: input.value });
    input.addEventListener('input', () => {
      lab.textContent = input.value;
      document.documentElement.style.setProperty('--tmp', '0');
    });
    input.addEventListener('change', async () => {
      await api.settings.set('game.' + key, Number(input.value));
      store.settings.game = store.settings.game || {};
      store.settings.game[key] = Number(input.value);
    });
    wrap.appendChild(field(label, input));
    wrap.appendChild(lab);
  };
  numRow('Дальность прорисовки', 'renderDistance', { min: 2, max: 32, def: 12 });
  numRow('Дальность симуляции', 'simulationDistance', { min: 4, max: 32, def: 12 });
  numRow('Угол обзора (FOV)', 'fov', { min: 30, max: 110, def: 70 });
  numRow('Лимит FPS (0 — без лимита)', 'maxFps', { min: 0, max: 480, step: 10, def: 0 });
  numRow('Громкость игры', 'masterVolume', { min: 0, max: 100, def: 100 });
  numRow('Громкость музыки', 'musicVolume', { min: 0, max: 100, def: 100 });

  wrap.appendChild(field('Сложность', customSelect([
    { value: 'peaceful', label: 'Мирная' },
    { value: 'easy', label: 'Лёгкая' },
    { value: 'normal', label: 'Обычная' },
    { value: 'hard', label: 'Сложная' }
  ], g.difficulty || 'normal', (v) => api.settings.set('game.difficulty', v))));
  wrap.appendChild(field('Видимость чата', customSelect([
    { value: 'full', label: 'Полный' },
    { value: 'system', label: 'Только системный' },
    { value: 'hidden', label: 'Скрыт' }
  ], g.chatVisibility || 'full', (v) => api.settings.set('game.chatVisibility', v))));
  wrap.appendChild(chk('Вертикальная синхронизация', g.vsync !== false, (v) => api.settings.set('game.vsync', v)));
  wrap.appendChild(chk('Показывать FPS', Boolean(g.showFps), (v) => api.settings.set('game.showFps', v)));
  wrap.appendChild(chk('Автопрыжок', Boolean(g.autoJump), (v) => api.settings.set('game.autoJump', v)));
  wrap.appendChild(chk('Прямой ввод мыши (raw input)', g.rawMouseInput !== false, (v) => api.settings.set('game.rawMouseInput', v)));
  wrap.appendChild(chk('Спринт-тумблер (Shift)', g.toggleSprint !== false, (v) => api.settings.set('game.toggleSprint', v)));
  wrap.appendChild(chk('Крадущийся режим (Shift)', Boolean(g.toggleSneak), (v) => api.settings.set('game.toggleSneak', v)));
  wrap.appendChild(field('Частицы', customSelect([
    { value: 'all', label: 'Все' },
    { value: 'decreased', label: 'Меньше' },
    { value: 'minimal', label: 'Минимум' }
  ], g.particlesSetting || 'all', (v) => api.settings.set('game.particlesSetting', v))));
  const guiScaleSel = customSelect([
    { value: '0', label: 'Авто' },
    { value: '1', label: 'Маленький' },
    { value: '2', label: 'Обычный' },
    { value: '3', label: 'Большой' },
    { value: '4', label: 'Огромный' }
  ], String(g.guiScale || 0), (v) => api.settings.set('game.guiScale', Number(v)));
  wrap.appendChild(field('Размер интерфейса Minecraft', guiScaleSel));
  wrap.appendChild(chk('Запускать игру на весь экран', Boolean(g.fullscreenOnLaunch), (v) => api.settings.set('game.fullscreenOnLaunch', v)));
  wrap.appendChild(chk('Автоматически добавлять сервер Cryndel.ru', g.autoAddServer !== false, (v) => api.settings.set('game.autoAddServer', v)));
  const hostInput = el('input', { class: 'field', value: g.serverHost || 'cryndel.ru', placeholder: 'cryndel.ru' });
  hostInput.addEventListener('change', () => api.settings.set('game.serverHost', hostInput.value.trim() || 'cryndel.ru'));
  wrap.appendChild(field('Адрес сервера', hostInput));
  const portInput = el('input', { class: 'field', type: 'number', value: String(g.serverPort || 25565) });
  portInput.addEventListener('change', () => api.settings.set('game.serverPort', Number(portInput.value) || 25565));
  wrap.appendChild(field('Порт сервера', portInput));

  block('Игра: мир и детали');
  const sel = (label, key, opts) => {
    wrap.appendChild(field(label, customSelect(opts, g[key], (v) => {
      api.settings.set('game.' + key, v);
      store.settings.game = store.settings.game || {};
      store.settings.game[key] = v;
    })));
  };
  sel('Облака', 'clouds', [
    { value: 'default', label: 'Как в игре' },
    { value: 'true', label: 'Красивые' },
    { value: 'false', label: 'Скрыть' },
    { value: 'fast', label: 'Быстрые' }
  ]);
  sel('Модель скина', 'skinModel', [
    { value: 'default', label: 'Как в игре' },
    { value: 'classic', label: 'Классическая (широкие руки)' },
    { value: 'slim', label: 'Тонкая (Alex)' }
  ]);
  sel('Повествование (Narrator)', 'narrator', [
    { value: 0, label: 'Выкл' },
    { value: 1, label: 'Вкл' },
    { value: 2, label: 'Только системное' },
    { value: 3, label: 'Все' }
  ]);
  wrap.appendChild(chk('Мягкое освещение (smooth lighting)', g.smoothLighting !== false, (v) => {
    api.settings.set('game.smoothLighting', v);
    store.settings.game = store.settings.game || {};
    store.settings.game.smoothLighting = v;
  }));
  wrap.appendChild(chk('Тени сущностей', g.entityShadows !== false, (v) => {
    api.settings.set('game.entityShadows', v);
    store.settings.game = store.settings.game || {};
    store.settings.game.entityShadows = v;
  }));
  wrap.appendChild(chk('Покачивание камеры при ходьбе', g.bobView !== false, (v) => {
    api.settings.set('game.bobView', v);
    store.settings.game = store.settings.game || {};
    store.settings.game.bobView = v;
  }));
  wrap.appendChild(chk('Пауза при потере фокуса', g.pauseOnLostFocus !== false, (v) => {
    api.settings.set('game.pauseOnLostFocus', v);
    store.settings.game = store.settings.game || {};
    store.settings.game.pauseOnLostFocus = v;
  }));
  wrap.appendChild(chk('Инвертировать мышь по Y', Boolean(g.invertYMouse), (v) => {
    api.settings.set('game.invertYMouse', v);
    store.settings.game = store.settings.game || {};
    store.settings.game.invertYMouse = v;
  }));
  numRow('Чувствительность мыши, %', 'mouseSensitivityPct', { min: 10, max: 200, def: 100 });
  numRow('Яркость (гамма)', 'gammaPct', { min: 0, max: 100, def: 50 });
  numRow('Прозрачность чата, %', 'chatOpacityPct', { min: 0, max: 100, def: 100 });

  block('Плащи (только на клиенте)');
  const capeRow = el('div', { class: 'row', style: 'margin-bottom:8px' });
  const capePrev = el('img', { class: 'cape-prev', alt: 'плащ' });
  capeRow.appendChild(capePrev);
  capeRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Выбрать плащ PNG', onclick: async () => {
    const r = await api.skins.importCape();
    if (r && r.ok) {
      const u = await api.skins.capePreview().catch(() => null);
      if (u) capePrev.src = u;
      toast('Плащ сохранён');
    }
  } }));
  capeRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Убрать плащ', onclick: async () => {
    await api.skins.clearCape();
    capePrev.removeAttribute('src');
    toast('Плащ убран');
  } }));
  wrap.appendChild(capeRow);
  api.skins.capePreview().then((u) => { if (u) capePrev.src = u; }).catch(() => {});

  block('Java и рендер');

  const javaBox = el('div', { class: 'card', style: 'margin:12px 0' });
  const javas = await api.system.detectJava().catch(() => []);
  if (!javas.length) javaBox.appendChild(el('p', { class: 'hint', text: 'Java не найдена — лаунчер скачает сам.' }));
  for (const j of javas) javaBox.appendChild(el('div', { text: j.path + ' (' + (j.version || '?') + ')', class: 'hint' }));
  javaBox.appendChild(el('button', { class: 'btn btn-sky', style: 'margin-top:10px', text: 'Скачать Java 21', onclick: async () => {
    try { toast('Качаю Java 21…'); await api.java.ensure(21); toast('Java готова'); }
    catch (e) { toast(e.message || 'Не удалось скачать Java', 'bad'); }
  } }));
  wrap.appendChild(javaBox);

  block('Лаунчер');
  wrap.appendChild(chk('Discord RPC', !s.launcher || s.launcher.discordRpc !== false, async (v) => {
    await api.settings.set('launcher.discordRpc', v);
    try {
      const r = await api.discord.toggle(v);
      if (v && r && r.needsAppId) {
        toast('Укажи Discord App ID ниже — без него RPC не покажется', 'bad');
      } else if (v && r && r.ready === false) {
        toast('Discord не отвечает — проверь, запущен ли он и верен ли App ID', 'bad');
      } else if (v && r && r.ready) {
        toast('Discord подключён', 'ok');
      }
    } catch (_) { /* */ }
  }));
  const discordId = el('input', { class: 'field', placeholder: 'Например: 1234567890123456789', value: (s.advanced && s.advanced.discordAppId) || '' });
  discordId.addEventListener('change', async () => {
    const v = discordId.value.trim();
    await api.settings.set('advanced.discordAppId', v);
    try {
      const r = await api.discord.configure(v);
      if (v && r && r.ready) toast('Discord подключён', 'ok');
      else if (v && r && r.error) toast(r.error, 'bad');
    } catch (_) { /* */ }
    toast(v ? 'Discord App ID сохранён' : 'Discord App ID сброшен');
  });
  wrap.appendChild(field('Discord App ID (для Rich Presence)', discordId));
  const discordState = el('p', { class: 'hint', text: 'Проверяю Discord…' });
  function paintDiscord(r) {
    if (!r) { discordState.textContent = ''; return; }
    if (r.ready) { discordState.textContent = 'Discord подключён'; return; }
    if (r.needsAppId) {
      discordState.textContent = 'Укажи Discord App ID — без него статус в Discord не появится. Создай приложение на discord.com/developers и вставь его Application ID.';
      return;
    }
    discordState.textContent = 'Discord не подключён' + (r.error ? ' · ' + r.error : '');
  }
  api.discord.status().then(paintDiscord).catch(() => { discordState.textContent = ''; });
  wrap.appendChild(discordState);
  wrap.appendChild(chk('Сворачивать в трей при запуске игры', s.launcher && s.launcher.minimizeToTray !== false, (v) => api.settings.set('launcher.minimizeToTray', v)));
  wrap.appendChild(chk('Закрывать лаунчер при запуске игры', s.launcher && s.launcher.closeOnLaunch, (v) => api.settings.set('launcher.closeOnLaunch', v)));
  wrap.appendChild(chk('Возвращать лаунчер после закрытия игры', !s.launcher || s.launcher.showOnGameExit !== false, (v) => api.settings.set('launcher.showOnGameExit', v)));

  block('Скин');
  const skinBox = el('div', { class: 'card' });
  const skinRowPrev = el('div', { class: 'row', style: 'align-items:flex-start;gap:16px' });
  const skinPrev = el('img', { class: 'skin-prev', alt: 'лицо' });
  const skinFront = el('canvas', { width: '96', height: '192', class: 'skin-front' });
  skinRowPrev.appendChild(skinPrev);
  skinRowPrev.appendChild(skinFront);
  skinBox.appendChild(skinRowPrev);
  async function showSkin(p) {
    if (!p) return;
    const u = await api.skins.preview(p).catch(() => null);
    if (u) {
      paintSkinFace(skinPrev, u);
      drawSkinFront(skinFront, u);
    }
  }
  if (store.user && store.user.skin && store.user.skin.path) showSkin(store.user.skin.path);
  const skinRow = el('div', { class: 'row', style: 'margin-top:10px' });
  skinRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Файл PNG', onclick: async () => {
    const r = await api.skins.importFile();
    if (r.ok) {
      await showSkin(r.path);
      if (store.selectedId) await api.skins.apply(r.path, store.selectedId);
      if (window.__cryndelRefresh) await window.__cryndelRefresh();
      toast('Скин сохранён');
    }
  } }));
  const nickSkin = el('input', { class: 'field', placeholder: 'Ник для скина' });
  skinRow.appendChild(nickSkin);
  skinRow.appendChild(el('button', { class: 'btn', text: 'По нику', onclick: async () => {
    try {
      const r = await api.skins.fromNick(nickSkin.value.trim() || (store.user && store.user.nick));
      await showSkin(r.path);
      if (store.selectedId) await api.skins.apply(r.path, store.selectedId);
      if (window.__cryndelRefresh) await window.__cryndelRefresh();
      toast('Скин скачан');
    } catch (e) { toast(e.message, 'bad'); }
  } }));
  skinBox.appendChild(skinRow);
  wrap.appendChild(skinBox);

  block('Приветствие');
  wrap.appendChild(chk('Показывать приветствие на главной', !s.ui || s.ui.greetingEnabled !== false, async (v) => {
    await api.settings.set('ui.greetingEnabled', v);
    store.settings.ui.greetingEnabled = v;
    if (window.__cryndelApplyUi) await window.__cryndelApplyUi();
  }));
  const greetHint = el('p', { class: 'hint', text: 'Тексты берутся из data/greetings.json: ключ «default» — общий, ключ с ником — только для него. {nick} подставит ник, {time} — время суток (утро/день/вечер/ночь).' });
  wrap.appendChild(greetHint);
  const greetArea = el('textarea', { class: 'field css-editor', spellcheck: 'false', style: 'min-height:130px;font-family:var(--mono);font-size:12.5px;line-height:1.5' });
  greetArea.value = 'Загрузка…';
  const greetStatus = el('p', { class: 'hint', text: '' });
  async function loadGreetings() {
    const r = await api.greeting.read().catch(() => null);
    const g = (r && r.greetings) || {};
    greetArea.value = JSON.stringify(g, null, 2);
  }
  loadGreetings();
  const greetRow = el('div', { class: 'row', style: 'margin-top:8px' });
  greetRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Сохранить', onclick: async () => {
    try {
      const parsed = JSON.parse(greetArea.value || '{}');
      const r = await api.greeting.write(parsed);
      if (r && r.ok) { greetStatus.textContent = 'Сохранено'; toast('Приветствия сохранены'); }
      else { greetStatus.textContent = (r && r.error) || 'Ошибка'; toast('Не удалось сохранить', 'bad'); }
    } catch (e) { greetStatus.textContent = 'JSON сломан: ' + e.message; toast('JSON сломан', 'bad'); }
  } }));
  greetRow.appendChild(el('button', { class: 'btn', text: 'Открыть файл', onclick: () => api.greeting.openFile() }));
  greetRow.appendChild(el('button', { class: 'btn btn-ghost', text: 'Перечитать', onclick: loadGreetings }));
  wrap.appendChild(greetRow);
  wrap.appendChild(greetStatus);
  wrap.appendChild(greetArea);

  block('Плагины');
  wrap.appendChild(chk('Включить плагины', !s.ui || s.ui.pluginsEnabled !== false, async (v) => {
    await api.settings.set('ui.pluginsEnabled', v);
    store.settings.ui.pluginsEnabled = v;
    toast(v ? 'Плагины включены' : 'Плагины выключены');
  }));
  const pluginList = el('div', { class: 'plugin-list' });
  const pluginWarn = el('p', { class: 'hint', text: '' });
  async function paintPlugins() {
    pluginList.replaceChildren();
    const list = await api.plugins.list().catch(() => []);
    if (!list.length) {
      pluginList.appendChild(el('p', { class: 'hint', text: 'Плагинов нет. Положи папку или .zip с manifest.json в папку плагинов.' }));
    }
    for (const p of list) {
      const card = el('div', { class: 'plugin-card' });
      const head = el('div', { class: 'plugin-head' });
      head.appendChild(el('strong', { text: p.name || p.id }));
      head.appendChild(el('span', { class: 'badge ' + (p.error ? 'bad' : p.active ? 'ok' : '') , text: p.error ? 'ошибка' : p.active ? 'активен' : 'выключен' }));
      card.appendChild(head);
      if (p.version || p.author) card.appendChild(el('p', { class: 'hint', text: [p.version && 'v' + p.version, p.author].filter(Boolean).join(' · ') }));
      if (p.description) card.appendChild(el('p', { class: 'hint', text: p.description }));
      if (p.error) card.appendChild(el('p', { class: 'hint', style: 'color:var(--bad)', text: p.error }));
      const row = el('div', { class: 'row' });
      row.appendChild(el('button', { class: 'btn btn-danger btn-sm', text: 'Удалить', onclick: async () => {
        await api.plugins.remove(p.id);
        toast('Плагин удалён');
        paintPlugins();
      } }));
      card.appendChild(row);
      pluginList.appendChild(card);
    }
    const warns = await api.plugins.warnings().catch(() => []);
    pluginWarn.textContent = warns.length ? 'Предупреждения: ' + warns.map((w) => w.id).join(', ') : '';
  }
  paintPlugins();
  const pluginRow = el('div', { class: 'row', style: 'margin-top:8px' });
  pluginRow.appendChild(el('button', { class: 'btn btn-sky', text: 'Установить из .zip', onclick: async () => {
    const r = await api.plugins.install();
    if (r && r.ok) { toast('Плагин установлен'); paintPlugins(); }
    else if (r && !r.cancelled) toast(r.error || 'Не удалось', 'bad');
  } }));
  pluginRow.appendChild(el('button', { class: 'btn', text: 'Открыть папку', onclick: () => api.plugins.openDir() }));
  pluginRow.appendChild(el('button', { class: 'btn', text: 'Перезагрузить', onclick: async () => {
    await api.plugins.reload();
    paintPlugins();
    toast('Плагины перезагружены');
  } }));
  wrap.appendChild(pluginRow);
  wrap.appendChild(pluginWarn);
  wrap.appendChild(pluginList);

  wrap.appendChild(el('button', { class: 'btn', style: 'margin-top:16px', text: 'О лаунчере', onclick: () => {
    location.hash = '#/about';
  } }));
  wrap.appendChild(el('button', { class: 'btn', style: 'margin-top:8px', text: 'Пройти обучение заново', onclick: async () => {
    if (window.__cryndelRedoOnboarding) {
      await window.__cryndelRedoOnboarding();
      toast('Обучение запущено');
    }
  } }));
  wrap.appendChild(el('button', { class: 'btn btn-danger', style: 'margin-top:8px', text: 'Сброс настроек', onclick: async () => {
    store.settings = await api.settings.reset();
    if (window.__cryndelApplyUi) window.__cryndelApplyUi();
    toast('Сброшено');
  } }));
  root.appendChild(wrap);
}
