import { el, fmtNum } from '../utils.js';

export function modrinthCard(hit, { onInstall, onDetails }) {
  const card = el('div', { class: 'card mr-card' });
  const icon = el('img', { alt: '' });
  if (hit.icon_url) icon.setAttribute('src', hit.icon_url);
  const mid = el('div');
  mid.appendChild(el('strong', { text: hit.title || hit.slug }));
  mid.appendChild(el('div', { class: 'mr-meta', text: `${hit.author || ''} · ${fmtNum(hit.downloads)}` }));
  const right = el('div', { class: 'row' });
  right.appendChild(el('button', { class: 'btn btn-ember', text: 'Установить', onclick: () => onInstall && onInstall(hit) }));
  right.appendChild(el('button', { class: 'btn btn-ghost', text: 'Подробнее', onclick: () => onDetails && onDetails(hit) }));
  card.appendChild(icon);
  card.appendChild(mid);
  card.appendChild(right);
  return card;
}
