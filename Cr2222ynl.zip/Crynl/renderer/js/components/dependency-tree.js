import { el } from '../utils.js';

export function dependencyTree(nodes) {
  const ul = el('ul', { class: 'timeline' });
  for (const n of nodes || []) {
    ul.appendChild(el('li', { text: `${n.filename || n.projectId} ${n.versionNumber || ''}` }));
  }
  return ul;
}
