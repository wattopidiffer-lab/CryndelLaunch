import { el } from '../utils.js';

export function attachConsole(host) {
  const box = el('pre', { class: 'card', style: 'max-height:180px;overflow:auto;font-family:var(--mono);font-size:11px' });
  host.appendChild(box);
  if (window.cryndel && window.cryndel.game) {
    window.cryndel.game.onLog((l) => {
      box.textContent += (l.line || '') + '\n';
      box.scrollTop = box.scrollHeight;
    });
  }
  return box;
}
