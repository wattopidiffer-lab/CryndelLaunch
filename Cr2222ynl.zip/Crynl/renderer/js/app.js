import { installMockApi } from './mock-api.js';
import { api } from './api.js';
import { store, bus, toast } from './state.js';
import { loadLocale, t } from './i18n.js';
import { defineRoute, bootRouter, go, apply } from './router.js';
import { el } from './utils.js';
import { svg } from './icons.js';
import { iconBtn, closeBtn, menu, chk, modal, tip, closeMenus } from './ui.js';
import { mountHome } from './screens/main.js';
import { mountModrinth } from './screens/modrinth.js';
import { mountMods } from './screens/mods.js';
import { mountVersions } from './screens/versions.js';
import { mountWizard } from './screens/build-wizard.js';
import { mountSettings } from './screens/settings.js';
import { mountHealth } from './screens/health.js';
import { mountInstances, mountInstance } from './screens/instances.js';
import { mountAbout } from './screens/about.js';
import { mountMyCryndel } from './screens/mycryndel.js';
import { mountShots } from './screens/screenshots.js';
import { mountBrowser } from './screens/browser.js';
import { mountMrSettings } from './screens/modrinth-settings.js';
import { destroyWidgets, bootWidgets } from './widgets.js';
import { sound, attachUiSounds, unlockAudio, initSounds, playMusic } from './sound.js';

installMockApi();

defineRoute('/', mountHome);
defineRoute('/modrinth', mountModrinth);
defineRoute('/modrinth/settings', mountMrSettings);
defineRoute('/mods', mountMods);
defineRoute('/versions', mountVersions);
defineRoute('/build-wizard', mountWizard);
defineRoute('/instances', mountInstances);
defineRoute('/instance/:id', mountInstance);
defineRoute('/settings', mountSettings);
defineRoute('/health', mountHealth);
defineRoute('/about', mountAbout);
defineRoute('/mycryndel', mountMyCryndel);
defineRoute('/screenshots', mountShots);
defineRoute('/browser', mountBrowser);

// Register the browser:open listener at module load, not inside the async
// boot: the main process can push a URL (a popup, window.open, a "open in
// browser" click) while boot is still awaiting settings, and that message used
// to be dropped — which is why the in-app browser opened only sometimes.
if (api.browser && api.browser.onOpen) {
  api.browser.onOpen((payload) => {
    const url = typeof payload === 'string' ? payload : (payload && payload.url);
    if (url) store.pendingBrowserUrl = url;
    // If the browser is already open, hand the URL straight to it; otherwise
    // stash it and let the screen drain it on mount. Both paths guarantee the
    // in-app browser opens instead of a bare Electron window.
    if ((store.route || '') === '/browser') {
      bus.emit('browser-tab', url);
    } else {
      go('#/browser');
    }
  });
}

const NAV = [
  ['#/', 'nav.home', 'home'],
  ['#/modrinth', 'nav.modrinth', 'mr'],
  ['#/mods', 'nav.mods', 'mods'],
  ['#/screenshots', 'nav.shots', 'shots'],
  ['#/browser', 'nav.net', 'net'],
  ['#/mycryndel', 'nav.cab', 'cab'],
  ['#/instances', 'nav.instances', 'inst'],
  ['#/settings', 'nav.settings', 'gear'],
  ['#/health', 'nav.health', 'hp']
];

const NICK_RE = /^[A-Za-z0-9_]{3,20}$/;
let dlMin = false;

function paintNav() {
  const list = document.getElementById('navList');
  if (!list) return;
  list.replaceChildren();
  const route = String(store.route || '/');
  for (const [href, key, icon] of NAV) {
    const path = href.slice(1);
    const on = route === path
      || (path === '/instances' && (route === '/instances' || route.startsWith('/instance/')))
      || (path === '/modrinth' && route.startsWith('/modrinth'))
      || (path !== '/' && path !== '/modrinth' && path !== '/instances' && route.startsWith(path + '/'));
    const btn = el('button', {
      class: 'nav-item' + (on ? ' active' : ''),
      onclick: () => go(href)
    });
    btn.innerHTML = svg(icon) + '<span>' + t(key) + '</span>';
    list.appendChild(btn);
  }
}

function paintToasts() {
  const host = document.getElementById('toasts');
  if (!host) return;
  host.replaceChildren();
  for (const titem of store.toasts) {
    host.appendChild(el('div', { class: 'toast ' + titem.kind, text: titem.text }));
  }
}

function paintFoot() {
  const nick = document.getElementById('footNick');
  const lab = document.getElementById('footInstanceLab');
  if (nick) nick.textContent = store.user ? store.user.nick : t('player', 'Игрок');
  const selected = store.instances.find((i) => i.id === store.selectedId) || store.instances[0];
  if (lab) lab.textContent = selected ? selected.name : t('no.instance', 'Нет сборки');
  if (selected) store.selectedId = selected.id;
}

function paintPageTools() {
  const host = document.getElementById('pageTools');
  if (!host) return;
  host.replaceChildren();
  const route = store.route || '/';
  // Pinned quick tools belong to the home screen only — everywhere else they
  // floated over the content and got in the way.
  if (route !== '/') return;
  host.appendChild(iconBtn('pal', t('tip.customize', 'Кастомизация лаунчера'), () => go('#/settings')));
  host.appendChild(iconBtn('gear', t('tip.game', 'Настройки игры'), () => go('#/settings')));
  host.appendChild(iconBtn('folder', t('tip.folder', 'Папка сборки'), () => {
    if (store.selectedId) api.instances.openFolder(store.selectedId);
  }));
  host.appendChild(iconBtn('dl', t('tip.inbox', 'Загрузки (J)'), toggleInbox));
}

async function refreshCore() {
  store.user = await api.auth.getCurrent();
  store.instances = await api.instances.list();
  if (store.user && store.user.preferences && store.user.preferences.selectedInstanceId) {
    store.selectedId = store.user.preferences.selectedInstanceId;
  }
  if (!store.selectedId && store.instances[0]) store.selectedId = store.instances[0].id;
  paintFoot();
  paintNav();
}
window.__cryndelRefresh = refreshCore;

function fmtBytes(n) {
  const x = Number(n) || 0;
  if (x >= 1073741824) return (x / 1073741824).toFixed(1) + ' ГБ';
  if (x >= 1048576) return (x / 1048576).toFixed(1) + ' МБ';
  if (x >= 1024) return Math.round(x / 1024) + ' КБ';
  return x ? x + ' Б' : '';
}

function showDl(on) {
  const v = document.getElementById('dlDock');
  if (!v) return;
  if (on) v.classList.remove('hidden');
  else v.classList.add('hidden');
}

function setBusy(on, label) {
  const btn = document.getElementById('btnPlay');
  const lab = document.getElementById('progLabel');
  store.busy = on;
  if (btn) {
    btn.disabled = on && !store.running;
    if (store.running) {
      btn.textContent = t('playing', 'СТОП');
      btn.classList.add('stop');
    } else {
      btn.textContent = on ? 'КАЧАЮ…' : t('play', 'ИГРАТЬ').toUpperCase();
      btn.classList.remove('stop');
    }
  }
  if (lab && label) lab.textContent = label;
  if (!on && !store.running) showDl(false);
}

function applyTheme(name) {
  document.documentElement.setAttribute('data-theme', name || 'dark');
}

function paintWinState(st) {
  const winMax = document.getElementById('winMax');
  if (!winMax || !st) return;
  const maximized = Boolean(st.maximized || st.fullScreen);
  winMax.innerHTML = maximized
    ? '<svg viewBox="0 0 12 12"><rect x="2.5" y="4" width="5.5" height="5.5" fill="none" stroke="currentColor" stroke-width="1.2"/><path d="M4 4V2.5h5.5V8H8" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>'
    : '<svg viewBox="0 0 12 12"><rect x="2.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
  winMax.setAttribute('aria-label', maximized ? 'Восстановить' : 'Развернуть');
}

function applyNavPos(pos) {
  const shell = document.getElementById('shell');
  if (!shell) return;
  shell.classList.remove('nav-right', 'nav-top', 'nav-bottom');
  document.documentElement.setAttribute('data-nav', pos || 'left');
  if (pos === 'right') shell.classList.add('nav-right');
  if (pos === 'top') shell.classList.add('nav-top');
  if (pos === 'bottom') shell.classList.add('nav-bottom');
}

async function applyCustomCss() {
  const node = document.getElementById('userTheme');
  if (!node) return;
  try {
    const css = await api.theme.read();
    node.textContent = css || '';
  } catch (_) {
    node.textContent = '';
  }
}

function applyUiVars(s) {
  const ui = (s && s.ui) || {};
  const root = document.documentElement;
  if (ui.accent) root.style.setProperty('--accent', ui.accent);
  else root.style.removeProperty('--accent');
  if (ui.radius != null) root.style.setProperty('--radius', Number(ui.radius) + 'px');
  if (ui.cardRadius != null) root.style.setProperty('--card-radius', Number(ui.cardRadius) + 'px');
  const navPos = ui.navPos || 'left';
  // Only a side rail takes the width setting: the top/bottom bars size
  // themselves. The value is written to --nav-user and capped by --nav-max in
  // CSS, so the responsive breakpoints can still shrink the rail on a narrow
  // window instead of an inline style overriding them.
  if (ui.navWidth != null && (navPos === 'left' || navPos === 'right')) {
    root.style.setProperty('--nav-user', Number(ui.navWidth) + 'px');
  } else {
    root.style.removeProperty('--nav-user');
  }
  const scale = Number(ui.uiScale);
  const factor = scale > 0 ? scale / 100 : 1;
  root.style.setProperty('--ui-scale', String(factor));
  if (api.window && api.window.setZoom) api.window.setZoom(factor).catch(() => {});
  // Panel opacity and glass blur are independent knobs so the surfaces can be
  // made more (or less) transparent without touching the theme itself. A blur
  // of 0 means "leave the theme's own glass effect alone".
  const opacity = Number(ui.panelOpacity);
  root.style.setProperty('--panel-pct', (opacity > 0 ? Math.min(100, opacity) : 100) + '%');
  const blur = Number(ui.glassBlur);
  if (blur > 0) root.style.setProperty('--glass-blur', blur + 'px');
  else root.style.removeProperty('--glass-blur');
  const iconSize = Number(ui.navIconSize);
  root.style.setProperty('--nav-icon', (iconSize > 0 ? iconSize : 18) + 'px');
  root.setAttribute('data-hover-lift', ui.hoverLift === false ? 'off' : 'on');
  root.setAttribute('data-toast', ui.toastPos === 'top' ? 'top' : 'bottom');
  root.setAttribute('data-statusbar', ui.showStatusBar === false ? 'off' : 'on');
  const dim = ui.bgDim != null ? ui.bgDim : 0.55;
  root.style.setProperty('--bg-dim', String(dim));
  // Wallpaper blur: a separate knob from the panel glass so a photo background
  // can be softened without touching the surfaces.
  const bgBlur = Number(ui.bgBlur) || 0;
  root.style.setProperty('--bg-blur', bgBlur + 'px');
  root.setAttribute('data-nav-labels', ui.navLabels === false ? 'off' : 'on');
  root.setAttribute('data-dock', ui.dockPos === 'left' ? 'left' : 'right');
  root.style.setProperty('--veil-op', ui.bgVeil != null ? String(ui.bgVeil) : '1');
  // Animation speed is user-controlled so the opening reveal can be as quick
  // or as slow as the player likes.
  const dur = Number(ui.animationDuration) || 450;
  root.style.setProperty('--anim-dur', dur + 'ms');
  const animationsOn = ui.animations !== false && !ui.reducedMotion;
  root.style.setProperty('--anim-play', animationsOn ? 'running' : 'paused');
  root.setAttribute('data-anim', animationsOn ? 'on' : 'off');
  root.style.setProperty('--sound-volume', String(ui.soundVolume != null ? ui.soundVolume : 0.6));
  root.setAttribute('data-density', ui.density || 'normal');
  root.setAttribute('data-compact', ui.compact ? 'on' : 'off');
  // Adaptive header: brand text collapses and the bar tightens on a narrow
  // window, so the title bar and window buttons never collide.
  root.setAttribute('data-header', ui.headerAutoHide === false ? 'full' : 'auto');
  root.setAttribute('data-homebuttons', ui.homeButtons === false ? 'off' : 'on');
  root.setAttribute('data-glow', ui.accentGlow === false ? 'off' : 'on');
  const fonts = {
    default: '"Manrope", "Segoe UI", sans-serif',
    minecraft: '"Minecraft Ten", "Press Start 2P", monospace',
    title: '"Manrope", Impact, sans-serif',
    classic: 'Georgia, "Times New Roman", serif'
  };
  if (ui.homeFont && fonts[ui.homeFont]) root.style.setProperty('--home-font', fonts[ui.homeFont]);
  applyNavPos(ui.navPos || 'left');
  const shell = document.getElementById('shell');
  if (shell) {
    shell.classList.remove('tools-top', 'tools-bottom');
    if (ui.toolsPos === 'top') shell.classList.add('tools-top');
    if (ui.toolsPos === 'bottom') shell.classList.add('tools-bottom');
  }
}

async function applyBackground() {
  const video = document.getElementById('bgVideo');
  const image = document.getElementById('bgImage');
  if (!video || !image) return;
  const s = store.settings || {};
  const kind = (s.ui && s.ui.backgroundKind) || 'video';
  const loop = !s.ui || s.ui.bgLoop !== false;
  let vUrl = '';
  let iUrl = '';
  try { vUrl = await api.media.bgVideoUrl(); } catch (_) { /* */ }
  try { iUrl = await api.media.bgImageUrl(); } catch (_) { /* */ }
  video.pause();
  video.removeAttribute('src');
  image.classList.add('hidden');
  video.classList.add('hidden');
  if (kind !== 'image' && vUrl) {
    video.src = vUrl;
    video.muted = true;
    video.loop = loop;
    video.autoplay = true;
    video.classList.remove('hidden');
    video.play().catch(() => {});
  } else if (iUrl) {
    image.src = iUrl;
    image.classList.remove('hidden');
  }
}

function startParticles(on) {
  const c = document.getElementById('fxLayer');
  if (!c) return;
  if (c._stop) { c._stop(); c._stop = null; }
  if (!on) { c.classList.add('hidden'); return; }
  c.classList.remove('hidden');
  const ctx = c.getContext('2d');
  let bits = [];
  let raf = 0;
  function resize() { c.width = innerWidth; c.height = innerHeight; }
  resize();
  bits = Array.from({ length: 28 }, () => ({
    x: Math.random() * c.width, y: Math.random() * c.height,
    r: 1 + Math.random() * 2, s: 0.2 + Math.random() * 0.6
  }));
  function tick() {
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    for (const b of bits) {
      b.y -= b.s;
      if (b.y < -4) { b.y = c.height + 4; b.x = Math.random() * c.width; }
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.fill();
    }
    raf = requestAnimationFrame(tick);
  }
  tick();
  c._stop = () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  window.addEventListener('resize', resize);
}

async function playSelected() {
  if (store.running) {
    try { await api.game.kill(store.selectedId); } catch (_) { /* */ }
    store.running = false;
    setBusy(false, t('ready', 'Готов к игре'));
    toast('Сессия остановлена');
    return;
  }
  if (!store.user) { toast('Сначала ник', 'bad'); await runOnboarding(); return; }
  if (!store.selectedId) { go('#/build-wizard'); toast('Сначала создай сборку'); return; }
  setBusy(true, 'Готовлю запуск…');
  try {
    await api.game.launch(store.selectedId);
    store.running = true;
    setBusy(false, 'Minecraft запущен');
    toast('Minecraft запускается');
  } catch (e) {
    store.running = false;
    toast(e.message || 'Не удалось запустить', 'bad');
    setBusy(false, 'Ошибка запуска');
  }
}

function openNickModal() {
  const existing = document.getElementById('nickModal');
  if (existing) existing.remove();
  const m = modal({ kicker: 'НИК', title: 'Как тебя звать?', class: 'nick-modal' });
  m.veil.id = 'nickModal';
  const input = el('input', { class: 'field', value: store.user ? store.user.nick : '', placeholder: '3–20, латиница / цифры / _' });
  const err = el('p', { class: 'hint', style: 'color:var(--bad);min-height:18px' });
  m.body.appendChild(input);
  m.body.appendChild(err);
  const row = el('div', { class: 'row', style: 'margin-top:12px' });
  row.appendChild(el('button', { class: 'btn btn-sky', text: 'Сохранить', onclick: async () => {
    const next = input.value.trim();
    if (!NICK_RE.test(next)) { err.textContent = 'Ник: 3–20, латиница, цифры, _'; return; }
    try {
      await api.liveNick.change(next);
      await refreshCore();
      m.close();
      toast('Ник обновлён');
    } catch (e) {
      err.textContent = e.message || 'Не вышло';
    }
  } }));
  m.body.appendChild(row);
  input.focus();
}

function openInstanceMenu(anchor) {
  const items = store.instances.length
    ? store.instances.map((i) => ({
      label: i.name + ' · ' + i.mcVersion,
      active: i.id === store.selectedId,
      icon: 'inst',
      onclick: async () => {
        store.selectedId = i.id;
        try { await api.instances.select(i.id); } catch (_) { /* */ }
        paintFoot();
        if (store.route === '/') apply();
      }
    }))
    : [{ label: t('no.instance', 'Нет сборки') + ' — создать', onclick: () => go('#/build-wizard') }];
  items.push('sep');
  items.push({ label: 'Новая сборка', icon: 'plus', onclick: () => go('#/build-wizard') });
  menu(anchor, items, { place: 'up', class: 'inst-menu' });
}

function askImportMeta(suggested = {}) {
  return new Promise((resolve) => {
    const m = modal({ kicker: 'ИМПОРТ', title: 'Назови модпак', onClose: () => resolve(null) });
    const name = el('input', { class: 'field', value: suggested.suggestedName || '', placeholder: 'Название' });
    const ver = el('input', { class: 'field', value: suggested.suggestedMcVersion || '1.21.11', placeholder: 'Версия Minecraft' });
    const loader = el('select', { class: 'field' });
    for (const [id, t] of [['fabric', 'Fabric'], ['forge', 'Forge'], ['neoforge', 'NeoForge'], ['quilt', 'Quilt'], ['vanilla', 'Vanilla']]) {
      loader.appendChild(el('option', { value: id, text: t }));
    }
    loader.value = suggested.suggestedLoader || 'fabric';
    m.body.appendChild(el('label', { class: 'hint', text: 'Название' }));
    m.body.appendChild(name);
    m.body.appendChild(el('label', { class: 'hint', text: 'Версия Minecraft' }));
    m.body.appendChild(ver);
    m.body.appendChild(el('label', { class: 'hint', text: 'Загрузчик' }));
    m.body.appendChild(loader);
    const row = el('div', { class: 'row', style: 'margin-top:8px' });
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'Импортировать', onclick: () => {
      const n = name.value.trim();
      const v = ver.value.trim();
      if (!n || !v) return;
      m.close();
      resolve({ name: n, mcVersion: v, modLoader: loader.value });
    } }));
    m.body.appendChild(row);
  });
}
window.__cryndelAskImport = askImportMeta;

async function importPackSmart(filePath) {
  let res = await api.inbox.importMrpackPath(filePath);
  if (res && res.needsMeta) {
    const meta = await askImportMeta(res);
    if (!meta) return null;
    res = await api.inbox.importMrpackPath(filePath, meta);
  }
  return res;
}
window.__cryndelImportPack = importPackSmart;

function bindChrome() {
  document.getElementById('btnPlay').addEventListener('click', playSelected);
  document.getElementById('btnMods').innerHTML = svg('mods');
  tip(document.getElementById('btnMods'), t('tip.mods', 'Моды'));
  document.getElementById('btnMods').addEventListener('click', () => go('#/mods'));
  document.getElementById('btnInstance').addEventListener('click', (e) => openInstanceMenu(e.currentTarget));
  document.getElementById('btnNick').addEventListener('click', openNickModal);

  const winMin = document.getElementById('winMin');
  const winMax = document.getElementById('winMax');
  const winFull = document.getElementById('winFull');
  const winClose = document.getElementById('winClose');
  if (winMin) {
    winMin.innerHTML = '<svg viewBox="0 0 12 12"><path d="M2 6h8" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
    tip(winMin, t('tip.minimize', 'Свернуть'));
    winMin.addEventListener('click', async () => {
      try { await api.window.minimize(); } catch (_) { /* */ }
    });
  }
  if (winFull) {
    winFull.innerHTML = '<svg viewBox="0 0 12 12"><path d="M4 2H2v2M8 2h2v2M2 8v2h2M10 8v2H8" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>';
    tip(winFull, 'Во весь экран (F11)');
    winFull.addEventListener('click', async () => {
      try { paintWinState(await api.window.fullscreen()); } catch (_) { /* */ }
    });
  }
  if (winMax) {
    winMax.innerHTML = '<svg viewBox="0 0 12 12"><rect x="2.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
    tip(winMax, t('tip.maximize', 'Развернуть'));
    winMax.addEventListener('click', async () => {
      try {
        const st = await api.window.maximize();
        paintWinState(st);
      } catch (_) { /* */ }
    });
  }
  if (winClose) {
    winClose.innerHTML = '<svg viewBox="0 0 12 12"><path d="M3 3l6 6M9 3L3 9" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>';
    tip(winClose, t('tip.close', 'Закрыть'));
    winClose.addEventListener('click', async () => {
      try { await api.window.close(); } catch (_) { /* */ }
    });
  }
  // Double-clicking the title bar toggles maximise, like a native window.
  const titlebar = document.getElementById('titlebar');
  if (titlebar) {
    titlebar.addEventListener('dblclick', async (e) => {
      if (e.target.closest('.win-btns')) return;
      try { paintWinState(await api.window.maximize()); } catch (_) { /* */ }
    });
  }
  if (api.window && api.window.onState) api.window.onState(paintWinState);
  if (api.window && api.window.state) api.window.state().then(paintWinState).catch(() => {});

  const tools = document.getElementById('footTools');
  tools.replaceChildren();
  tools.appendChild(iconBtn('folder', t('tip.folder', 'Папка сборки'), () => {
    if (store.selectedId) api.instances.openFolder(store.selectedId);
  }));
  tools.appendChild(iconBtn('dl', t('tip.inbox', 'Загрузки (J)'), toggleInbox));

  const dlMinBtn = document.getElementById('dlMin');
  dlMinBtn.innerHTML = svg('chev');
  document.getElementById('dlCancel').innerHTML = svg('x');
  dlMinBtn.addEventListener('click', () => {
    dlMin = !dlMin;
    document.getElementById('dlDock').classList.toggle('min', dlMin);
  });
  document.getElementById('dlCancel').addEventListener('click', async () => {
    try { await api.game.cancel(); } catch (_) { /* */ }
    showDl(false);
    setBusy(false, 'Отменено');
    toast('Загрузка остановлена');
  });

  api.game.onProgress((p) => {
    store.progress = p;
    const pct = Math.max(0, Math.min(100, Number(p.pct) || 0));
    const bar = document.getElementById('prog');
    const label = document.getElementById('progLabel');
    if (bar) bar.style.width = pct + '%';
    if (label) label.textContent = p.message || '';
    const downloading = p.stage === 'download' || p.stage === 'java' || p.stage === 'client' || p.stage === 'pack' || p.stage === 'libraries' || p.stage === 'assets' || pct < 100;
    if (downloading && pct < 100) showDl(true);
    const dt = document.getElementById('dlTitle');
    const db = document.getElementById('dlBar');
    const dl = document.getElementById('dlLabel');
    const dx = document.getElementById('dlBytes');
    if (dt) dt.textContent = p.message || 'Загрузка';
    if (db) db.style.width = pct + '%';
    if (dl) dl.textContent = pct + '%';
    if (dx) dx.textContent = p.total ? fmtBytes(p.loaded) + ' / ' + fmtBytes(p.total) : '';
    if (pct >= 100) setTimeout(() => setBusy(false, 'Готово'), 700);
  });
  api.game.onCrash(() => {
    store.running = false;
    setBusy(false, 'Крэш');
    showDl(false);
    toast('Minecraft упал — вкладка Починка', 'bad');
  });
  api.game.onClose(() => {
    store.running = false;
    setBusy(false, t('ready', 'Готов к игре'));
    showDl(false);
    toast('Сессия завершена');
  });
  if (api.inbox && api.inbox.onSaved) api.inbox.onSaved((item) => toast('Скачано: ' + (item.name || 'файл'), 'ok'));
  if (api.inbox && api.inbox.onProgress) {
    api.inbox.onProgress((p) => {
      const pct = Math.max(0, Math.min(100, Number(p.pct) || 0));
      if (!p.failed) showDl(true);
      const db = document.getElementById('dlBar');
      const dl = document.getElementById('dlLabel');
      const dt = document.getElementById('dlTitle');
      const dx = document.getElementById('dlBytes');
      if (dt) dt.textContent = p.filename || 'Файл из интернета';
      if (db) db.style.width = pct + '%';
      if (dl) dl.textContent = pct + '%';
      if (dx) dx.textContent = p.total ? fmtBytes(p.loaded) + ' / ' + fmtBytes(p.total) : '';
      if (p.failed) {
        showDl(false);
        toast('Загрузка не удалась', 'bad');
      } else if (p.finished || pct >= 100) {
        setTimeout(() => showDl(false), 900);
      }
    });
  }

  // Settings changed in another view (or by the main process) must be reflected
  // here immediately, without a restart.
  if (api.settings && api.settings.onChanged) {
    api.settings.onChanged(async (payload) => {
      const key = payload && payload.key;
      if (!key) {
        store.settings = await api.settings.getAll();
        await applyCustomCss();
        window.__cryndelApplyUi();
        return;
      }
      store.settings = store.settings || {};
      const parts = String(key).split('.');
      let cur = store.settings;
      for (let i = 0; i < parts.length - 1; i += 1) {
        if (!cur[parts[i]] || typeof cur[parts[i]] !== 'object') cur[parts[i]] = {};
        cur = cur[parts[i]];
      }
      cur[parts[parts.length - 1]] = payload.value;
      if (String(key).startsWith('ui.')) await applyCustomCss();
      window.__cryndelApplyUi();
    });
  }

  window.addEventListener('keydown', (e) => handleHotkey(e));
  // Hotkeys pressed while a <webview> (in-app browser / cabinet) had focus are
  // forwarded by the main process, so J and F11 keep working there too.
  if (api.hotkey && api.hotkey.on) {
    api.hotkey.on((payload) => {
      if (!payload) return;
      handleHotkey({ code: payload.code, key: payload.key, location: 0, target: null, preventDefault() {} });
    });
  }
}

// The main process also forwards J/F11 while a <webview> has focus; a single
// press can arrive on both paths, which would toggle the downloads panel open
// and instantly shut again. Collapse those duplicates here.
const lastHotkey = { KeyJ: 0, F11: 0 };

function handleHotkey(e) {
  const tag = e.target && e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || (e.target && e.target.isContentEditable)) return;
  // Use physical key codes: on a Russian layout the letter keys produce
  // Cyrillic characters, so `e.key === 'j'` never matched and the hotkey
  // looked dead.
  const code = e.code;
  const now = Date.now();
  if (code === 'KeyJ' || e.key === 'j' || e.key === 'J') {
    e.preventDefault();
    if (now - lastHotkey.KeyJ < 180) return;
    lastHotkey.KeyJ = now;
    toggleInbox();
    return;
  }
  if (code === 'KeyB' || e.key === 'b' || e.key === 'B') {
    if ((store.route || '/') === '/') bus.emit('pin-shots');
    return;
  }
  if (e.key === 'Escape') { closeMenus(); return; }
  if (code === 'F11') {
    e.preventDefault();
    if (now - lastHotkey.F11 < 250) return;
    lastHotkey.F11 = now;
    api.window.fullscreen().then(paintWinState).catch(() => {});
    return;
  }
  if (e.key === 'Shift' && e.location === 1) bus.emit('furry-scale');
  if (e.key === 'Shift' && e.location === 2) {
    e.preventDefault();
    if (store.route !== '/mycryndel') go('#/mycryndel');
    else bus.emit('cabinet-settings');
  }
  if (e.key === 'Tab' && store.route === '/browser') {
    e.preventDefault();
    bus.emit('browser-tab');
  }
}

function toggleInbox() {
  let panel = document.getElementById('inboxPanel');
  if (panel) { panel.remove(); return; }
  panel = el('div', { class: 'inbox-panel', id: 'inboxPanel' });
  const head = el('div', { class: 'row', style: 'justify-content:space-between' });
  head.appendChild(el('p', { class: 'kicker', text: 'ЗАГРУЗКИ' }));
  head.appendChild(closeBtn(() => panel.remove()));
  panel.appendChild(head);
  const list = el('div');
  panel.appendChild(list);
  const row = el('div', { class: 'row', style: 'margin-top:12px' });
  row.appendChild(iconBtn('folder', 'Папка загрузок', () => api.inbox.openDir()));
  panel.appendChild(row);
  document.getElementById('inboxHost').appendChild(panel);

  async function paint() {
    const files = await api.inbox.list().catch(() => []);
    list.replaceChildren();
    if (!files.length) {
      list.appendChild(el('p', { class: 'hint', text: 'Пусто. Файлы из сети попадут сюда.' }));
      return;
    }
    for (const f of files) {
      const c = el('div', { class: 'card inbox-item' });
      c.appendChild(el('strong', { text: f.name }));
      c.appendChild(el('div', { class: 'hint', text: f.kind + ' · ' + Math.round((f.size || 0) / 1024) + ' KB' }));
      const r = el('div', { class: 'row', style: 'margin-top:8px' });
      if (f.kind === 'mod') {
        r.appendChild(el('button', { class: 'btn btn-sky', text: 'В сборку', onclick: async () => {
          if (!store.selectedId) { toast('Сначала выбери сборку', 'bad'); return; }
          try {
            await api.inbox.importToInstance(f.path, store.selectedId);
            toast('Мод перенесён');
          } catch (e) { toast(e.message, 'bad'); }
        } }));
      } else if (f.kind === 'modpack' || f.kind === 'archive') {
        r.appendChild(el('button', { class: 'btn btn-sky', text: 'Как сборку', onclick: async () => {
          try {
            const res = await importPackSmart(f.path);
            if (res && res.instance) {
              store.selectedId = res.instance.id;
              await refreshCore();
              toast('Сборка создана');
              go('#/');
            }
          } catch (e) { toast(e.message, 'bad'); }
        } }));
        r.appendChild(el('button', { class: 'btn', text: 'Ресурспак', onclick: async () => {
          if (!store.selectedId) { toast('Сначала выбери сборку', 'bad'); return; }
          try {
            await api.inbox.importAsResourcepack(f.path, store.selectedId);
            toast('ZIP в resourcepacks');
          } catch (e) { toast(e.message, 'bad'); }
        } }));
      }
      c.appendChild(r);
      list.appendChild(c);
    }
  }
  paint();
}

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function playSplash() {
  const host = document.getElementById('splash');
  if (!host) return;
  const s = store.settings || {};
  if (s.ui && s.ui.splash === false && !s.ui.alwaysSplash) return;
  host.classList.remove('hidden');
  host.replaceChildren();
  sound.splash();
  let url = '';
  try { url = await api.media.splashUrl(); } catch (_) { url = ''; }
  const custom = Number(s.ui && s.ui.splashDuration) || 0;
  if (url) {
    const v = document.createElement('video');
    v.src = url;
    v.autoplay = true;
    v.muted = true;
    v.playsInline = true;
    host.appendChild(v);
    await new Promise((resolve) => {
      const done = () => resolve();
      v.addEventListener('ended', done);
      v.addEventListener('error', done);
      setTimeout(done, custom > 0 ? custom : 8000);
      v.play().catch(done);
    });
  } else {
    host.appendChild(el('div', { class: 'splash-word', text: 'Cryndel Launcher' }));
    await wait(custom > 0 ? custom : 1400);
  }
  host.classList.add('hidden');
}

async function runOnboarding() {
  const veil = el('div', { class: 'modal-veil', id: 'onboard' });
  const box = el('div', { class: 'modal' });
  const stepHost = el('div');
  box.appendChild(stepHost);
  veil.appendChild(box);
  document.body.appendChild(veil);
  function paint(node) { stepHost.replaceChildren(node); }

  const nickBox = el('div');
  nickBox.appendChild(el('p', { class: 'kicker', text: 'CRYNDEL LAUNCHER' }));
  nickBox.appendChild(el('h2', { class: 'h2', text: 'Как тебя зовут?' }));
  const nick = el('input', { class: 'field', placeholder: 'Ник 3–20', style: 'margin:14px 0' });
  const err = el('p', { class: 'hint', style: 'color:var(--bad);min-height:18px' });
  nickBox.appendChild(nick);
  nickBox.appendChild(err);
  nickBox.appendChild(el('button', { class: 'btn btn-sky', style: 'width:100%', text: 'Дальше', onclick: () => {
    if (!NICK_RE.test(nick.value.trim())) { err.textContent = 'Ник: 3–20, латиница, цифры, _'; return; }
    askComfort(nick.value.trim());
  } }));
  paint(nickBox);
  nick.focus();

  function askComfort(name) {
    const n = el('div');
    n.appendChild(el('p', { class: 'kicker', text: 'ПОДГОТОВКА' }));
    n.appendChild(el('h2', { class: 'h2', text: 'Настроим всё для Cryndel?' }));
    const row = el('div', { class: 'row' });
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'Да, подготовь', onclick: () => askPacks(name) }));
    row.appendChild(el('button', { class: 'btn', text: 'Нет, сам', onclick: async () => {
      await api.auth.createOffline(name, { onboardingCompleted: true, surveyAnswer: 'other' });
      veil.remove();
      await refreshCore();
      await apply();
      toast('Профиль создан');
      go('#/build-wizard');
    } }));
    n.appendChild(row);
    paint(n);
  }

  async function askPacks(name) {
    const catalog = await api.catalog.comfortPacks().catch(() => ({ packs: [] }));
    const extra = await api.catalog.extraMods().catch(() => ({ mods: [] }));
    const n = el('div');
    n.appendChild(el('p', { class: 'kicker', text: 'СБОРКА' }));
    n.appendChild(el('h2', { class: 'h2', text: 'Скачать модпак?' }));
    let packId = '';
    const list = el('div');
    for (const p of catalog.packs || []) {
      const b = el('button', { class: 'btn source-opt', onclick: () => {
        packId = p.id;
        list.querySelectorAll('.source-opt').forEach((x) => x.classList.remove('picked'));
        b.classList.add('picked');
      } });
      b.appendChild(el('strong', { text: p.name, style: 'display:block' }));
      b.appendChild(el('span', { class: 'hint', text: p.tag || '' }));
      list.appendChild(b);
    }
    n.appendChild(list);
    const cryem = chk((extra.mods && extra.mods[0] && extra.mods[0].name) || 'Cryem', true);
    n.appendChild(cryem);
    const row = el('div', { class: 'row' });
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'Качать', onclick: () => goComfort(name, packId, cryem.isOn()) }));
    row.appendChild(el('button', { class: 'btn btn-ghost', text: 'Только Fabric', onclick: () => goComfort(name, '', cryem.isOn()) }));
    n.appendChild(row);
    paint(n);
  }

  async function goComfort(name, packId, cryem) {
    const n = el('div');
    n.appendChild(el('p', { class: 'kicker', text: 'УСТАНОВКА' }));
    n.appendChild(el('h2', { class: 'h2', text: 'Готовлю всё нужное' }));
    const bar = el('div', { class: 'progress', style: 'margin:12px 0' });
    const i = el('i'); i.style.width = '8%';
    bar.appendChild(i);
    const lab = el('p', { class: 'hint', text: 'Java, Fabric 1.21.11…' });
    n.appendChild(bar);
    n.appendChild(lab);
    paint(n);
    const un = api.game.onProgress((p) => {
      i.style.width = (p.pct || 0) + '%';
      lab.textContent = p.message || lab.textContent;
    });
    try {
      await api.onboard.comfort(name, { packId, cryem });
      if (typeof un === 'function') un();
      veil.remove();
      await refreshCore();
      await apply();
      toast('Готово.');
    } catch (e) {
      lab.textContent = e.message || 'Ошибка';
      lab.style.color = 'var(--bad)';
    }
  }
}

bus.on('toast', paintToasts);
bus.on('toast:new', (item) => {
  if (item && item.kind === 'bad') sound.error();
  else sound.ok();
});
bus.on('route', () => {
  const stage = document.getElementById('stage');
  const shell = document.getElementById('shell');
  const home = store.route === '/';
  if (shell) shell.classList.toggle('home-on', home);
  if (stage) {
    stage.classList.toggle('home-stage', home);
    if (store.route !== '/mycryndel' && store.route !== '/browser' && !String(store.route).startsWith('/modrinth/')) {
      stage.classList.remove('padless');
    }
  }
  paintNav();
  paintPageTools();
  destroyWidgets();
  bootWidgets();
});

async function main() {
  if (!window.cryndel) {
    document.getElementById('stage').textContent = 'preload missing';
    return;
  }
  store.settings = await api.settings.getAll();
  applyTheme((store.settings.ui && store.settings.ui.theme) || 'dark');
  applyUiVars(store.settings);
  await loadLocale((store.settings.ui && store.settings.ui.language) || 'ru');
  const play = document.getElementById('btnPlay');
  if (play) play.textContent = t('play', 'ИГРАТЬ').toUpperCase();
  const prog = document.getElementById('progLabel');
  if (prog) prog.textContent = t('ready', 'Готов к игре');
  const dk = document.getElementById('dlKicker');
  if (dk) dk.textContent = t('dl.kicker', 'ЗАГРУЗКА');
  await applyCustomCss();
  bindChrome();
  attachUiSounds();
  // Resolve the sound URLs before the splash so the opening sound is the
  // player's own file (or the synthesized fallback), not a generic beep.
  await initSounds().catch(() => {});
  await applyBackground();
  startParticles(Boolean(store.settings.ui && store.settings.ui.particles));
  await refreshCore();
  const always = store.settings.ui && store.settings.ui.alwaysSplash;
  if (!store.user || always) await playSplash();
  bootRouter();
  if (!store.user) await runOnboarding();
  window.addEventListener('pointerdown', unlockAudio, { once: true });
  window.addEventListener('keydown', unlockAudio, { once: true });
  // Autoplay needs a user gesture on first run; retry on the first interaction
  // so the playlist starts as soon as the player touches anything.
  if (store.settings.ui && store.settings.ui.musicAutoplay !== false) {
    const kick = () => { playMusic({}); window.removeEventListener('pointerdown', kick); };
    window.addEventListener('pointerdown', kick, { once: true });
  }
}

window.__cryndelApplyUi = () => {
  applyTheme((store.settings.ui && store.settings.ui.theme) || 'dark');
  applyUiVars(store.settings);
  applyBackground();
  startParticles(Boolean(store.settings.ui && store.settings.ui.particles));
};

// Settings → "Пройти обучение заново": clears the flag for the current profile
// and replays the first-run flow without a restart.
window.__cryndelRedoOnboarding = async () => {
  try {
    if (store.user) await api.auth.patchCurrent({ onboardingCompleted: false });
  } catch (_) { /* */ }
  const stale = document.getElementById('onboard');
  if (stale) stale.remove();
  await runOnboarding();
};

main().catch((err) => {
  console.error(err);
  toast(String(err.message || err), 'bad');
});
