import { store, bus } from './state.js';

const routes = [];

export function defineRoute(path, mount) {
  routes.push({ path, mount });
}

function match(hash) {
  const raw = (hash || '#/').replace(/^#/, '') || '/';
  const path = raw.split('?')[0];
  for (const r of routes) {
    const keys = [];
    const re = new RegExp('^' + r.path.replace(/:([^/]+)/g, (_, k) => {
      keys.push(k);
      return '([^/]+)';
    }) + '$');
    const m = path.match(re);
    if (m) {
      const params = {};
      keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      return { route: r, params, path };
    }
  }
  return { route: routes.find((x) => x.path === '/') || routes[0], params: {}, path };
}

export async function go(path) {
  if (!path.startsWith('#') && !path.startsWith('/')) path = '/' + path;
  const hash = path.startsWith('#') ? path : '#' + path;
  if (location.hash !== hash) location.hash = hash;
  else await apply();
}

export async function apply() {
  const { route, params, path } = match(location.hash);
  store.route = path;
  bus.emit('route', path);
  const root = document.getElementById('stage');
  if (!root || !route) return;
  if (typeof root._off === 'function') {
    try { root._off(); } catch (_) { /* */ }
    root._off = null;
  }
  if (typeof root._offCab === 'function') {
    try { root._offCab(); } catch (_) { /* */ }
    root._offCab = null;
  }
  if (typeof root._offBrowser === 'function') {
    try { root._offBrowser(); } catch (_) { /* */ }
    root._offBrowser = null;
  }
  root.classList.remove('padless');
  root.replaceChildren();
  await route.mount(root, params);
}

export function bootRouter() {
  window.addEventListener('hashchange', () => apply());
  if (!location.hash) location.hash = '#/';
  else apply();
}
