export const api = window.cryndel;
