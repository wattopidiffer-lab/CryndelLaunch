const ModrinthHarbor = require('../../electron/managers/modrinth-client');

describe('ModrinthHarbor.search facets', () => {
  test('builds AND facets', async () => {
    const client = new ModrinthHarbor();
    const captured = [];
    client.request = async (method, url, opts) => {
      captured.push({ method, url, opts });
      return { hits: [], total_hits: 0 };
    };
    await client.search({ query: 'sodium', type: 'mod', loader: 'fabric', mcVersion: '1.21.4' });
    expect(captured[0].url).toBe('/search');
    const facets = JSON.parse(captured[0].opts.params.facets);
    expect(facets).toEqual([
      ['project_type:mod'],
      ['categories:fabric'],
      ['versions:1.21.4']
    ]);
  });
});
