const os = require('os');
const path = require('path');
const fs = require('fs-extra');
const vault = require('../../electron/storage/json-db');

describe('AtomJsonVault', () => {
  const dir = path.join(os.tmpdir(), 'cryndel-jsondb-test');
  const file = path.join(dir, 'doc.json');

  beforeEach(async () => {
    await fs.remove(dir);
    await fs.ensureDir(dir);
  });

  test('writes and reads atomically', async () => {
    await vault.write(file, { a: 1 });
    const got = await vault.read(file);
    expect(got.a).toBe(1);
  });

  test('patch mutates', async () => {
    await vault.write(file, { n: 1 });
    await vault.patch(file, (d) => { d.n += 1; return d; });
    const got = await vault.read(file);
    expect(got.n).toBe(2);
  });

  test('fallback when missing', async () => {
    const f = path.join(dir, 'missing.json');
    const got = await vault.read(f, { ok: true });
    expect(got.ok).toBe(true);
  });
});
