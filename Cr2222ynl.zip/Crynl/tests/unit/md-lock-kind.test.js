const os = require('os');
const path = require('path');
const AdmZip = require('adm-zip');

const dir = path.join(os.tmpdir(), 'cryndel-pack-kind');
process.env.CRYNDEL_HOME = dir;

const LedgerKeeper = require('../../electron/managers/lockfile-manager');

describe('LedgerKeeper.detectKind', () => {
  const keeper = new LedgerKeeper();

  test('detects mrpack index', () => {
    const zip = new AdmZip();
    zip.addFile('modrinth.index.json', Buffer.from('{}'));
    expect(keeper.detectKind('x.mrpack', zip)).toBe('mrpack');
  });

  test('detects resourcepack', () => {
    const zip = new AdmZip();
    zip.addFile('pack.mcmeta', Buffer.from('{}'));
    expect(keeper.detectKind('rp.zip', zip)).toBe('resourcepack');
  });

  test('mods folder wins over pack.mcmeta', () => {
    const zip = new AdmZip();
    zip.addFile('pack.mcmeta', Buffer.from('{}'));
    zip.addFile('mods/sodium.jar', Buffer.from('x'));
    expect(keeper.detectKind('pack.zip', zip)).toBe('modpack-zip');
  });

  test('plain zip asks for meta instead of defaulting 1.21.4', async () => {
    const zip = new AdmZip();
    zip.addFile('mods/foo.jar', Buffer.from('x'));
    const tmp = path.join(dir, 'plain.zip');
    await require('fs-extra').ensureDir(dir);
    zip.writeZip(tmp);
    const parsed = await keeper.parseMrpack(tmp);
    expect(parsed.index.needsMeta).toBe(true);
    expect(parsed.index.dependencies.minecraft).toBe('');
  });
});
