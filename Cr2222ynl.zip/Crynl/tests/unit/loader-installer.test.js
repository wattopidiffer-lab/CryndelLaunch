const LoomBinder = require('../../electron/managers/loader-installer');

describe('LoomBinder', () => {
  const loom = new LoomBinder();

  test('fabric profile id format', () => {
    expect(loom.profileId('1.21.4', '0.16.9')).toBe('fabric-loader-0.16.9-1.21.4');
  });

  test('buildFabricProfile has inheritsFrom and mainClass', () => {
    const json = loom.buildFabricProfile('1.21.4', '0.16.9', {
      loader: { maven: 'net.fabricmc:fabric-loader:0.16.9' },
      intermediary: { maven: 'net.fabricmc:intermediary:1.21.4' },
      launcherMeta: {
        mainClass: { client: 'net.fabricmc.loader.impl.launch.knot.KnotClient' },
        arguments: { game: [], jvm: [] },
        libraries: { common: [], client: [] }
      }
    });
    expect(json.inheritsFrom).toBe('1.21.4');
    expect(json.mainClass).toContain('KnotClient');
    expect(json.libraries.length).toBeGreaterThan(0);
  });
});
