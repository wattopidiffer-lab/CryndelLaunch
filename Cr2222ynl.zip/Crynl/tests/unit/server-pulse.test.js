const net = require('net');
const { queryServer, pingHost } = require('../../electron/managers/server-pulse');

function writeVarInt(value) {
  const bytes = [];
  let v = value >>> 0;
  do {
    let b = v & 0x7f;
    v >>>= 7;
    if (v !== 0) b |= 0x80;
    bytes.push(b);
  } while (v !== 0);
  return Buffer.from(bytes);
}

function writeString(str) {
  const data = Buffer.from(str, 'utf8');
  return Buffer.concat([writeVarInt(data.length), data]);
}

function packet(id, payload) {
  const body = Buffer.concat([writeVarInt(id), payload]);
  return Buffer.concat([writeVarInt(body.length), body]);
}

// Minimal server-list-ping responder so we exercise the real socket path.
function fakeServer(status, opts = {}) {
  return new Promise((resolve) => {
    const sockets = [];
    const srv = net.createServer((sock) => {
      sockets.push(sock);
      sock.on('data', () => {
        if (opts.silent) return;
        const json = JSON.stringify(status);
        sock.write(packet(0x00, writeString(json)));
      });
      sock.on('error', () => { /* */ });
    });
    srv.listen(0, '127.0.0.1', () => {
      resolve({
        port: srv.address().port,
        close: () => new Promise((r) => {
          for (const s of sockets) { try { s.destroy(); } catch (_) { /* */ } }
          srv.close(() => r());
        })
      });
    });
  });
}

describe('queryServer', () => {
  test('reads players, ping and version from a live server', async () => {
    const srv = await fakeServer({
      version: { name: 'Paper 1.21.11', protocol: 767 },
      players: { online: 42, max: 200 },
      description: { text: 'Cryndel' }
    });
    try {
      const res = await queryServer('127.0.0.1', srv.port, 2000);
      expect(res.online).toBe(true);
      expect(res.players).toEqual({ online: 42, max: 200 });
      expect(res.version).toBe('Paper 1.21.11');
      expect(typeof res.ms).toBe('number');
      expect(res.maintenance).toBe(false);
    } finally {
      await srv.close();
    }
  });

  test('flags maintenance when the MOTD says so', async () => {
    const srv = await fakeServer({
      version: { name: '1.21.11' },
      players: { online: 0, max: 100 },
      description: { text: '§cТехнические работы' }
    });
    try {
      const res = await queryServer('127.0.0.1', srv.port, 2000);
      expect(res.online).toBe(true);
      expect(res.maintenance).toBe(true);
    } finally {
      await srv.close();
    }
  });

  test('reads maintenance from a nested extra MOTD component', async () => {
    const srv = await fakeServer({
      players: { online: 1, max: 10 },
      description: { text: 'Cryndel', extra: [{ text: ' — ' }, { text: 'Тех работы' }] }
    });
    try {
      const res = await queryServer('127.0.0.1', srv.port, 2000);
      expect(res.maintenance).toBe(true);
      expect(res.motd).toContain('Cryndel');
    } finally {
      await srv.close();
    }
  });

  test('reports offline when nothing answers', async () => {
    const srv = await fakeServer({}, { silent: true });
    try {
      const res = await queryServer('127.0.0.1', srv.port, 700);
      expect(res.online).toBe(false);
      expect(res.maintenance).toBe(false);
    } finally {
      await srv.close();
    }
  });

  test('pingHost still reports a raw open port as online', async () => {
    const srv = await fakeServer({});
    try {
      const res = await pingHost('127.0.0.1', srv.port, 1500);
      expect(res.online).toBe(true);
      expect(typeof res.ms).toBe('number');
    } finally {
      await srv.close();
    }
  });
});
