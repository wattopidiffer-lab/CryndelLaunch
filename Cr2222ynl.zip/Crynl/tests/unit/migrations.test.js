const { migrateUsers, migrateInstances, migrateSettings } = require('../../electron/storage/migrations');

describe('migrations', () => {
  test('users v1 to v2', () => {
    const next = migrateUsers({ version: 1, users: [{ nick: 'A' }] });
    expect(next.version).toBe(2);
    expect(next.users[0].stats).toBeTruthy();
  });

  test('instances array to doc', () => {
    const next = migrateInstances([{ id: 'i', name: 'x' }]);
    expect(next.version).toBe(2);
    expect(next.instances[0].quickPlay).toBeTruthy();
  });

  test('settings merge keeps unknown', () => {
    const next = migrateSettings({ ui: { language: 'en' } });
    expect(next.version).toBe(10);
    expect(next.ui.language).toBe('en');
    expect(next.modrinth.enabled).toBe(true);
    // New interface/game knobs land with sane defaults so nothing reads undefined.
    expect(next.ui.density).toBe('normal');
    expect(next.ui.uiScale).toBe(100);
    expect(next.game.rawMouseInput).toBe(true);
    expect(next.ui.glassBlur).toBe(0);
    expect(next.game.smoothLighting).toBe(true);
    expect(next.game.clouds).toBe('default');
    expect(next.game.pauseOnLostFocus).toBe(true);
    expect(next.game.mouseSensitivityPct).toBe(100);
    expect(next.game.skinModel).toBe('default');
    expect(next.ui.navLabels).toBe(true);
    expect(next.ui.bgBlur).toBe(0);
    expect(next.ui.toastDuration).toBe(4200);
    expect(next.ui.dockPos).toBe('right');
    expect(next.ui.headerAutoHide).toBe(true);
    expect(next.ui.greetingEnabled).toBe(true);
    expect(next.ui.pluginsEnabled).toBe(true);
    expect(next.ui.homeButtons).toBe(true);
  });

  test('legacy tray-hide default becomes minimise, with restore on exit', () => {
    const next = migrateSettings({ version: 5, launcher: { hideToTrayOnLaunch: true, minimizeToTray: true } });
    expect(next.launcher.hideToTrayOnLaunch).toBe(false);
    expect(next.launcher.showOnGameExit).toBe(true);
    expect(next.game.autoAddServer).toBe(true);
  });

  test('legacy 80% browser zoom is reset to 100%', () => {
    const next = migrateSettings({ version: 3, browser: { zoom: 80 }, cabinet: { zoom: 80 } });
    expect(next.browser.zoom).toBe(100);
    expect(next.cabinet.zoom).toBe(100);
  });

  test('a deliberate zoom choice is preserved', () => {
    const next = migrateSettings({ version: 3, browser: { zoom: 125 } });
    expect(next.browser.zoom).toBe(125);
  });
});
