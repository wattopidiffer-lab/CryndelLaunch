const fs = require('fs-extra');
const os = require('os');
const path = require('path');
const { buildServersDat, readServersDat } = require('../../electron/utils/nbt');

let tmp;

beforeEach(async () => {
  tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'cryndel-nbt-'));
  process.env.CRYNDEL_HOME = tmp;
});

afterEach(async () => {
  if (tmp) await fs.remove(tmp);
});

describe('servers.dat NBT', () => {
  test('round-trips a server list', () => {
    const buf = buildServersDat([
      { name: 'Cryndel.ru', ip: 'cryndel.ru:25565' },
      { name: 'Test', ip: '1.2.3.4:25565' }
    ]);
    const back = readServersDat(buf);
    expect(back).toHaveLength(2);
    expect(back[0]).toEqual({ name: 'Cryndel.ru', ip: 'cryndel.ru:25565', acceptTextures: true });
    expect(back[1].name).toBe('Test');
  });

  test('loads and merges cryndel.ru without dropping player servers', async () => {
    const EmberPilot = require('../../electron/managers/game-launcher');
    const pilot = new EmberPilot({ settings: { get: async () => null, getAll: async () => ({}) } });
    const gameDir = path.join(tmp, 'inst');
    await fs.ensureDir(gameDir);

    await pilot.writeServersDat(gameDir, { quickPlay: { server: 'cryndel.ru', port: 25565 } });
    const first = readServersDat(await fs.readFile(path.join(gameDir, 'servers.dat')));
    // Vanilla omits the default port from the stored address.
    expect(first.map((s) => s.ip)).toEqual(['cryndel.ru']);

    // A player adds their own server, then we launch again.
    await fs.writeFile(path.join(gameDir, 'servers.dat'), buildServersDat([
      { name: 'My Server', ip: '10.0.0.1:25565' }
    ]));
    await pilot.writeServersDat(gameDir, { quickPlay: { server: 'cryndel.ru', port: 25565 } });
    const merged = readServersDat(await fs.readFile(path.join(gameDir, 'servers.dat')));
    const ips = merged.map((s) => s.ip);
    expect(ips[0]).toBe('cryndel.ru');
    expect(ips).toContain('10.0.0.1:25565');
    expect(ips.filter((i) => i === 'cryndel.ru')).toHaveLength(1);
  });

  test('honours a non-default port', async () => {
    const EmberPilot = require('../../electron/managers/game-launcher');
    const pilot = new EmberPilot({ settings: { get: async () => null, getAll: async () => ({}) } });
    const gameDir = path.join(tmp, 'inst2');
    await fs.ensureDir(gameDir);
    await pilot.writeServersDat(gameDir, { quickPlay: { server: 'cryndel.ru', port: 25566 } });
    const list = readServersDat(await fs.readFile(path.join(gameDir, 'servers.dat')));
    expect(list[0].ip).toBe('cryndel.ru:25566');
  });

  test('ignores a corrupt existing file instead of throwing', async () => {
    const EmberPilot = require('../../electron/managers/game-launcher');
    const pilot = new EmberPilot({ settings: { get: async () => null, getAll: async () => ({}) } });
    const gameDir = path.join(tmp, 'inst3');
    await fs.ensureDir(gameDir);
    await fs.writeFile(path.join(gameDir, 'servers.dat'), Buffer.from('not gzip at all'));
    await pilot.writeServersDat(gameDir, { quickPlay: { server: 'cryndel.ru', port: 25565 } });
    const list = readServersDat(await fs.readFile(path.join(gameDir, 'servers.dat')));
    expect(list.map((s) => s.ip)).toEqual(['cryndel.ru']);
  });
});
