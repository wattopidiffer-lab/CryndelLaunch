// Regression guard for the "launcher exits right after 'kernel ready'" bug.
//
// `app.on('browser-window-created')` fires *synchronously* from inside
// `new BrowserWindow()`, so `panes.win` is still null while the launcher's own
// window is being constructed. The old guard only compared `win === panes.win`,
// so it treated the main window as a stray popup, destroyed it ~30 ms later,
// and Electron quit with no windows left.
//
// These tests drive the real guard module (electron/popup-guard.js) and the real
// PaneSmith against a fake `electron`, so the ordering bug cannot return.
const path = require('path');

const mockCreated = [];
const mockDestroyed = [];
let mockCreatedHandler = null;

jest.mock('electron', () => {
  class FakeBrowserWindow {
    constructor() {
      mockCreated.push(this);
      this.dead = false;
      this.hidden = false;
      this.webContents = {
        on: () => {},
        once: () => {},
        send: () => {},
        setWindowOpenHandler: () => {},
        getURL: () => ''
      };
      // Electron emits browser-window-created while the constructor is still on
      // the stack, and passes (event, window).
      if (mockCreatedHandler) mockCreatedHandler({ sender: null }, this);
    }

    loadFile() {}
    once() {}
    on() {}
    isDestroyed() { return this.dead; }
    isMinimized() { return false; }
    isVisible() { return !this.hidden; }
    isMaximized() { return false; }
    isFullScreen() { return false; }
    show() { this.hidden = false; }
    hide() { this.hidden = true; }
    focus() {}
    moveTop() {}
    minimize() {}
    restore() {}
    maximize() {}
    unmaximize() {}
    setFullScreen() {}
    setSkipTaskbar() {}
    destroy() { this.dead = true; mockDestroyed.push(this); }
  }

  return {
    BrowserWindow: FakeBrowserWindow,
    app: {
      on: (ev, cb) => { if (ev === 'browser-window-created') mockCreatedHandler = cb; }
    },
    session: {}
  };
});

const PaneSmith = require('../../electron/window-manager');
const { installPopupGuard } = require('../../electron/popup-guard');

function makeKernel() {
  const panes = new PaneSmith();
  const routed = [];
  installPopupGuard({
    app: require('electron').app,
    panes,
    routeToBrowser: (url) => routed.push(url)
  });
  return { panes, routed };
}

const tick = () => new Promise((r) => setTimeout(r, 60));

describe('popup guard does not kill the launcher window', () => {
  beforeEach(() => {
    mockCreated.length = 0;
    mockDestroyed.length = 0;
    mockCreatedHandler = null;
  });

  test('main window survives its own construction', async () => {
    const kernel = makeKernel();
    const win = kernel.panes.create();

    expect(win).toBe(kernel.panes.win);
    expect(win.isDestroyed()).toBe(false);

    await tick();
    expect(win.isDestroyed()).toBe(false);
    expect(mockDestroyed).toHaveLength(0);
  });

  test('the creating flag is cleared once the window exists', () => {
    const kernel = makeKernel();
    kernel.panes.create();
    expect(kernel.panes.creating).toBe(false);
  });

  test('a window recreated after the game closes also survives', async () => {
    const kernel = makeKernel();
    kernel.panes.create();
    kernel.panes.win = null; // simulated close (closeOnLaunch)

    const again = kernel.panes.create();
    await tick();
    expect(again.isDestroyed()).toBe(false);
    expect(mockDestroyed).toHaveLength(0);
  });

  test('a genuine popup is still destroyed', async () => {
    const kernel = makeKernel();
    kernel.panes.create();

    const popup = new (require('electron').BrowserWindow)();
    expect(popup.isDestroyed()).toBe(false);
    await tick();
    expect(popup.isDestroyed()).toBe(true);
  });

  test('a popup that reports an http URL is routed into the in-app browser', async () => {
    const kernel = makeKernel();
    kernel.panes.create();

    const popup = new (require('electron').BrowserWindow)();
    popup.webContents.getURL = () => 'https://modrinth.com/mod/sodium';
    await tick();

    expect(popup.isDestroyed()).toBe(true);
    expect(kernel.routed).toContain('https://modrinth.com/mod/sodium');
  });

  test('the launcher icon path exists in the repo', () => {
    const fs = require('fs');
    const icon = path.join(__dirname, '..', '..', 'assets', 'icon.png');
    expect(fs.existsSync(icon)).toBe(true);
  });
});
