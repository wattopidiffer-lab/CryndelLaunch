const { BrowserWindow } = require('electron');
const path = require('path');

class PaneSmith {
  constructor() {
    this.win = null;
    // Set by main.js so every popup goes through one funnel (with queueing).
    this.onOpenUrl = null;
    // `browser-window-created` is emitted synchronously while `new BrowserWindow()`
    // is still on the stack, so `this.win` is not assigned yet when main.js's
    // popup guard runs. This flag lets that guard recognise the launcher's own
    // window during construction — without it the main window was treated as a
    // stray popup and destroyed 30 ms after creation, and the app then quit.
    this.creating = false;
  }

  create() {
    this.creating = true;
    try {
      this.win = new BrowserWindow({
        width: 1440,
        height: 900,
        minWidth: 760,
        minHeight: 520,
        backgroundColor: '#07080c',
        show: false,
        autoHideMenuBar: true,
        frame: false,
        titleBarStyle: 'hidden',
        title: 'Cryndel Launcher',
        icon: path.join(__dirname, '..', 'assets', 'icon.png'),
        webPreferences: {
          preload: path.join(__dirname, 'preload.js'),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: false,
          webviewTag: true,
          webSecurity: true,
          partition: 'persist:cryndel'
        }
      });
    } finally {
      this.creating = false;
    }
    this.win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
    this.win.once('ready-to-show', () => this.win.show());

    // Keep the renderer in sync with the real window state so the title-bar
    // buttons always reflect reality (maximized glyph, etc.).
    for (const ev of ['maximize', 'unmaximize', 'minimize', 'restore', 'show', 'hide', 'enter-full-screen', 'leave-full-screen']) {
      this.win.on(ev, () => this.sendState());
    }

    this.win.on('closed', () => { this.win = null; });
    // Hotkeys must keep working while a page is focused inside the in-app
    // browser or the my.cryndel cabinet: a <webview> swallows the keydown, so
    // the renderer never saw J (Downloads) or F11 (fullscreen) there.
    this.win.webContents.on('did-attach-webview', (_e, wc) => {
      wc.on('before-input-event', (_ev, input) => {
        if (input.type !== 'keyDown') return;
        const code = input.code || '';
        const key = input.key || '';
        const isHotkey = code === 'KeyJ' || key === 'j' || key === 'J'
          || code === 'KeyB' || key === 'b' || key === 'B'
          || code === 'F11' || key === 'F11' || key === 'Escape';
        if (!isHotkey) return;
        if (this.win && !this.win.isDestroyed()) {
          try { this.win.webContents.send('hotkey', { code, key }); } catch (_) { /* */ }
        }
      });
    });

    this.win.webContents.setWindowOpenHandler(({ url }) => {
      if (this.onOpenUrl) this.onOpenUrl(url);
      else if (/^https?:\/\//i.test(url)) this.win.webContents.send('browser:open', url);
      return { action: 'deny' };
    });
    if (process.argv.includes('--dev')) this.win.webContents.openDevTools({ mode: 'detach' });
    return this.win;
  }

  sendState() {
    if (!this.win || this.win.isDestroyed()) return;
    try {
      this.win.webContents.send('window:state', this.state());
    } catch (_) { /* renderer gone */ }
  }

  state() {
    if (!this.win || this.win.isDestroyed()) {
      return { maximized: false, minimized: false, visible: false };
    }
    return {
      maximized: this.win.isMaximized(),
      minimized: this.win.isMinimized(),
      fullScreen: this.win.isFullScreen(),
      visible: this.win.isVisible()
    };
  }

  all() {
    return BrowserWindow.getAllWindows();
  }

  minimize() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.minimize();
    return this.state();
  }

  // While a game session runs the launcher drops off the taskbar entirely (the
  // way most launchers behave) but stays alive, so it can be revealed the moment
  // Minecraft exits. show() clears the flag again.
  hideFromTaskbar() {
    if (!this.win || this.win.isDestroyed()) return null;
    try { this.win.setSkipTaskbar(true); } catch (_) { /* linux */ }
    this.win.minimize();
    this.sendState();
    return this.state();
  }

  toggleMaximize() {
    if (!this.win || this.win.isDestroyed()) return null;
    if (this.win.isMaximized()) this.win.unmaximize();
    else this.win.maximize();
    this.sendState();
    return this.state();
  }

  toggleFullScreen() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.setFullScreen(!this.win.isFullScreen());
    this.sendState();
    return this.state();
  }

  hide() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.hide();
    this.sendState();
    return this.state();
  }

  close() {
    if (!this.win || this.win.isDestroyed()) return null;
    this.win.close();
    return { ok: true };
  }

  // Bring the launcher back after the game exits. `restore()` only helps when
  // the window is minimised, so also clear the skip-taskbar flag that Windows
  // may keep after a tray hide, otherwise the window stays invisible.
  show() {
    if (!this.win || this.win.isDestroyed()) return null;
    try { this.win.setSkipTaskbar(false); } catch (_) { /* linux */ }
    // Leave fullscreen before restoring: a window that went fullscreen for the
    // game could not be brought back with show()/focus() alone.
    try { if (this.win.isFullScreen()) this.win.setFullScreen(false); } catch (_) { /* */ }
    if (this.win.isMinimized()) this.win.restore();
    if (!this.win.isVisible()) this.win.show();
    try { this.win.moveTop(); } catch (_) { /* some platforms */ }
    this.win.focus();
    this.sendState();
    return this.win;
  }
}

module.exports = PaneSmith;
