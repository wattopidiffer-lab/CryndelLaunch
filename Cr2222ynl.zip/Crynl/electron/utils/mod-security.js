const fs = require('fs-extra');
const path = require('path');
const AdmZip = require('adm-zip');

// Heuristic scan of a mod jar for code that has no business being in a
// Minecraft mod: process spawning, reflection-based class loading, raw socket
// clients and obfuscated payloads. This is a best-effort signal, not a
// sandbox — the launcher only warns, it never silently runs unknown code.
const PATTERNS = [
  { re: /java\/lang\/Runtime/, label: 'Runtime.exec (запуск процессов)', severity: 'high' },
  { re: /ProcessBuilder/, label: 'ProcessBuilder (запуск процессов)', severity: 'high' },
  { re: /Runtime\.getRuntime/, label: 'Runtime.getRuntime', severity: 'high' },
  { re: /URLClassLoader/, label: 'URLClassLoader (загрузка кода из сети)', severity: 'high' },
  { re: /defineClass/, label: 'ClassLoader.defineClass (динамический код)', severity: 'high' },
  { re: /javax?\/script/, label: 'ScriptEngine (выполнение скриптов)', severity: 'medium' },
  { re: /java\/net\/Socket/, label: 'Сырой Socket', severity: 'low' },
  { re: /java\/net\/URL/, label: 'Сетевые запросы (URL)', severity: 'low' },
  { re: /Base64/, label: 'Base64 (возможная обфускация)', severity: 'low' },
  { re: /java\/lang\/reflect/, label: 'Рефлексия', severity: 'low' }
];

const ALLOWED_HOSTS = [
  'cryndel.ru', 'api.cryndel.ru', 'my.cryndel.ru', 'play.cryndel.ru',
  'modrinth.com', 'cdn.modrinth.com', 'github.com', 'raw.githubusercontent.com',
  'objects.githubusercontent.com', 'minecraft.net', 'mojang.com', 'piston-data.mojang.com'
];

const URL_RE = /https?:\/\/([a-z0-9.-]+\.[a-z]{2,})/gi;

class ModSecurityScanner {
  async scan(filePath) {
    const abs = path.resolve(filePath);
    if (!(await fs.pathExists(abs))) return { ok: false, error: 'Файл не найден' };
    const findings = [];
    const hosts = new Set();
    let classes = 0;
    try {
      const zip = new AdmZip(abs);
      const entries = zip.getEntries();
      for (const entry of entries) {
        if (entry.isDirectory) continue;
        const name = entry.entryName;
        if (!/\.(class|jar)$/i.test(name)) continue;
        classes += 1;
        let text = '';
        try {
          text = entry.getData().toString('latin1');
        } catch (_) {
          continue;
        }
        for (const p of PATTERNS) {
          if (p.re.test(text)) {
            findings.push({ where: name, label: p.label, severity: p.severity });
          }
        }
        let m;
        URL_RE.lastIndex = 0;
        while ((m = URL_RE.exec(text)) !== null) {
          hosts.add(m[1].toLowerCase());
        }
      }
    } catch (err) {
      return { ok: false, error: 'Не удалось прочитать jar: ' + err.message };
    }
    const foreignHosts = [...hosts].filter((h) => !ALLOWED_HOSTS.some((a) => h === a || h.endsWith(`.${a}`)));
    const high = findings.filter((f) => f.severity === 'high');
    return {
      ok: high.length === 0,
      file: abs,
      classes,
      findings,
      hosts: [...hosts],
      foreignHosts,
      risk: high.length ? 'high' : (findings.length ? 'low' : 'none'),
      message: high.length
        ? `Найдено ${high.length} опасных совпадений (${high.map((f) => f.label).join(', ')})`
        : (findings.length ? 'Подозрительных совпадений нет, но есть сетевой код' : 'Чисто')
    };
  }
}

module.exports = new ModSecurityScanner();
