const fs = require('fs-extra');
const path = require('path');
const AdmZip = require('adm-zip');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

// `.mpcryn` is the launcher's own build container: a zip holding a
// `build.mpcryn.json` manifest plus every file from the instance folder (mods,
// configs, worlds, resourcepacks, options.txt). Publishing produces one file
// that can be dropped into "Publsborka" on another machine and imported back.
const MANIFEST_NAME = 'build.mpcryn.json';
const CONTAINER_VERSION = 1;

function safeRel(root, file) {
  return path.relative(root, file).split(path.sep).join('/');
}

class PackPublisher {
  constructor({ instances } = {}) {
    this.instances = instances;
  }

  async publish(instanceId, destPath) {
    const inst = await this.instances.get(instanceId);
    if (!inst) throw new Error('Сборка не найдена');
    const root = inst.gameDir;
    if (!await fs.pathExists(root)) throw new Error('Папка сборки не найдена');
    const manifest = {
      container: CONTAINER_VERSION,
      kind: 'mpcryn',
      id: inst.id,
      name: inst.name,
      mcVersion: inst.mcVersion,
      modLoader: inst.modLoader,
      loaderVersion: inst.loaderVersion || '',
      memoryMb: inst.memoryMb || 4096,
      created: new Date().toISOString(),
      launcher: 'Cryndel',
      language: inst.language || '',
      addServer: inst.addServer !== false,
      serverHost: inst.serverHost || 'cryndel.ru',
      serverPort: Number(inst.serverPort) || 25565
    };
    const zip = new AdmZip();
    zip.addFile(MANIFEST_NAME, Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'));
    await this.walk(root, root, zip);
    const target = destPath || path.join(CryndelPathVault.downloadsDir(), `${inst.name}.mpcryn`);
    await fs.ensureDir(path.dirname(target));
    zip.writeZip(target);
    logger.info('published build', { target, name: inst.name });
    return { ok: true, path: target, manifest };
  }

  async walk(root, dir, zip) {
    const names = await fs.readdir(dir).catch(() => []);
    for (const name of names) {
      const full = path.join(dir, name);
      const st = await fs.stat(full).catch(() => null);
      if (!st) continue;
      if (st.isDirectory()) {
        // Skip transient runtime folders that only bloat the archive.
        if (name === 'logs' || name === 'crash-reports') continue;
        await this.walk(root, full, zip);
      } else {
        const rel = safeRel(root, full);
        if (rel === MANIFEST_NAME) continue;
        zip.addLocalFile(full, path.dirname(rel) === '.' ? '' : path.dirname(rel));
      }
    }
  }

  // Reads a .mpcryn and returns its manifest without touching disk, so the UI
  // can ask for a name/version before importing.
  async inspect(filePath) {
    const zip = new AdmZip(filePath);
    const entry = zip.getEntry(MANIFEST_NAME);
    if (!entry) throw new Error('Это не .mpcryn: нет ' + MANIFEST_NAME);
    const manifest = JSON.parse(entry.getData().toString('utf8'));
    if (manifest.kind !== 'mpcryn') throw new Error('Неизвестный тип контейнера');
    return manifest;
  }

  // Extracts a container into a fresh instance folder. The caller supplies the
  // (already uniquified) name so the folder matches the pack name.
  async extract(filePath, instance, onProgress) {
    const zip = new AdmZip(filePath);
    const root = instance.gameDir;
    await fs.ensureDir(root);
    const entries = zip.getEntries();
    let done = 0;
    for (const entry of entries) {
      if (entry.entryName === MANIFEST_NAME) continue;
      const rel = entry.entryName.split('/').filter((p) => p && p !== '..').join(path.sep);
      if (!rel) continue;
      const dest = path.join(root, rel);
      if (!dest.startsWith(root + path.sep) && dest !== root) continue;
      if (entry.isDirectory) await fs.ensureDir(dest);
      else {
        await fs.ensureDir(path.dirname(dest));
        await fs.writeFile(dest, entry.getData());
      }
      done += 1;
      if (onProgress && entries.length) {
        onProgress({ pct: Math.round((done / entries.length) * 100), message: 'Распаковка ' + path.basename(rel) });
      }
    }
    return { ok: true, files: done, dir: root };
  }
}

module.exports = PackPublisher;
module.exports.MANIFEST_NAME = MANIFEST_NAME;
