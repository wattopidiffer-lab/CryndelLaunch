const fs = require('fs-extra');
const path = require('path');
const { pathToFileURL } = require('url');

// Sound layout (all under the project's `muzick` folder so the player can drop
// in their own files without touching the code):
//
//   muzick/<event>.mp3|ogg|wav   UI sounds
//   muzick/fon/*                 background music playlist
//   muzick/zastavka/*            splash video (falls back to the sound below)
//   muzick/_defaults/*.wav       synthesized fallbacks (generated on demand)
//
// Every event resolves to the first user file that exists; if the player has
// none, a clean-room synthesized WAV is generated so the launcher always has a
// pleasant sound instead of silence. Nothing is downloaded from the internet:
// the generated tones avoid license and availability problems entirely.

const EVENTS = [
  'interfeyse', 'klick', 'ura', 'eror', 'warn',
  'zastavka', 'sew', 'posluzunok', 'zvukprinapisanii', 'knopka'
];

const EXTENSIONS = ['.mp3', '.ogg', '.wav', '.m4a'];
const AUDIO_RE = /\.(mp3|ogg|wav|m4a)$/i;
const RATE = 44100;

// ---------------------------------------------------------------- synthesis

function toWav(samples) {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write('WAVE', 8);
  buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(RATE, 24);
  buf.writeUInt32LE(RATE * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write('data', 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i += 1) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  return buf;
}

function silence(seconds) {
  return new Float32Array(Math.max(1, Math.floor(RATE * seconds)));
}

// Adds an exponentially decaying sine (or triangle-ish) partial.
function addTone(out, startSec, durSec, freq, amp, opts = {}) {
  const start = Math.floor(startSec * RATE);
  const len = Math.floor(durSec * RATE);
  const decay = opts.decay != null ? opts.decay : 6;
  const attack = opts.attack != null ? opts.attack : 0.004;
  const glide = opts.glide || 0;
  for (let i = 0; i < len; i += 1) {
    const idx = start + i;
    if (idx < 0 || idx >= out.length) continue;
    const t = i / RATE;
    const f = freq + glide * t;
    const env = Math.min(1, t / attack) * Math.exp(-decay * t);
    let s = Math.sin(2 * Math.PI * f * t);
    if (opts.harmonic) s += opts.harmonic * Math.sin(4 * Math.PI * f * t);
    out[idx] += s * amp * env;
  }
}

// Adds a short burst of band-limited noise, used for the click transient.
function addNoise(out, startSec, durSec, amp, decay) {
  const start = Math.floor(startSec * RATE);
  const len = Math.floor(durSec * RATE);
  let prev = 0;
  for (let i = 0; i < len; i += 1) {
    const idx = start + i;
    if (idx < 0 || idx >= out.length) continue;
    const t = i / RATE;
    const white = Math.random() * 2 - 1;
    prev = prev * 0.55 + white * 0.45; // gentle low-pass so it is not harsh
    out[idx] += (white - prev) * amp * Math.exp(-decay * t);
  }
}

const RECIPES = {
  // A soft, pleasant mouse click: a muted transient plus a high tick.
  klick() {
    const out = silence(0.09);
    addNoise(out, 0, 0.02, 0.22, 190);
    addTone(out, 0, 0.045, 1750, 0.16, { decay: 95, attack: 0.001 });
    return out;
  },
  // Button press: same family, a touch lower and warmer.
  knopka() {
    const out = silence(0.1);
    addNoise(out, 0, 0.018, 0.18, 170);
    addTone(out, 0, 0.05, 1320, 0.15, { decay: 70, attack: 0.001 });
    addTone(out, 0, 0.05, 660, 0.06, { decay: 60 });
    return out;
  },
  // Selecting an entry in a list.
  sew() {
    const out = silence(0.11);
    addTone(out, 0, 0.05, 880, 0.13, { decay: 55 });
    addTone(out, 0.02, 0.05, 1320, 0.07, { decay: 60 });
    return out;
  },
  // Slider movement: a short rising sweep.
  posluzunok() {
    const out = silence(0.12);
    addTone(out, 0, 0.09, 520, 0.11, { decay: 22, glide: 900, attack: 0.006 });
    return out;
  },
  // Keystroke: very short and dry so typing does not become noisy.
  zvukprinapisanii() {
    const out = silence(0.06);
    addNoise(out, 0, 0.012, 0.14, 240);
    addTone(out, 0, 0.03, 2100, 0.09, { decay: 130, attack: 0.001 });
    return out;
  },
  // Success: a bright major arpeggio.
  ura() {
    const out = silence(0.62);
    addTone(out, 0, 0.3, 523.25, 0.16, { decay: 8 });
    addTone(out, 0.09, 0.3, 659.25, 0.15, { decay: 8 });
    addTone(out, 0.18, 0.36, 783.99, 0.15, { decay: 7 });
    addTone(out, 0.27, 0.32, 1046.5, 0.13, { decay: 7 });
    return out;
  },
  // Error: two low descending tones.
  eror() {
    const out = silence(0.42);
    addTone(out, 0, 0.16, 300, 0.2, { decay: 12, harmonic: 0.25 });
    addTone(out, 0.15, 0.22, 210, 0.2, { decay: 10, harmonic: 0.25 });
    return out;
  },
  // Warning: a soft double beep.
  warn() {
    const out = silence(0.44);
    addTone(out, 0, 0.13, 720, 0.16, { decay: 11 });
    addTone(out, 0.19, 0.16, 620, 0.15, { decay: 10 });
    return out;
  },
  // Splash / opening: a rising, airy chime.
  zastavka() {
    const out = silence(1.5);
    addTone(out, 0, 0.9, 392, 0.14, { decay: 3.2, glide: 60, attack: 0.09 });
    addTone(out, 0.14, 0.9, 587.33, 0.12, { decay: 3.2, attack: 0.1 });
    addTone(out, 0.28, 1.0, 783.99, 0.11, { decay: 3, attack: 0.12 });
    addTone(out, 0.42, 0.95, 1174.66, 0.08, { decay: 3.4, attack: 0.14 });
    return out;
  },
  // Interface ambience used when a screen opens.
  interfeyse() {
    const out = silence(0.4);
    addTone(out, 0, 0.3, 440, 0.09, { decay: 9, attack: 0.02 });
    addTone(out, 0.05, 0.3, 659.25, 0.07, { decay: 9, attack: 0.03 });
    return out;
  }
};

// ---------------------------------------------------------------- manager

class SoundForge {
  constructor(settings) {
    this.settings = settings;
  }

  // `muzick` lives next to the source tree (and is copied into the packaged
  // app), so both `npm start` and a built launcher find the same folder.
  root() {
    return path.join(__dirname, '..', '..', 'muzick');
  }

  soundsDir() {
    return this.root();
  }

  musicDir() {
    return path.join(this.root(), 'fon');
  }

  splashDir() {
    return path.join(this.root(), 'zastavka');
  }

  defaultsDir() {
    return path.join(this.root(), '_defaults');
  }

  async ensure() {
    await fs.ensureDir(this.root());
    await fs.ensureDir(this.musicDir());
    await fs.ensureDir(this.splashDir());
    await fs.ensureDir(this.defaultsDir());
  }

  // Writes the synthesized fallback for one event, unless it already exists.
  async ensureDefault(event) {
    if (!RECIPES[event]) return '';
    await this.ensure();
    const dest = path.join(this.defaultsDir(), `${event}.wav`);
    if (await fs.pathExists(dest)) return dest;
    try {
      await fs.writeFile(dest, toWav(RECIPES[event]()));
      return dest;
    } catch (_) {
      return '';
    }
  }

  async ensureAllDefaults() {
    for (const ev of EVENTS) await this.ensureDefault(ev);
  }

  // User file first (any supported extension), synthesized fallback second.
  async resolve(event) {
    const custom = await this.settings.get(`ui.soundFiles.${event}`).catch(() => '');
    if (custom && await fs.pathExists(custom)) return custom;
    for (const ext of EXTENSIONS) {
      const p = path.join(this.soundsDir(), `${event}${ext}`);
      if (await fs.pathExists(p)) return p;
    }
    return this.ensureDefault(event);
  }

  async listMusic() {
    await this.ensure();
    const names = await fs.readdir(this.musicDir()).catch(() => []);
    return names.filter((n) => AUDIO_RE.test(n)).map((n) => path.join(this.musicDir(), n));
  }

  async listSplash() {
    await this.ensure();
    const names = await fs.readdir(this.splashDir()).catch(() => []);
    return names.filter((n) => /\.(mp4|webm|mp3|ogg|wav)$/i.test(n))
      .map((n) => path.join(this.splashDir(), n));
  }

  async url(filePath) {
    if (!filePath || !(await fs.pathExists(filePath))) return '';
    try { return pathToFileURL(filePath).href; } catch (_) { return ''; }
  }

  // Payload the renderer needs: a URL per event plus the playlist.
  async payload() {
    const sounds = {};
    for (const ev of EVENTS) sounds[ev] = await this.url(await this.resolve(ev));
    const music = [];
    for (const p of await this.listMusic()) music.push({ name: path.basename(p), url: await this.url(p) });
    return { sounds, music };
  }

  async setCustom(event, filePath) {
    if (!EVENTS.includes(event)) throw new Error('Неизвестный звук: ' + event);
    if (filePath && !AUDIO_RE.test(filePath)) throw new Error('Нужен mp3, ogg, wav или m4a');
    await this.settings.set(`ui.soundFiles.${event}`, filePath || '');
    return { ok: true, url: await this.url(await this.resolve(event)) };
  }

  async resetAll() {
    for (const ev of EVENTS) await this.settings.set(`ui.soundFiles.${ev}`, '');
    return { ok: true };
  }
}

module.exports = SoundForge;
module.exports.EVENTS = EVENTS;
module.exports.toWav = toWav;
module.exports.RECIPES = RECIPES;
