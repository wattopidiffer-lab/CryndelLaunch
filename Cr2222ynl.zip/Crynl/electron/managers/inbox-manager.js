const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const { session } = require('electron');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');
const { sanitizeName } = require('./download-manager');

class InboxBay {
  constructor() {
    this.ready = false;
  }

  dir() {
    return CryndelPathVault.downloadsDir();
  }

  async ensure() {
    await fs.ensureDir(this.dir());
    this.ready = true;
    return this.dir();
  }

  classify(name) {
    const n = String(name || '').toLowerCase();
    if (n.endsWith('.mrpack')) return 'modpack';
    if (n.endsWith('.zip')) return 'archive';
    if (n.endsWith('.jar')) return 'mod';
    return 'file';
  }

  async list() {
    await this.ensure();
    const names = await fs.readdir(this.dir());
    const out = [];
    for (const name of names) {
      const full = path.join(this.dir(), name);
      let st;
      try { st = await fs.stat(full); } catch (_) { continue; }
      if (!st.isFile()) continue;
      out.push({
        name,
        path: full,
        size: st.size,
        mtime: st.mtime.toISOString(),
        kind: this.classify(name)
      });
    }
    out.sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
    return out;
  }

  async saveBuffer(filename, buf) {
    await this.ensure();
    const safe = sanitizeName(filename);
    const dest = path.join(this.dir(), safe);
    await fs.writeFile(dest, buf);
    return dest;
  }

  async downloadUrl(url, filename, onProgress) {
    await this.ensure();
    const safe = sanitizeName(filename || path.basename(new URL(url).pathname) || 'download.bin');
    // Never clobber a file that is already in the downloads folder.
    const dest = this.uniqueDest(safe);
    const res = await axios.get(url, {
      responseType: 'stream',
      timeout: 180000,
      maxRedirects: 8,
      headers: { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' }
    });
    const total = Number(res.headers['content-length'] || 0);
    let loaded = 0;
    // Show the dock immediately so the player sees progress from byte zero.
    if (onProgress) onProgress({ loaded: 0, total, pct: 0, filename: path.basename(dest), started: true });
    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(dest);
      res.data.on('data', (chunk) => {
        loaded += chunk.length;
        if (onProgress) onProgress({ loaded, total, pct: total ? Math.round((loaded / total) * 100) : 0, filename: safe });
      });
      res.data.on('error', reject);
      out.on('error', reject);
      out.on('finish', resolve);
      res.data.pipe(out);
    });
    logger.info('inbox saved', { dest });
    if (onProgress) onProgress({ loaded, total: total || loaded, pct: 100, filename: path.basename(dest), finished: true });
    return dest;
  }

  // A downloaded name can collide with an existing file in the launcher's
  // downloads folder; append a counter so nothing is silently overwritten.
  uniqueDest(name) {
    const safe = sanitizeName(name || 'download.bin');
    const dir = this.dir();
    const ext = path.extname(safe);
    const stem = path.basename(safe, ext);
    let candidate = path.join(dir, safe);
    let n = 2;
    while (fs.existsSync(candidate)) {
      candidate = path.join(dir, `${stem} (${n})${ext}`);
      n += 1;
    }
    return candidate;
  }

  attachSession(ses, onSaved, onProgress) {
    if (!ses) ses = session.defaultSession;
    // A session must be wired once: attaching twice would double the progress
    // events and make the download dock flicker.
    this._wired = this._wired || new WeakSet();
    if (this._wired.has(ses)) return;
    this._wired.add(ses);
    if (onProgress) this._onProgress = onProgress;
    // Setting the session download path as well as the per-item save path is
    // what stops Electron from ever opening its own "Save as" dialog / bare
    // window: every download goes straight into the launcher's CL-Downloads.
    try { fs.ensureDirSync(this.dir()); ses.setDownloadPath(this.dir()); } catch (_) { /* older electron */ }
    ses.on('will-download', (_e, item) => {
      fs.ensureDirSync(this.dir());
      // setSavePath is what keeps the file *inside* the launcher: without it
      // Electron falls back to the OS download prompt / a bare window, which is
      // why downloads used to land outside CL-Downloads.
      const name = sanitizeName(item.getFilename() || 'download.bin');
      const dest = this.uniqueDest(name);
      try { item.setSavePath(dest); } catch (_) { /* fall back to default */ }
      // Announce the download immediately so the dock and the notification
      // appear the moment the file starts, not after the first byte arrives.
      if (typeof this._onProgress === 'function') {
        this._onProgress({ loaded: 0, total: item.getTotalBytes() || 0, pct: 0, filename: path.basename(dest), started: true });
      }
      item.on('updated', (_ev, state) => {
        if (state === 'progressing') {
          const total = item.getTotalBytes() || 0;
          const loaded = item.getReceivedBytes() || 0;
          const payload = { loaded, total, pct: total ? Math.round((loaded / total) * 100) : 0, filename: path.basename(dest) };
          if (typeof this._onProgress === 'function') this._onProgress(payload);
        }
      });
      item.once('done', (_ev, state) => {
        const saved = path.basename(dest);
        if (state === 'completed') {
          if (typeof this._onProgress === 'function') this._onProgress({ loaded: item.getReceivedBytes() || 0, total: item.getTotalBytes() || 0, pct: 100, filename: saved, finished: true });
          if (onSaved) onSaved({ name: saved, path: dest, kind: this.classify(saved) });
        } else if (typeof this._onProgress === 'function') {
          // Cancelled / interrupted downloads must still close the dock.
          this._onProgress({ loaded: 0, total: 0, pct: 0, filename: saved, failed: true });
        }
      });
    });
  }

  async importIntoInstance(filePath, instance, mods) {
    const kind = this.classify(filePath);
    if (kind === 'mod') {
      const destDir = path.join(instance.gameDir, 'mods');
      await fs.ensureDir(destDir);
      const name = sanitizeName(path.basename(filePath));
      const dest = path.join(destDir, name);
      await fs.copy(filePath, dest, { overwrite: true });
      const buf = await fs.readFile(dest);
      const sha512 = crypto.createHash('sha512').update(buf).digest('hex');
      if (mods && mods.lockfile) {
        await mods.lockfile.upsertEntry(instance.id, {
          id: path.basename(name, '.jar').toLowerCase(),
          filename: name,
          sha512,
          source: 'inbox',
          enabled: true,
          size: buf.length
        });
      }
      return { ok: true, kind, dest };
    }
    return { ok: false, kind, error: 'use-import-mrpack' };
  }
}

module.exports = InboxBay;
