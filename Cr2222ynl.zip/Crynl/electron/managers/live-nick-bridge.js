const { EventEmitter } = require('events');
const logger = require('../utils/logger');

class EchoAliasBridge extends EventEmitter {
  constructor() {
    super();
    this.wss = null;
    this.port = 21999;
    this.clients = new Set();
    this.lastNick = null;
  }

  async start(port) {
    if (this.wss) return this.status();
    this.port = port || 21999;
    let WebSocketServer;
    try {
      ({ WebSocketServer } = require('ws'));
    } catch (err) {
      logger.warn('ws module missing, live nick disabled');
      return this.status();
    }
    this.wss = new WebSocketServer({ port: this.port });
    this.wss.on('connection', (socket) => {
      this.clients.add(socket);
      this.emit('status', this.status());
      socket.on('close', () => {
        this.clients.delete(socket);
        this.emit('status', this.status());
      });
    });
    logger.info('live nick ws listening', { port: this.port });
    return this.status();
  }

  async stop() {
    if (!this.wss) return;
    for (const c of this.clients) {
      try { c.close(); } catch (_) { /* */ }
    }
    await new Promise((r) => this.wss.close(r));
    this.wss = null;
    this.clients.clear();
  }

  status() {
    return {
      enabled: Boolean(this.wss),
      port: this.port,
      clients: this.clients.size,
      lastNick: this.lastNick
    };
  }

  async change(newNick) {
    this.lastNick = newNick;
    const payload = JSON.stringify({ type: 'nick', nick: newNick, at: Date.now() });
    for (const c of this.clients) {
      try { c.send(payload); } catch (_) { /* */ }
    }
    this.emit('status', this.status());
    return { ok: true, delivered: this.clients.size };
  }
}

module.exports = EchoAliasBridge;
