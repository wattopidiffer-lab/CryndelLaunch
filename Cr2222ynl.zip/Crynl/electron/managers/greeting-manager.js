const fs = require('fs-extra');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

// Per-nick greetings, stored as one JSON document so the file can be edited by
// hand and shared between machines. The home screen picks the greeting for the
// current nickname; `{nick}` and `{time}` are substituted at read time.
const DEFAULT_GREETINGS = {
  default: [
    'С возвращением, {nick}!',
    'Привет, {nick}! Готов к игре?',
    'Рады видеть, {nick}.',
    'Доброго времени суток, {nick}!'
  ],
  morning: ['Доброе утро, {nick}!', 'Утро доброе, {nick}!'],
  day: ['Добрый день, {nick}!', 'Привет, {nick}!'],
  evening: ['Добрый вечер, {nick}!', 'Вечер в хату, {nick}.'],
  night: ['Доброй ночи, {nick}!', 'Не спится, {nick}?']
};

class GreetingLoom {
  async file() {
    return CryndelPathVault.greetingsFile();
  }

  async ensure() {
    const file = await this.file();
    if (!await fs.pathExists(file)) {
      await fs.ensureDir(require('path').dirname(file));
      await fs.writeJson(file, { greetings: DEFAULT_GREETINGS }, { spaces: 2 });
    }
    return file;
  }

  async read() {
    const file = await this.ensure();
    try {
      const doc = await fs.readJson(file);
      const g = doc && doc.greetings;
      if (g && typeof g === 'object') return g;
    } catch (err) {
      logger.warn('greetings read failed', { message: err.message });
    }
    return { ...DEFAULT_GREETINGS };
  }

  async write(greetings) {
    const file = await this.ensure();
    const clean = {};
    for (const [key, value] of Object.entries(greetings || {})) {
      const list = Array.isArray(value) ? value : [value];
      clean[key] = list.map((s) => String(s || '').trim()).filter(Boolean);
    }
    await fs.writeJson(file, { greetings: clean }, { spaces: 2 });
    return clean;
  }

  // Resolve one greeting for a nick. A per-nick bucket wins over the
  // time-of-day bucket, which wins over `default`.
  async pick(nick, date = new Date()) {
    const all = await this.read();
    const hour = date.getHours();
    const bucket = hour < 5 ? 'night' : hour < 12 ? 'morning' : hour < 18 ? 'day' : 'evening';
    const pool = (nick && all[nick]) || all[bucket] || all.default || [];
    const text = pool.length ? pool[Math.floor(Math.random() * pool.length)] : '';
    const timeWord = { morning: 'утро', day: 'день', evening: 'вечер', night: 'ночь' }[bucket];
    return String(text)
      .replace(/\{nick\}/g, nick || 'игрок')
      .replace(/\{time\}/g, timeWord);
  }
}

module.exports = GreetingLoom;
