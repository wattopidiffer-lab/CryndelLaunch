const vault = require('../storage/json-db');
const CryndelPathVault = require('../utils/paths');
const { DEFAULT_SETTINGS } = require('../storage/schemas');

function dig(obj, key) {
  if (!key) return obj;
  const parts = String(key).split('.');
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function plant(obj, key, value) {
  const parts = String(key).split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const p = parts[i];
    if (!cur[p] || typeof cur[p] !== 'object') cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
  return obj;
}

// Merge stored settings over the defaults, one level deep. A settings file
// written by an older build (or one damaged by a partial write) used to leave
// new keys undefined, which made freshly added toggles look broken. Objects are
// merged recursively; arrays and scalars from the file win.
function withDefaults(stored, defaults) {
  if (!stored || typeof stored !== 'object' || Array.isArray(stored)) {
    return JSON.parse(JSON.stringify(defaults));
  }
  const out = { ...stored };
  for (const key of Object.keys(defaults)) {
    const def = defaults[key];
    const cur = out[key];
    if (def && typeof def === 'object' && !Array.isArray(def)) {
      out[key] = withDefaults(cur, def);
    } else if (cur === undefined) {
      out[key] = Array.isArray(def) ? JSON.parse(JSON.stringify(def)) : def;
    }
  }
  return out;
}

class DialBoard {
  file() {
    return CryndelPathVault.settingsFile();
  }

  async load() {
    const stored = await vault.read(this.file(), DEFAULT_SETTINGS);
    return withDefaults(stored, DEFAULT_SETTINGS);
  }

  async get(key) {
    const all = await this.load();
    return key ? dig(all, key) : all;
  }

  async getAll() {
    return this.load();
  }

  async set(key, value) {
    return vault.patch(this.file(), (doc) => plant(doc, key, value), DEFAULT_SETTINGS);
  }

  async reset() {
    const fresh = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
    await vault.write(this.file(), fresh);
    return fresh;
  }
}

module.exports = DialBoard;
