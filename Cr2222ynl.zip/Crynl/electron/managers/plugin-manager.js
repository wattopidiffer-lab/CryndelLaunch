const fs = require('fs-extra');
const path = require('path');
const vm = require('vm');
const AdmZip = require('adm-zip');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

// Plugins are plain folders or .zip archives dropped into <userRoot>/plugins.
// Each one carries a manifest.json:
//   { "id": "hello", "name": "Hello", "version": "1.0.0", "main": "index.js",
//     "api": 1, "permissions": ["ui", "events"] }
//
// A plugin's `activate(api)` runs inside a `vm` context with only the globals we
// hand it. Everything it exports is wrapped so a throw in one plugin can never
// take down the launcher: errors are captured per plugin, surfaced as a warning
// and the rest keep running.
const PLUGIN_API_VERSION = 1;

class PluginForge {
  constructor(hub = {}) {
    this.hub = hub;
    this.loaded = new Map();
    this.warnings = [];
    this.hooks = new Map();
  }

  dir() {
    return CryndelPathVault.pluginsDir();
  }

  async ensure() {
    await fs.ensureDir(this.dir());
    return this.dir();
  }

  // Extracts a .zip into the plugins folder and returns the manifest, or null
  // when the archive is not a plugin.
  async installFromZip(zipPath) {
    await this.ensure();
    const zip = new AdmZip(zipPath);
    const entries = zip.getEntries();
    const manifestEntry = entries.find((e) => /(^|\/)manifest\.json$/i.test(e.entryName) && !e.isDirectory);
    if (!manifestEntry) return { ok: false, error: 'В архиве нет manifest.json' };
    let manifest;
    try {
      manifest = JSON.parse(manifestEntry.getData().toString('utf8'));
    } catch (_) {
      return { ok: false, error: 'manifest.json повреждён' };
    }
    const id = String(manifest.id || '').replace(/[^\w.-]+/g, '_');
    if (!id) return { ok: false, error: 'В манифесте нет id' };
    const target = path.join(this.dir(), id);
    // Never extract outside the plugins folder: strip absolute paths and `..`.
    for (const entry of entries) {
      const rel = entry.entryName.split('/').filter((p) => p && p !== '..').join(path.sep);
      if (!rel) continue;
      const dest = path.join(target, rel);
      if (!dest.startsWith(target + path.sep) && dest !== target) continue;
      if (entry.isDirectory) await fs.ensureDir(dest);
      else {
        await fs.ensureDir(path.dirname(dest));
        await fs.writeFile(dest, entry.getData());
      }
    }
    return { ok: true, id, manifest, dir: target };
  }

  async list() {
    await this.ensure();
    const names = await fs.readdir(this.dir()).catch(() => []);
    const out = [];
    for (const name of names) {
      const dir = path.join(this.dir(), name);
      const st = await fs.stat(dir).catch(() => null);
      if (!st || !st.isDirectory()) continue;
      const manifestPath = path.join(dir, 'manifest.json');
      if (!await fs.pathExists(manifestPath)) continue;
      let manifest = {};
      let error = '';
      try { manifest = await fs.readJson(manifestPath); } catch (err) { error = err.message; }
      out.push({
        id: name,
        name: manifest.name || name,
        version: manifest.version || '',
        description: manifest.description || '',
        author: manifest.author || '',
        api: manifest.api || 0,
        dir,
        error,
        active: this.loaded.has(name)
      });
    }
    return out;
  }

  // Build the sandboxed API handed to a plugin. Every call is guarded so a
  // misbehaving plugin produces a warning instead of an unhandled rejection.
  buildApi(id, manifest) {
    const warn = (message) => this.warn(id, message);
    return {
      apiVersion: PLUGIN_API_VERSION,
      pluginId: id,
      manifest: { ...manifest },
      log: (...args) => logger.info(`plugin ${id}`, { args: args.map(String) }),
      warn: (...args) => warn(args.map(String).join(' ')),
      on: (hook, handler) => this.on(id, hook, handler),
      settings: {
        get: (key, fallback) => Promise.resolve(
          this.hub.settings ? this.hub.settings.get(key).catch(() => fallback) : fallback
        ),
        set: (key, value) => (this.hub.settings ? this.hub.settings.set(key, value).catch(() => {}) : Promise.resolve())
      },
      toast: (text) => this.emit('toast', { text: String(text || '') })
    };
  }

  async loadOne(id) {
    const dir = path.join(this.dir(), id);
    const manifestPath = path.join(dir, 'manifest.json');
    if (!await fs.pathExists(manifestPath)) return { ok: false, error: 'Нет манифеста' };
    let manifest;
    try { manifest = await fs.readJson(manifestPath); } catch (err) { return { ok: false, error: err.message }; }
    if (Number(manifest.api) > PLUGIN_API_VERSION) {
      this.warn(id, `Плагин требует API ${manifest.api}, а лаунчер поддерживает ${PLUGIN_API_VERSION}`);
      return { ok: false, error: 'Слишком новая версия API' };
    }
    const main = path.join(dir, manifest.main || 'index.js');
    if (!await fs.pathExists(main)) return { ok: false, error: 'Нет main-файла' };
    const code = await fs.readFile(main, 'utf8');
    const api = this.buildApi(id, manifest);
    const sandbox = {
      module: { exports: {} },
      exports: {},
      console: { log: api.log, warn: api.warn, error: api.warn },
      api,
      setTimeout,
      clearTimeout,
      setInterval,
      clearInterval
    };
    try {
      const script = new vm.Script(code, { filename: main });
      const ctx = vm.createContext(sandbox);
      script.runInContext(ctx, { timeout: 5000 });
      const exported = sandbox.module.exports && Object.keys(sandbox.module.exports).length
        ? sandbox.module.exports
        : sandbox.exports;
      // Both `module.exports = { activate }` and a bare `module.exports = fn`
      // entry point are accepted; anything else is reported instead of
      // silently loading as a no-op.
      if (typeof exported === 'function') {
        await exported(api);
      } else if (exported && typeof exported.activate === 'function') {
        await exported.activate(api);
      } else {
        this.warn(id, 'Плагин не экспортирует activate() — он загружен, но ничего не делает');
      }
      this.loaded.set(id, { manifest, dir, api, exports: exported });
      return { ok: true, id };
    } catch (err) {
      this.warn(id, err.message || String(err));
      return { ok: false, error: err.message || String(err) };
    }
  }

  async loadAll() {
    await this.ensure();
    this.warnings = [];
    const list = await this.list();
    const results = [];
    for (const p of list) {
      // eslint-disable-next-line no-await-in-loop
      results.push(await this.loadOne(p.id));
    }
    return { loaded: this.loaded.size, results, warnings: this.warnings };
  }

  async unload(id) {
    const entry = this.loaded.get(id);
    if (entry && entry.exports && typeof entry.exports.deactivate === 'function') {
      try { await entry.exports.deactivate(); } catch (err) { this.warn(id, err.message); }
    }
    this.loaded.delete(id);
    for (const [hook, handlers] of this.hooks) {
      this.hooks.set(hook, handlers.filter((h) => h.id !== id));
    }
    return { ok: true };
  }

  on(id, hook, handler) {
    if (typeof handler !== 'function') return;
    if (!this.hooks.has(hook)) this.hooks.set(hook, []);
    this.hooks.get(hook).push({ id, handler });
  }

  // Fire a hook. Each handler runs in isolation: a throw is turned into a
  // warning and never breaks the caller or the other plugins.
  emit(hook, payload) {
    const handlers = this.hooks.get(hook) || [];
    const out = [];
    for (const { id, handler } of handlers) {
      try {
        out.push(handler(payload));
      } catch (err) {
        this.warn(id, `hook ${hook}: ${err.message || err}`);
      }
    }
    return out;
  }

  warn(id, message) {
    const w = { id, message: String(message || ''), at: new Date().toISOString() };
    this.warnings.push(w);
    if (this.warnings.length > 200) this.warnings.shift();
    logger.warn(`plugin ${id}`, { message: w.message });
    return w;
  }

  async remove(id) {
    await this.unload(id);
    await fs.remove(path.join(this.dir(), id)).catch(() => {});
    return { ok: true };
  }
}

module.exports = PluginForge;
module.exports.PLUGIN_API_VERSION = PLUGIN_API_VERSION;
