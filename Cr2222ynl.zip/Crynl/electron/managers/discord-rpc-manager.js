const logger = require('../utils/logger');

// Discord requires a real application id for Rich Presence. There is no usable
// public default: a placeholder id makes the RPC client connect and then fail
// silently, which is exactly the "RPC does not work" bug. The id therefore comes
// from (in order) the settings field, CRYNDEL_DISCORD_APP_ID, or nothing — and
// when it is missing the manager reports `needsAppId` so the UI can explain it.
const DEFAULT_APP_ID = process.env.CRYNDEL_DISCORD_APP_ID || '';
const RETRY_DELAYS = [2000, 8000, 20000, 60000];

class PresenceBeacon {
  constructor(appId) {
    this.client = null;
    this.ready = false;
    this.clientId = appId || DEFAULT_APP_ID;
    this.enabled = true;
    this.retryTimer = null;
    this.retryIndex = 0;
    this.activity = null;
    this.lastError = '';
  }

  get needsAppId() {
    return !String(this.clientId || '').trim();
  }

  // Lets the Options screen point the RPC at the user's own Discord app id.
  // Reconnects right away so the change applies without a launcher restart.
  async configure(appId) {
    const next = String(appId || '').trim() || DEFAULT_APP_ID;
    if (next === this.clientId && this.ready) return { ok: true, ready: this.ready };
    this.clientId = next;
    if (!this.enabled) return { ok: true, ready: false };
    await this.disconnect();
    this.enabled = true;
    await this.connect();
    return { ok: true, ready: this.ready };
  }

  scheduleRetry() {
    // Nothing to retry against without a real application id.
    if (!this.enabled || this.retryTimer || this.needsAppId) return;
    const delay = RETRY_DELAYS[Math.min(this.retryIndex, RETRY_DELAYS.length - 1)];
    this.retryIndex += 1;
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.connect().catch(() => { /* retried again */ });
    }, delay);
  }

  async connect(appId) {
    this.enabled = true;
    if (appId) this.clientId = appId;
    // Without a real application id the RPC library logs in against a bogus app
    // and Discord drops the connection, so the presence never appears. Bail out
    // early with a clear reason instead of retrying forever.
    if (this.needsAppId) {
      this.ready = false;
      this.lastError = 'Не задан Discord App ID — укажи его в настройках';
      return { ok: false, ready: false, error: this.lastError, needsAppId: true };
    }
    try {
      const RPC = require('discord-rpc');
      if (this.client) {
        try { await this.client.destroy(); } catch (_) { /* */ }
        this.client = null;
        this.ready = false;
      }
      const client = new RPC.Client({ transport: 'ipc' });
      this.client = client;
      client.on('ready', () => {
        this.ready = true;
        this.retryIndex = 0;
        logger.info('discord rpc ready');
        this.applyActivity(this.activity || {
          details: 'Cryndel Launcher',
          state: 'В лаунчере',
          startTimestamp: Date.now(),
          largeImageKey: 'cryndel',
          largeImageText: 'Cryndel Launcher'
        });
      });
      client.on('disconnected', () => {
        this.ready = false;
        this.client = null;
        // Discord may not be running yet; keep trying quietly.
        this.scheduleRetry();
      });
      await client.login({ clientId: this.clientId }).catch((err) => {
        this.lastError = err.message || String(err);
        logger.debug('discord rpc login failed', { message: this.lastError });
        this.scheduleRetry();
      });
    } catch (err) {
      this.lastError = err.message || String(err);
      logger.debug('discord rpc skipped', { message: this.lastError });
      this.scheduleRetry();
    }
  }

  async applyActivity(activity) {
    this.activity = activity;
    if (!this.ready || !this.client) return;
    try {
      await this.client.setActivity(activity);
    } catch (_) { /* rpc optional */ }
  }

  async disconnect() {
    this.enabled = false;
    this.ready = false;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (!this.client) return;
    try { await this.client.clearActivity(); } catch (_) { /* */ }
    try { await this.client.destroy(); } catch (_) { /* */ }
    this.client = null;
  }

  async setPlaying(instance, _user) {
    this.enabled = true;
    if (!this.ready || !this.client) {
      this.scheduleRetry();
      return;
    }
    try {
      await this.applyActivity({
        details: instance ? instance.name : 'Cryndel',
        state: instance ? `${instance.mcVersion} · ${instance.modLoader}` : 'In launcher',
        startTimestamp: Date.now(),
        largeImageKey: 'cryndel',
        largeImageText: 'Cryndel Launcher',
        buttons: instance && instance.quickPlay && instance.quickPlay.enabled
          ? [{ label: 'Join Cryndel', url: 'https://cryndel.ru' }]
          : undefined
      });
    } catch (_) { /* rpc optional */ }
  }

  async clear() {
    if (!this.ready || !this.client) return;
    this.activity = null;
    try {
      await this.applyActivity({
        details: 'Cryndel Launcher',
        state: 'В лаунчере',
        startTimestamp: Date.now(),
        largeImageKey: 'cryndel',
        largeImageText: 'Cryndel Launcher'
      });
    } catch (_) { /* rpc optional */ }
  }
}

module.exports = PresenceBeacon;
