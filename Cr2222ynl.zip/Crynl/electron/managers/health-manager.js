const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');
const CryndelPathVault = require('../utils/paths');

const PATTERNS = [
  { re: /NoClassDefFoundError:\s*([^\s]+)/i, hint: 'missing-class' },
  { re: /ClassNotFoundException:\s*([^\s]+)/i, hint: 'missing-class' },
  { re: /Missing dependency[:\s]+([^\n]+)/i, hint: 'missing-dep' },
  { re: /Mod\s+(\S+)\s+requires\s+([^\n]+)/i, hint: 'requires' },
  { re: /fabric-api/i, hint: 'fabric-api' },
  { re: /Incompatible mods found/i, hint: 'incompatible' },
  { re: /java\.lang\.OutOfMemoryError/i, hint: 'oom' },
  { re: /Failed to load mod/i, hint: 'mod-load' }
];

class PulseClinic {
  constructor({ lockfile, mods, backups, timeline }) {
    this.lockfile = lockfile;
    this.mods = mods;
    this.backups = backups;
    this.timeline = timeline;
  }

  async folderSize(dir) {
    if (!(await fs.pathExists(dir))) return 0;
    let total = 0;
    const walk = async (p) => {
      const st = await fs.stat(p);
      if (st.isFile()) {
        total += st.size;
        return;
      }
      const kids = await fs.readdir(p);
      for (const k of kids) await walk(path.join(p, k));
    };
    try { await walk(dir); } catch (_) { /* */ }
    return total;
  }

  fmt(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
    return `${(bytes / 1073741824).toFixed(2)} GB`;
  }

  async getStatus(instance) {
    if (!instance) {
      return {
        diskUsage: '0 B',
        diskBytes: 0,
        lastLaunch: null,
        lastExit: 'unknown',
        backupStatus: 'none',
        modCount: 0,
        enabledMods: 0,
        conflicts: 0,
        conflictItems: []
      };
    }
    const mods = await this.mods.listInstalled(instance.id);
    const conflicts = await this.mods.detectConflicts(instance.id);
    const disk = await this.folderSize(instance.gameDir);
    const backups = await this.backups.list(instance.id);
    return {
      diskUsage: this.fmt(disk),
      diskBytes: disk,
      lastLaunch: instance.lastPlayedAt,
      lastExit: 'unknown',
      backupStatus: backups.length ? 'ok' : 'none',
      modCount: mods.length,
      enabledMods: mods.filter((m) => m.enabled).length,
      conflicts: conflicts.length,
      conflictItems: conflicts
    };
  }

  async readLatestLogs(instance) {
    const logsDir = path.join(instance.gameDir, 'logs');
    const crashDir = path.join(instance.gameDir, 'crash-reports');
    const chunks = [];
    const latest = path.join(logsDir, 'latest.log');
    if (await fs.pathExists(latest)) {
      const raw = await fs.readFile(latest, 'utf8');
      chunks.push({ file: 'latest.log', text: raw.slice(-80000) });
    }
    if (await fs.pathExists(crashDir)) {
      const names = (await fs.readdir(crashDir)).filter((n) => n.endsWith('.txt')).sort().reverse();
      if (names[0]) {
        const raw = await fs.readFile(path.join(crashDir, names[0]), 'utf8');
        chunks.push({ file: names[0], text: raw.slice(-80000) });
      }
    }
    return chunks;
  }

  async analyzeCrash(instance) {
    if (!instance) {
      return { findings: [], suggestion: 'Нет выбранной сборки.', ru: 'Нет выбранной сборки.', logs: [] };
    }
    const chunks = await this.readLatestLogs(instance);
    const findings = [];
    for (const chunk of chunks) {
      for (const p of PATTERNS) {
        const m = chunk.text.match(p.re);
        if (m) findings.push({ hint: p.hint, match: m[0], extra: m[1] || null, file: chunk.file });
      }
    }
    let suggestion = 'Краш не распознан. Открой latest.log в папке сборки.';
    const hints = findings.map((f) => f.hint);
    if (hints.includes('fabric-api') || hints.includes('missing-dep') || hints.includes('requires')) {
      suggestion = 'Не хватает Fabric API или зависимости. Нажми «Исправить» — поставим из Модринта.';
    } else if (hints.includes('oom')) {
      suggestion = 'Не хватило оперативки. Увеличь память сборки в настройках.';
    } else if (hints.includes('incompatible') || hints.includes('mod-load')) {
      suggestion = 'Мод не загрузился. Отключим подозрительные или откатимся к снимку.';
    } else if (hints.includes('missing-class')) {
      suggestion = 'Не найден класс — установка оборвалась или не тот загрузчик.';
    }
    return { findings, suggestion, ru: suggestion, logs: chunks.map((c) => c.file) };
  }

  async autoFix(instance, hub) {
    if (!instance) return { ok: false, message: 'Нет выбранной сборки' };
    const crash = await this.analyzeCrash(instance);
    const hints = (crash.findings || []).map((f) => f.hint);
    const done = [];
    if (hints.includes('fabric-api') || hints.includes('missing-dep') || hints.includes('requires')) {
      if (hub && hub.resolver && hub.modrinth) {
        try {
          const versions = await hub.modrinth.getProjectVersions('fabric-api', {
            loader: instance.modLoader,
            mcVersion: instance.mcVersion
          });
          if (versions && versions[0]) {
            await hub.resolver.resolveAndInstall(instance.id, versions[0].id, new Set(), {
              loader: instance.modLoader,
              mcVersion: instance.mcVersion
            });
            done.push('fabric-api');
          }
        } catch (err) {
          return { ok: false, message: 'Не удалось поставить Fabric API: ' + err.message };
        }
      }
    }
    if (hints.includes('incompatible') || hints.includes('mod-load') || hints.includes('missing-class')) {
      const r = await this.fixInstance(instance, 'disable-suspects');
      if (r.ok) done.push('отключены подозрительные моды');
    }
    if (hints.includes('oom')) {
      return { ok: true, message: 'Это нехватка памяти. Поставь больше RAM в Опциях и запускай снова.' };
    }
    if (!done.length) {
      return { ok: true, message: crash.suggestion };
    }
    return { ok: true, message: 'Исправлено: ' + done.join(', ') };
  }

  async fixInstance(instance, action) {
    if (!instance) return { ok: false, error: 'Нет выбранной сборки' };
    if (action === 'install-fabric-api') {
      return { ok: true, action, note: 'Install Fabric API from Modrinth catalog' };
    }
    if (action === 'disable-suspects') {
      const mods = await this.mods.listInstalled(instance.id);
      const suspects = mods.filter((m) => m.enabled && m.source !== 'modrinth').slice(0, 5);
      for (const m of suspects) await this.mods.toggle(instance.id, m.id, false);
      if (this.timeline) await this.timeline.append(instance.id, 'fix', `Disabled ${suspects.length} local mods`);
      return { ok: true, disabled: suspects.map((s) => s.id) };
    }
    if (action === 'rollback') {
      const list = await this.backups.list(instance.id);
      if (!list.length) return { ok: false, error: 'No backups' };
      const last = list[list.length - 1];
      await this.backups.restore(instance, last.id);
      if (this.timeline) await this.timeline.append(instance.id, 'fix', `Restored backup ${last.id}`);
      return { ok: true, backupId: last.id };
    }
    return { ok: false, error: 'Unknown action' };
  }

  async getTimeline(instanceId) {
    if (!this.timeline) return [];
    return this.timeline.list(instanceId);
  }

  async storageInfo(instances) {
    const assets = await this.folderSize(CryndelPathVault.assetsDir());
    const libraries = await this.folderSize(CryndelPathVault.librariesDir());
    const cache = await this.folderSize(CryndelPathVault.modCacheDir());
    const list = [];
    for (const inst of instances || []) {
      const bytes = await this.folderSize(inst.gameDir);
      list.push({ id: inst.id, name: inst.name, bytes, human: this.fmt(bytes) });
    }
    return {
      assets: { bytes: assets, human: this.fmt(assets) },
      libraries: { bytes: libraries, human: this.fmt(libraries) },
      cache: { bytes: cache, human: this.fmt(cache) },
      instances: list
    };
  }

  async clearCache(type) {
    if (type === 'mods' || type === 'all') {
      await fs.emptyDir(CryndelPathVault.modCacheDir());
    }
    logger.info('cache cleared', { type });
    return { ok: true };
  }
}

module.exports = PulseClinic;
