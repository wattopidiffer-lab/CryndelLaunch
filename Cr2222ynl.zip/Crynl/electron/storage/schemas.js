const DEFAULT_SETTINGS = {
  version: 9,
  ui: {
    language: 'ru',
    theme: 'dark',
    animations: true,
    animationDuration: 450,
    backgroundVideo: true,
    backgroundKind: 'video',
    backgroundFile: '',
    reducedMotion: false,
    navPos: 'left',
    accent: '',
    radius: 16,
    homeFont: 'default',
    bgLoop: true,
    bgDim: 0.55,
    bgVeil: 1,
    alwaysSplash: false,
    splashDuration: 0,
    showSkin3d: false,
    particles: false,
    furryWidget: true,
    furryScale: 1,
    furryImage: '',
    furrySounds: [],
    splashFile: '',
    shotsWidget: true,
    hideCarousel: false,
    splash: true,
    sounds: true,
    soundVolume: 0.6,
    uiSounds: true,
    // Extra sound knobs: per-event volume/mute, custom files per event, and the
    // background music playlist behaviour.
    typingSounds: true,
    soundVolumes: {},
    soundMuted: {},
    soundFiles: {},
    musicVolume: 0.5,
    musicMode: 'playlist',
    musicAutoplay: true,
    showMusicCard: true,
    musicCardPos: 'bottom-left',
    showWidgets: false,
    compact: false,
    carouselSeconds: 10,
    homeActions: true,
    statCards: true,
    skinSpin: true,
    clickSounds: true,
    homeGreeting: true,
    accentGlow: true,
    uiScale: 100,
    navWidth: 92,
    cardRadius: 18,
    density: 'normal',
    toolsPos: 'auto',
    glassBlur: 0,
    panelOpacity: 100,
    navIconSize: 18,
    showStatusBar: true,
    toastPos: 'bottom',
    hoverLift: true,
    navLabels: true,
    bgBlur: 0,
    toastDuration: 4200,
    dockPos: 'right',
    headerAutoHide: true,
    greetingEnabled: true,
    pluginsEnabled: true,
    homeButtons: true
  },
  game: {
    defaultMemoryMb: 4096,
    memoryMode: 'auto',
    defaultGameDir: '',
    javaPath: 'auto',
    javaCommand: '',
    jvmPreset: 'cryndel-recommended',
    customJvmArgs: '',
    envVars: '',
    defaultResolution: { width: 1280, height: 720 },
    defaultFullscreen: false,
    language: 'ru',
    toggleSprint: true,
    toggleSneak: false,
    rawMouseInput: true,
    vsync: true,
    maxFps: 0,
    renderDistance: 12,
    simulationDistance: 12,
    guiScale: 0,
    fov: 70,
    autoJump: false,
    particlesSetting: 'all',
    gpu: 'auto',
    graphics: 'default',
    masterVolume: 1,
    musicVolume: 1,
    difficulty: 'normal',
    chatVisibility: 'full',
    showFps: false,
    fullscreenOnLaunch: false,
    capeFile: '',
    capeEnabled: false,
    showOnGameExit: true,
    serverHost: 'cryndel.ru',
    serverPort: 25565,
    autoAddServer: true,
    smoothLighting: true,
    clouds: 'default',
    entityShadows: true,
    bobView: true,
    viewBobbing: true,
    pauseOnLostFocus: true,
    invertYMouse: false,
    mouseSensitivityPct: 100,
    gammaPct: 50,
    chatOpacityPct: 100,
    hudHidden: false,
    narrator: 0,
    skinModel: 'default'
  },
  launcher: {
    closeOnLaunch: false,
    minimizeToTray: true,
    hideToTrayOnLaunch: false,
    discordRpc: true,
    showConsoleOnLaunch: false,
    hideOnLaunch: false,
    confirmExit: true,
    showOnGameExit: true,
    restoreWindowAfterGame: true
  },
  versions: {
    showReleases: true,
    showSnapshots: false,
    showBetas: false,
    showOld: false
  },
  modrinth: {
    enabled: true,
    autoCheckUpdates: true,
    checkIntervalHours: 24,
    autoInstallDependencies: true,
    scanMalware: true,
    skipDuplicates: true,
    listLimit: 20,
    fullscreen: true,
    svgOnly: true
  },
  browser: {
    zoom: 100,
    openLinksInside: true
  },
  cabinet: {
    zoom: 100,
    keepAlive: true
  },
  advanced: {
    apiUrl: 'https://api.cryndel.ru',
    devMode: false,
    verboseLogging: false,
    liveNick: { enabled: true, wsPort: 21999 },
    discordAppId: ''
  },
  extras: {
    customCss: true,
    splash: true
  }
};

const DEFAULT_USERS = {
  version: 2,
  currentUserId: null,
  users: []
};

const DEFAULT_INSTANCES = {
  version: 2,
  instances: []
};

function emptyLock(instanceId, extra) {
  return {
    version: 1,
    instanceId,
    mcVersion: extra && extra.mcVersion ? extra.mcVersion : '1.21.11',
    loader: extra && extra.loader ? extra.loader : 'fabric',
    loaderVersion: extra && extra.loaderVersion ? extra.loaderVersion : '',
    updatedAt: new Date().toISOString(),
    entries: []
  };
}

module.exports = {
  DEFAULT_SETTINGS,
  DEFAULT_USERS,
  DEFAULT_INSTANCES,
  emptyLock
};
