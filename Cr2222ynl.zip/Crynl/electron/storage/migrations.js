const logger = require('../utils/logger');
const { DEFAULT_SETTINGS, DEFAULT_USERS, DEFAULT_INSTANCES } = require('./schemas');

function migrateUsers(doc) {
  if (!doc || typeof doc !== 'object') return JSON.parse(JSON.stringify(DEFAULT_USERS));
  if (!doc.version) doc.version = 1;
  if (!Array.isArray(doc.users)) doc.users = [];
  if (doc.version < 2) {
    for (const u of doc.users) {
      u.stats = u.stats || { playtime: 0, launches: 0, lastPlayedAt: null, totalSessions: 0, longestSession: 0 };
      u.preferences = u.preferences || { selectedInstanceId: null };
      u.onboardingCompleted = Boolean(u.onboardingCompleted);
    }
    doc.version = 2;
  }
  return doc;
}

function migrateInstances(doc) {
  if (!doc || typeof doc !== 'object') return JSON.parse(JSON.stringify(DEFAULT_INSTANCES));
  if (Array.isArray(doc)) {
    doc = { version: 1, instances: doc };
  }
  if (!Array.isArray(doc.instances)) doc.instances = [];
  if (doc.version < 2) {
    for (const inst of doc.instances) {
      inst.quickPlay = inst.quickPlay || { enabled: false, server: 'cryndel.ru', port: 25565 };
      inst.preLaunchCommands = inst.preLaunchCommands || [];
      inst.postExitCommands = inst.postExitCommands || [];
      inst.group = inst.group || 'Default';
      inst.modLoader = inst.modLoader || inst.loader || 'vanilla';
      inst.memoryMb = inst.memoryMb || 4096;
    }
    doc.version = 2;
  }
  return doc;
}

function migrateSettings(doc) {
  if (!doc || typeof doc !== 'object') return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  const base = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  const merge = (a, b) => {
    if (!b || typeof b !== 'object' || Array.isArray(b)) return a;
    const out = { ...a };
    for (const k of Object.keys(b)) {
      if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a[k] && typeof a[k] === 'object') {
        out[k] = merge(a[k], b[k]);
      } else if (b[k] !== undefined) {
        out[k] = b[k];
      }
    }
    return out;
  };
  const next = merge(base, doc);
  const prevVersion = Number(doc.version || 0);
  if (prevVersion < 4) {
    // 80% was a bad default; it made every page render clipped.
    if (next.browser && Number(next.browser.zoom) === 80) next.browser.zoom = 100;
    if (next.cabinet && Number(next.cabinet.zoom) === 80) next.cabinet.zoom = 100;
  }
  if (prevVersion < 5) {
    // Widgets and pinned tool buttons are gone from everywhere but Home.
    if (next.ui && next.ui.showWidgets === undefined) next.ui.showWidgets = false;
    if (next.launcher && next.launcher.hideToTrayOnLaunch === undefined) {
      next.launcher.hideToTrayOnLaunch = next.launcher.minimizeToTray !== false;
    }
  }
  if (prevVersion < 6) {
    // The launcher used to hide fully on launch and never come back reliably.
    // Default to minimising, and always restore the window when the game exits.
    if (next.launcher && next.launcher.hideToTrayOnLaunch === true && next.launcher.minimizeToTray !== false) {
      next.launcher.hideToTrayOnLaunch = false;
    }
    if (next.launcher && next.launcher.showOnGameExit === undefined) next.launcher.showOnGameExit = true;
    if (next.launcher && next.launcher.restoreWindowAfterGame === undefined) next.launcher.restoreWindowAfterGame = true;
    if (next.game && next.game.fullscreenOnLaunch === undefined) next.game.fullscreenOnLaunch = false;
    if (next.game && next.game.autoAddServer === undefined) next.game.autoAddServer = true;
    if (next.game && next.game.serverHost === undefined) next.game.serverHost = 'cryndel.ru';
    if (next.game && next.game.serverPort === undefined) next.game.serverPort = 25565;
    if (next.advanced && next.advanced.discordAppId === undefined) next.advanced.discordAppId = '';
  }
  if (prevVersion < 7) {
    // New interface / game toggles. They default to on, matching how the UI
    // behaved before they were configurable.
    if (next.ui) {
      if (next.ui.skinSpin === undefined) next.ui.skinSpin = true;
      if (next.ui.clickSounds === undefined) next.ui.clickSounds = true;
      if (next.ui.homeGreeting === undefined) next.ui.homeGreeting = true;
      if (next.ui.accentGlow === undefined) next.ui.accentGlow = true;
      if (next.ui.uiScale === undefined) next.ui.uiScale = 100;
      if (next.ui.navWidth === undefined) next.ui.navWidth = 92;
      if (next.ui.cardRadius === undefined) next.ui.cardRadius = 18;
      if (next.ui.density === undefined) next.ui.density = 'normal';
      if (next.ui.toolsPos === undefined) next.ui.toolsPos = 'auto';
    }
    if (next.game) {
      if (next.game.toggleSneak === undefined) next.game.toggleSneak = false;
      if (next.game.autoJump === undefined) next.game.autoJump = false;
      if (next.game.rawMouseInput === undefined) next.game.rawMouseInput = true;
      if (next.game.particlesSetting === undefined) next.game.particlesSetting = 'all';
      if (next.game.guiScale === undefined) next.game.guiScale = 0;
    }
  }
  if (prevVersion < 8) {
    // Extra interface + game knobs. Defaults match how the launcher and the
    // game already behaved, so an upgrade never changes anything silently.
    if (next.ui) {
      if (next.ui.glassBlur === undefined) next.ui.glassBlur = 0;
      if (next.ui.panelOpacity === undefined) next.ui.panelOpacity = 100;
      if (next.ui.navIconSize === undefined) next.ui.navIconSize = 18;
      if (next.ui.showStatusBar === undefined) next.ui.showStatusBar = true;
      if (next.ui.toastPos === undefined) next.ui.toastPos = 'bottom';
      if (next.ui.hoverLift === undefined) next.ui.hoverLift = true;
    }
    if (next.game) {
      if (next.game.clouds === undefined) next.game.clouds = 'default';
      if (next.game.smoothLighting === undefined) next.game.smoothLighting = true;
      if (next.game.entityShadows === undefined) next.game.entityShadows = true;
      if (next.game.bobView === undefined) next.game.bobView = true;
      if (next.game.pauseOnLostFocus === undefined) next.game.pauseOnLostFocus = true;
      if (next.game.invertYMouse === undefined) next.game.invertYMouse = false;
      if (next.game.mouseSensitivityPct === undefined) next.game.mouseSensitivityPct = 100;
      if (next.game.gammaPct === undefined) next.game.gammaPct = 50;
      if (next.game.chatOpacityPct === undefined) next.game.chatOpacityPct = 100;
      if (next.game.hudHidden === undefined) next.game.hudHidden = false;
      if (next.game.narrator === undefined) next.game.narrator = 0;
      if (next.game.skinModel === undefined) next.game.skinModel = 'default';
    }
  }
  if (prevVersion < 9) {
    // Interface extras: navigation labels, wallpaper blur, toast duration and the
    // download dock corner. Defaults keep the previous behaviour.
    if (next.ui) {
      if (next.ui.navLabels === undefined) next.ui.navLabels = true;
      if (next.ui.bgBlur === undefined) next.ui.bgBlur = 0;
      if (next.ui.toastDuration === undefined) next.ui.toastDuration = 4200;
      if (next.ui.dockPos === undefined) next.ui.dockPos = 'right';
    }
  }
  if (prevVersion < 10) {
    // Adaptive header, greeting file, plugins and the home action row.
    if (next.ui) {
      if (next.ui.headerAutoHide === undefined) next.ui.headerAutoHide = true;
      if (next.ui.greetingEnabled === undefined) next.ui.greetingEnabled = true;
      if (next.ui.pluginsEnabled === undefined) next.ui.pluginsEnabled = true;
      if (next.ui.homeButtons === undefined) next.ui.homeButtons = true;
    }
  }
  next.version = 10;
  return next;
}

async function runMigrations(vault, files) {
  logger.info('running storage migrations');
  const users = migrateUsers(await vault.read(files.users, DEFAULT_USERS));
  await vault.write(files.users, users);
  const instances = migrateInstances(await vault.read(files.instances, DEFAULT_INSTANCES));
  await vault.write(files.instances, instances);
  const settings = migrateSettings(await vault.read(files.settings, DEFAULT_SETTINGS));
  await vault.write(files.settings, settings);
  return { users, instances, settings };
}

module.exports = { migrateUsers, migrateInstances, migrateSettings, runMigrations };
