const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');
const { CryndelFault, FaultCodes } = require('../utils/errors');

class AtomJsonVault {
  constructor() {
    this.locks = new Map();
  }

  async withLock(file, fn) {
    let release;
    const done = new Promise((ok) => { release = ok; });
    const prev = this.locks.get(file) || Promise.resolve();
    this.locks.set(file, prev.then(() => done, () => done));
    try {
      await prev;
      return await fn();
    } finally {
      release();
    }
  }

  async read(file, fallback) {
    try {
      const exists = await fs.pathExists(file);
      if (!exists) {
        if (fallback !== undefined) {
          await this.write(file, fallback);
          return JSON.parse(JSON.stringify(fallback));
        }
        return null;
      }
      const raw = await fs.readFile(file, 'utf8');
      if (!raw.trim()) {
        return fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : null;
      }
      return JSON.parse(raw);
    } catch (err) {
      logger.error('json-db read failed', { file, message: err.message });
      if (fallback !== undefined) return JSON.parse(JSON.stringify(fallback));
      throw new CryndelFault(FaultCodes.STORAGE, `Cannot read ${file}`);
    }
  }

  async write(file, data) {
    return this.withLock(file, async () => {
      await fs.ensureDir(path.dirname(file));
      const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
      const payload = JSON.stringify(data, null, 2);
      await fs.writeFile(tmp, payload, 'utf8');
      await fs.move(tmp, file, { overwrite: true });
      return data;
    });
  }

  async patch(file, mutator, fallback) {
    return this.withLock(file, async () => {
      let current;
      try {
        const exists = await fs.pathExists(file);
        if (!exists) {
          current = fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : {};
        } else {
          const raw = await fs.readFile(file, 'utf8');
          current = raw.trim() ? JSON.parse(raw) : (fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : {});
        }
      } catch (_) {
        current = fallback !== undefined ? JSON.parse(JSON.stringify(fallback)) : {};
      }
      const next = await mutator(current);
      const result = next === undefined ? current : next;
      await fs.ensureDir(path.dirname(file));
      const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
      await fs.writeFile(tmp, JSON.stringify(result, null, 2), 'utf8');
      await fs.move(tmp, file, { overwrite: true });
      return result;
    });
  }
}

module.exports = new AtomJsonVault();
