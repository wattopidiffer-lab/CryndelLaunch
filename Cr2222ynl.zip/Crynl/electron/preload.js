const { contextBridge, ipcRenderer } = require('electron');

function listen(channel, cb) {
  const wrap = (_e, payload) => cb(payload);
  ipcRenderer.on(channel, wrap);
  return () => ipcRenderer.removeListener(channel, wrap);
}

contextBridge.exposeInMainWorld('cryndel', {
  auth: {
    createOffline: (nick, extra) => ipcRenderer.invoke('auth:createOffline', nick, extra),
    getCurrent: () => ipcRenderer.invoke('auth:getCurrent'),
    logout: () => ipcRenderer.invoke('auth:logout'),
    rename: (nick) => ipcRenderer.invoke('auth:rename', nick),
    patchCurrent: (patch) => ipcRenderer.invoke('auth:patchCurrent', patch)
  },
  instances: {
    list: () => ipcRenderer.invoke('instances:list'),
    get: (id) => ipcRenderer.invoke('instances:get', id),
    create: (dto) => ipcRenderer.invoke('instances:create', dto),
    createFromBuild: (buildId, name) => ipcRenderer.invoke('instances:createFromBuild', buildId, name),
    delete: (id) => ipcRenderer.invoke('instances:delete', id),
    update: (id, patch) => ipcRenderer.invoke('instances:update', id, patch),
    openFolder: (id) => ipcRenderer.invoke('instances:openFolder', id),
    exportMrpack: (id) => ipcRenderer.invoke('instances:exportMrpack', id),
    importMrpack: (meta) => ipcRenderer.invoke('instances:importMrpack', meta),
    catalog: () => ipcRenderer.invoke('instances:catalog'),
    select: (id) => ipcRenderer.invoke('instances:select', id),
    applyExtended: (id) => ipcRenderer.invoke('instances:applyExtended', id),
    rename: (id, name) => ipcRenderer.invoke('instances:rename', id, name),
    patchSodium: (id) => ipcRenderer.invoke('instances:patchSodium', id)
  },
  versions: {
    manifest: () => ipcRenderer.invoke('versions:manifest'),
    ensure: (id) => ipcRenderer.invoke('versions:ensure', id)
  },
  modrinth: {
    search: (params) => ipcRenderer.invoke('modrinth:search', params),
    getProject: (id) => ipcRenderer.invoke('modrinth:getProject', id),
    getVersions: (projectId, filters) => ipcRenderer.invoke('modrinth:getVersions', projectId, filters),
    getVersion: (versionId) => ipcRenderer.invoke('modrinth:getVersion', versionId),
    tags: () => ipcRenderer.invoke('modrinth:tags'),
    install: (instanceId, projectId) => ipcRenderer.invoke('modrinth:install', instanceId, projectId),
    installVersion: (instanceId, versionId) => ipcRenderer.invoke('modrinth:installVersion', instanceId, versionId)
  },
  mods: {
    listInstalled: (instanceId) => ipcRenderer.invoke('mods:listInstalled', instanceId),
    toggle: (instanceId, modId, enabled) => ipcRenderer.invoke('mods:toggle', instanceId, modId, enabled),
    remove: (instanceId, modId) => ipcRenderer.invoke('mods:remove', instanceId, modId),
    pin: (instanceId, modId, pinned) => ipcRenderer.invoke('mods:pin', instanceId, modId, pinned),
    addFromFile: (instanceId) => ipcRenderer.invoke('mods:addFromFile', instanceId),
    installBuiltin: (instanceId, id) => ipcRenderer.invoke('mods:installBuiltin', instanceId, id),
    checkUpdates: (instanceId) => ipcRenderer.invoke('mods:checkUpdates', instanceId),
    applyUpdates: (instanceId, updates) => ipcRenderer.invoke('mods:applyUpdates', instanceId, updates),
    detectConflicts: (instanceId) => ipcRenderer.invoke('mods:detectConflicts', instanceId),
    verifyIntegrity: (instanceId) => ipcRenderer.invoke('mods:verifyIntegrity', instanceId),
    scan: (instanceId) => ipcRenderer.invoke('mods:scan', instanceId),
    hasMod: (instanceId, projectId, filename) => ipcRenderer.invoke('mods:hasMod', instanceId, projectId, filename)
  },
  lockfile: {
    load: (instanceId) => ipcRenderer.invoke('lockfile:load', instanceId),
    export: (instanceId) => ipcRenderer.invoke('lockfile:export', instanceId)
  },
  backup: {
    create: (instanceId, label) => ipcRenderer.invoke('backup:create', instanceId, label),
    createAll: (label) => ipcRenderer.invoke('backup:createAll', label),
    list: (instanceId) => ipcRenderer.invoke('backup:list', instanceId),
    listLauncher: () => ipcRenderer.invoke('backup:listLauncher'),
    restoreLauncher: (backupId) => ipcRenderer.invoke('backup:restoreLauncher', backupId),
    restore: (instanceId, backupId) => ipcRenderer.invoke('backup:restore', instanceId, backupId),
    delete: (instanceId, backupId) => ipcRenderer.invoke('backup:delete', instanceId, backupId)
  },
  game: {
    launch: (instanceId) => ipcRenderer.invoke('game:launch', instanceId),
    kill: (instanceId) => ipcRenderer.invoke('game:kill', instanceId),
    isRunning: (instanceId) => ipcRenderer.invoke('game:isRunning', instanceId),
    anyRunning: () => ipcRenderer.invoke('game:anyRunning'),
    cancel: () => ipcRenderer.invoke('game:cancel'),
    onLog: (cb) => listen('game:log', cb),
    onProgress: (cb) => listen('game:progress', cb),
    onClose: (cb) => listen('game:close', cb),
    onCrash: (cb) => listen('game:crash', cb)
  },
  screenshots: {
    list: (limit) => ipcRenderer.invoke('screenshots:list', limit),
    open: (p) => ipcRenderer.invoke('screenshots:open', p),
    openFolder: (p) => ipcRenderer.invoke('screenshots:openFolder', p),
    dataUrl: (p) => ipcRenderer.invoke('screenshots:dataUrl', p),
    copy: (p) => ipcRenderer.invoke('screenshots:copy', p),
    onNew: (cb) => listen('screenshots:new', cb)
  },
  liveNick: {
    status: () => ipcRenderer.invoke('liveNick:status'),
    start: (port) => ipcRenderer.invoke('liveNick:start', port),
    change: (newNick) => ipcRenderer.invoke('liveNick:change', newNick),
    onStatusChange: (cb) => listen('liveNick:statusChange', cb)
  },
  ram: {
    suggest: () => ipcRenderer.invoke('ram:suggest')
  },
  server: {
    ping: (host, port) => ipcRenderer.invoke('server:ping', host, port),
    query: (host, port) => ipcRenderer.invoke('server:query', host, port)
  },
  skins: {
    list: () => ipcRenderer.invoke('skins:list'),
    importFile: () => ipcRenderer.invoke('skins:importFile'),
    fromNick: (nick) => ipcRenderer.invoke('skins:fromNick', nick),
    preview: (p) => ipcRenderer.invoke('skins:preview', p),
    apply: (p, instanceId) => ipcRenderer.invoke('skins:apply', p, instanceId),
    importCape: () => ipcRenderer.invoke('skins:importCape'),
    clearCape: () => ipcRenderer.invoke('skins:clearCape'),
    capePreview: () => ipcRenderer.invoke('skins:capePreview')
  },
  theme: {
    read: () => ipcRenderer.invoke('theme:read'),
    write: (css) => ipcRenderer.invoke('theme:write', css),
    import: () => ipcRenderer.invoke('theme:import'),
    clear: () => ipcRenderer.invoke('theme:clear'),
    pickBackground: () => ipcRenderer.invoke('theme:pickBackground'),
    pickSplash: () => ipcRenderer.invoke('theme:pickSplash'),
    pickFurryImage: () => ipcRenderer.invoke('theme:pickFurryImage'),
    pickFurrySounds: () => ipcRenderer.invoke('theme:pickFurrySounds')
  },
  media: {
    logoUrl: () => ipcRenderer.invoke('media:logoUrl'),
    splashUrl: () => ipcRenderer.invoke('media:splashUrl'),
    bgVideoUrl: () => ipcRenderer.invoke('media:bgVideoUrl'),
    bgImageUrl: () => ipcRenderer.invoke('media:bgImageUrl'),
    playFurry: () => ipcRenderer.invoke('media:playFurry')
  },
  sounds: {
    payload: () => ipcRenderer.invoke('sounds:payload'),
    list: () => ipcRenderer.invoke('sounds:list'),
    pick: (event) => ipcRenderer.invoke('sounds:pick', event),
    clear: (event) => ipcRenderer.invoke('sounds:clear', event),
    reset: () => ipcRenderer.invoke('sounds:reset'),
    music: () => ipcRenderer.invoke('sounds:music'),
    regenerate: () => ipcRenderer.invoke('sounds:regenerate')
  },
  catalog: {
    extraMods: () => ipcRenderer.invoke('catalog:extraMods'),
    comfortPacks: () => ipcRenderer.invoke('catalog:comfortPacks'),
    recommended: () => ipcRenderer.invoke('catalog:recommended')
  },
  onboard: {
    comfort: (nick, opts) => ipcRenderer.invoke('onboard:comfort', nick, opts)
  },
  notes: {
    load: (id) => ipcRenderer.invoke('notes:load', id),
    save: (id, text) => ipcRenderer.invoke('notes:save', id, text)
  },
  settings: {
    get: (key) => ipcRenderer.invoke('settings:get', key),
    set: (key, v) => ipcRenderer.invoke('settings:set', key, v),
    getAll: () => ipcRenderer.invoke('settings:getAll'),
    reset: () => ipcRenderer.invoke('settings:reset'),
    onChanged: (cb) => listen('settings:changed', cb)
  },
  system: {
    openExternal: (url) => ipcRenderer.invoke('system:openExternal', url),
    selectDirectory: () => ipcRenderer.invoke('system:selectDirectory'),
    openPath: (rel) => ipcRenderer.invoke('system:openPath', rel),
    detectJava: () => ipcRenderer.invoke('system:detectJava'),
    copyToClipboard: (text) => ipcRenderer.invoke('system:copyToClipboard', text),
    getStorageInfo: () => ipcRenderer.invoke('system:getStorageInfo'),
    clearCache: (type) => ipcRenderer.invoke('system:clearCache', type),
    gpus: () => ipcRenderer.invoke('system:gpus')
  },
  discord: {
    toggle: (on) => ipcRenderer.invoke('discord:toggle', on),
    status: () => ipcRenderer.invoke('discord:status'),
    configure: (appId) => ipcRenderer.invoke('discord:configure', appId)
  },
  health: {
    getStatus: (instanceId) => ipcRenderer.invoke('health:getStatus', instanceId),
    analyzeCrash: (instanceId) => ipcRenderer.invoke('health:analyzeCrash', instanceId),
    fixInstance: (instanceId, action) => ipcRenderer.invoke('health:fixInstance', instanceId, action),
    autoFix: (instanceId) => ipcRenderer.invoke('health:autoFix', instanceId),
    getTimeline: (instanceId) => ipcRenderer.invoke('health:getTimeline', instanceId)
  },
  inbox: {
    list: () => ipcRenderer.invoke('inbox:list'),
    dir: () => ipcRenderer.invoke('inbox:dir'),
    openDir: () => ipcRenderer.invoke('inbox:openDir'),
    downloadUrl: (url, filename) => ipcRenderer.invoke('inbox:downloadUrl', url, filename),
    importToInstance: (filePath, instanceId) => ipcRenderer.invoke('inbox:importToInstance', filePath, instanceId),
    importMrpackPath: (filePath, meta) => ipcRenderer.invoke('inbox:importMrpackPath', filePath, meta),
    importAsResourcepack: (filePath, instanceId) => ipcRenderer.invoke('inbox:importAsResourcepack', filePath, instanceId),
    onProgress: (cb) => listen('inbox:progress', cb),
    onSaved: (cb) => listen('inbox:saved', cb)
  },
  java: {
    ensure: (major) => ipcRenderer.invoke('java:ensure', major)
  },
  app: {
    getVersion: () => ipcRenderer.invoke('app:getVersion')
  },
  greeting: {
    pick: (nick) => ipcRenderer.invoke('greeting:pick', nick),
    read: () => ipcRenderer.invoke('greeting:read'),
    write: (greetings) => ipcRenderer.invoke('greeting:write', greetings),
    openFile: () => ipcRenderer.invoke('greeting:openFile')
  },
  plugins: {
    list: () => ipcRenderer.invoke('plugins:list'),
    reload: () => ipcRenderer.invoke('plugins:reload'),
    warnings: () => ipcRenderer.invoke('plugins:warnings'),
    dir: () => ipcRenderer.invoke('plugins:dir'),
    openDir: () => ipcRenderer.invoke('plugins:openDir'),
    install: () => ipcRenderer.invoke('plugins:install'),
    installPath: (zipPath) => ipcRenderer.invoke('plugins:installPath', zipPath),
    remove: (id) => ipcRenderer.invoke('plugins:remove', id),
    emit: (hook, payload) => ipcRenderer.invoke('plugins:emit', hook, payload)
  },
  publish: {
    build: (instanceId, destPath) => ipcRenderer.invoke('publish:build', instanceId, destPath),
    inspect: (filePath) => ipcRenderer.invoke('publish:inspect', filePath),
    pick: () => ipcRenderer.invoke('publish:pick'),
    import: (filePath, name) => ipcRenderer.invoke('publish:import', filePath, name)
  },
  browser: {
    onOpen: (cb) => listen('browser:open', cb)
  },
  hotkey: {
    on: (cb) => listen('hotkey', cb)
  },
  window: {
    minimize: () => ipcRenderer.invoke('window:minimize'),
    maximize: () => ipcRenderer.invoke('window:maximize'),
    fullscreen: () => ipcRenderer.invoke('window:fullscreen'),
    close: () => ipcRenderer.invoke('window:close'),
    show: () => ipcRenderer.invoke('window:show'),
    state: () => ipcRenderer.invoke('window:state'),
    setZoom: (factor) => ipcRenderer.invoke('window:setZoom', factor),
    onState: (cb) => listen('window:state', cb)
  }
});
