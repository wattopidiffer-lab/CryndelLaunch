const { Tray, Menu, nativeImage, app } = require('electron');
const path = require('path');
const fs = require('fs');

class DockNudge {
  constructor() {
    this.tray = null;
    this.opener = null;
  }

  attach(win, opener) {
    if (opener) this.opener = opener;
    const iconPath = path.join(__dirname, '..', 'assets', 'icon.png');
    let image = nativeImage.createEmpty();
    if (fs.existsSync(iconPath)) image = nativeImage.createFromPath(iconPath);
    if (image.isEmpty()) image = nativeImage.createFromDataURL(
      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAHklEQVQ4T2NkYGD4z0ABYBw1gGE0DBjGwDAaBgyDAQAAFvkCAeuS7aQAAAAASUVORK5CYII='
    );
    this.tray = new Tray(image.resize({ width: 16, height: 16 }));
    this.tray.setToolTip('Cryndel Launcher');
    this.tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Открыть', click: () => this.reveal(win) },
      { type: 'separator' },
      { label: 'Выход', click: () => app.quit() }
    ]));
    this.tray.on('click', () => this.reveal(win));
    return this.tray;
  }

  // Prefer the injected opener: it can recreate the window if it was really
  // closed, which the stale `win` reference cannot do.
  reveal(win) {
    if (this.opener) {
      try {
        const res = this.opener();
        if (res) return res;
      } catch (_) { /* fall through */ }
    }
    if (!win || win.isDestroyed()) return null;
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
    return win;
  }
}

module.exports = DockNudge;
