const { ipcMain } = require('electron');

function bindAuthIpc(hub) {
  ipcMain.handle('auth:createOffline', async (_e, nick, extra) => {
    const user = await hub.auth.createOffline(nick, { onboardingCompleted: true, ...(extra || {}) });
    return { ok: true, user };
  });
  ipcMain.handle('auth:getCurrent', async () => hub.auth.getCurrent());
  ipcMain.handle('auth:logout', async () => hub.auth.logout());
  ipcMain.handle('auth:rename', async (_e, nick) => hub.auth.rename(nick));
  ipcMain.handle('auth:patchCurrent', async (_e, patch) => hub.auth.patchCurrent(patch || {}));
}

module.exports = bindAuthIpc;
