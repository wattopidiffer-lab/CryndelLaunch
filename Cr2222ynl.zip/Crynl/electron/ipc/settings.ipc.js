const { ipcMain } = require('electron');

// Every window that shows settings must hear about a change, otherwise the UI
// keeps stale values and appears to "break" until a restart.
function broadcastSetting(hub, key, value) {
  const wins = hub.panes && hub.panes.all ? hub.panes.all() : [hub.window];
  for (const win of wins) {
    if (win && !win.isDestroyed()) win.webContents.send('settings:changed', { key, value });
  }
}

function bindSettingsIpc(hub) {
  ipcMain.handle('settings:get', async (_e, key) => hub.settings.get(key));
  ipcMain.handle('settings:set', async (_e, key, v) => {
    await hub.settings.set(key, v);
    broadcastSetting(hub, key, v);
    return { ok: true };
  });
  ipcMain.handle('settings:getAll', async () => hub.settings.getAll());
  ipcMain.handle('settings:reset', async () => {
    const fresh = await hub.settings.reset();
    broadcastSetting(hub, null, null);
    return fresh;
  });
}

module.exports = bindSettingsIpc;
module.exports.broadcastSetting = broadcastSetting;
