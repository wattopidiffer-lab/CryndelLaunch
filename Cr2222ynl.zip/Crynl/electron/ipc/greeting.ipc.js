const { ipcMain, dialog } = require('electron');

// Greetings live in data/greetings.json. The renderer reads the resolved text
// for the current nick; the settings screen can edit the buckets.
function bindGreetingIpc(hub) {
  ipcMain.handle('greeting:pick', async (_e, nick) => {
    try { return { ok: true, text: await hub.greetings.pick(nick) }; } catch (err) { return { ok: false, error: err.message }; }
  });
  ipcMain.handle('greeting:read', async () => {
    try { return { ok: true, greetings: await hub.greetings.read() }; } catch (err) { return { ok: false, error: err.message }; }
  });
  ipcMain.handle('greeting:write', async (_e, greetings) => {
    try { return { ok: true, greetings: await hub.greetings.write(greetings || {}) }; } catch (err) { return { ok: false, error: err.message }; }
  });
  ipcMain.handle('greeting:openFile', async () => {
    const { shell } = require('electron');
    try {
      const file = await hub.greetings.ensure();
      shell.showItemInFolder(file);
      return { ok: true, path: file };
    } catch (err) { return { ok: false, error: err.message }; }
  });
}

module.exports = bindGreetingIpc;
