const { ipcMain } = require('electron');

function bindModsIpc(hub) {
  ipcMain.handle('mods:listInstalled', async (_e, instanceId) => hub.mods.listInstalled(instanceId));
  ipcMain.handle('mods:toggle', async (_e, instanceId, modId, enabled) => hub.mods.toggle(instanceId, modId, enabled));
  ipcMain.handle('mods:remove', async (_e, instanceId, modId) => {
    const r = await hub.mods.remove(instanceId, modId);
    await hub.timeline.append(instanceId, 'mod', `Removed ${modId}`);
    return r;
  });
  ipcMain.handle('mods:pin', async (_e, instanceId, modId, pinned) => hub.mods.pin(instanceId, modId, pinned));
  ipcMain.handle('mods:addFromFile', async (_e, instanceId) => hub.mods.addFromFile(instanceId, hub.window));
  ipcMain.handle('mods:checkUpdates', async (_e, instanceId) => hub.mods.checkAllUpdates(instanceId));
  ipcMain.handle('mods:applyUpdates', async (_e, instanceId, updates) => {
    const inst = await hub.instances.get(instanceId);
    await hub.backups.create(inst, 'pre-update');
    const done = [];
    for (const u of updates || []) {
      const res = await hub.resolver.resolveAndInstall(instanceId, u.latestVersionId, new Set(), {
        loader: inst.modLoader,
        mcVersion: inst.mcVersion
      });
      done.push(...hub.resolver.flatten(res));
    }
    await hub.timeline.append(instanceId, 'update', `Applied ${done.length} updates`);
    return { ok: true, done };
  });
  ipcMain.handle('mods:detectConflicts', async (_e, instanceId) => hub.mods.detectConflicts(instanceId));
  ipcMain.handle('mods:verifyIntegrity', async (_e, instanceId) => hub.mods.verifyIntegrity(instanceId));
  ipcMain.handle('mods:scan', async (_e, instanceId) => hub.mods.scanInstance(instanceId));
  ipcMain.handle('mods:hasMod', async (_e, instanceId, projectId, filename) => hub.mods.hasMod(instanceId, projectId, filename));
  ipcMain.handle('mods:installBuiltin', async (_e, instanceId, id) => {
    const fs = require('fs-extra');
    const path = require('path');
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Сборка не найдена');
    const dir = path.join(__dirname, '..', '..', 'Vstroymods');
    await fs.ensureDir(dir);
    const names = await fs.readdir(dir);
    const match = names.find((n) => n.toLowerCase().startsWith(String(id).toLowerCase()) && n.endsWith('.jar'));
    if (!match) throw new Error('Встроенный мод ' + id + ' не найден в /Vstroymods');
    const src = path.join(dir, match);
    const dest = path.join(inst.gameDir, 'mods', match);
    await fs.ensureDir(path.dirname(dest));
    await fs.copy(src, dest, { overwrite: true });
    return { ok: true, dest };
  });
}

module.exports = bindModsIpc;
