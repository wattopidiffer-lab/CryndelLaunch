const { ipcMain, dialog, nativeImage } = require('electron');
const { broadcastSetting } = require('./settings.ipc');
const fs = require('fs-extra');
const path = require('path');
const { pathToFileURL } = require('url');

// file:// URLs must be percent-encoded: a Windows profile such as
// `C:\Users\Иван\...` or any folder with a space produced a URL the renderer
// could not load, which is why wallpapers, the splash and custom skins silently
// failed to appear (and never survived a restart).
function fileUrl(p) {
  if (!p) return '';
  try { return pathToFileURL(String(p)).href; } catch (_) { return ''; }
}

function bindExtrasIpc(hub) {
  ipcMain.handle('ram:suggest', async () => hub.suggestMemoryMb());
  ipcMain.handle('server:ping', async (_e, host, port) => hub.pingHost(host || 'cryndel.ru', port || 25565));
  ipcMain.handle('server:query', async (_e, host, port) => hub.queryServer(host || 'cryndel.ru', port || 25565));

  // ---- Sounds -------------------------------------------------------------
  // The renderer asks for every URL at boot; `setSound` swaps one event's file
  // and answers with the new URL so the change applies without a restart.
  ipcMain.handle('sounds:payload', async () => hub.sounds.payload());
  ipcMain.handle('sounds:list', async () => {
    const data = await hub.sounds.payload();
    const files = await hub.settings.get('ui.soundFiles').catch(() => ({})) || {};
    return Object.keys(data.sounds).map((event) => ({
      event,
      url: data.sounds[event],
      custom: Boolean(files[event]),
      volume: 1
    }));
  });
  ipcMain.handle('sounds:pick', async (_e, event) => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Звук', extensions: ['mp3', 'ogg', 'wav', 'm4a'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const res = await hub.sounds.setCustom(event, picked.filePaths[0]);
    broadcastSetting(hub, `ui.soundFiles.${event}`, picked.filePaths[0]);
    return { ok: true, ...res };
  });
  ipcMain.handle('sounds:clear', async (_e, event) => {
    await hub.sounds.setCustom(event, '');
    broadcastSetting(hub, `ui.soundFiles.${event}`, '');
    return { ok: true, url: await hub.sounds.url(await hub.sounds.resolve(event)) };
  });
  ipcMain.handle('sounds:reset', async () => {
    await hub.sounds.resetAll();
    broadcastSetting(hub, 'ui.soundFiles', {});
    return hub.sounds.payload();
  });
  ipcMain.handle('sounds:music', async () => hub.sounds.listMusic().then(async (files) => {
    const out = [];
    for (const f of files) out.push({ name: require('path').basename(f), url: await hub.sounds.url(f) });
    return out;
  }));

  // Downloads the fallback sounds again (e.g. after the user deleted them).
  ipcMain.handle('sounds:regenerate', async () => {
    await hub.sounds.ensureAllDefaults();
    return hub.sounds.payload();
  });

  ipcMain.handle('skins:list', async () => hub.skins.list());
  ipcMain.handle('skins:importFile', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'PNG скин', extensions: ['png'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const dest = await hub.skins.importFile(picked.filePaths[0]);
    await hub.auth.patchCurrent({ skin: { type: 'file', model: 'classic', path: dest } });
    return { ok: true, path: dest };
  });
  ipcMain.handle('skins:fromNick', async (_e, nick) => {
    const dest = await hub.skins.fetchByNick(nick);
    await hub.auth.patchCurrent({ skin: { type: 'nick', model: 'classic', path: dest, nick } });
    return { ok: true, path: dest };
  });
  ipcMain.handle('skins:preview', async (_e, filePath) => {
    if (!filePath) return null;
    return hub.skins.toDataUrl(filePath);
  });
  ipcMain.handle('skins:apply', async (_e, filePath, instanceId) => {
    const inst = instanceId ? await hub.instances.get(instanceId) : null;
    if (!inst) throw new Error('Сборка не выбрана');
    const dest = await hub.skins.applyToInstance(filePath, inst);
    return { ok: true, dest };
  });

  // Client-side capes: any PNG the player owns. Stored like skins and copied
  // into the instance on launch, so it shows up without a server account.
  ipcMain.handle('skins:importCape', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Плащ PNG', extensions: ['png'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const dest = await hub.skins.importCape(picked.filePaths[0]);
    await hub.settings.set('game.capeFile', dest);
    await hub.settings.set('game.capeEnabled', true);
    broadcastSetting(hub, 'game.capeFile', dest);
    return { ok: true, path: dest };
  });
  ipcMain.handle('skins:clearCape', async () => {
    await hub.settings.set('game.capeFile', '');
    await hub.settings.set('game.capeEnabled', false);
    broadcastSetting(hub, 'game.capeFile', '');
    return { ok: true };
  });
  ipcMain.handle('skins:capePreview', async () => {
    const p = await hub.settings.get('game.capeFile').catch(() => '');
    if (!p) return null;
    try { return await hub.skins.toDataUrl(p); } catch (_) { return null; }
  });

  ipcMain.handle('theme:read', async () => hub.themes.readCustom());
  ipcMain.handle('theme:import', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'CSS', extensions: ['css'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const dest = await hub.themes.importCss(picked.filePaths[0]);
    const css = await hub.themes.readCustom();
    return { ok: true, path: dest, css };
  });
  ipcMain.handle('theme:clear', async () => hub.themes.clear());
  ipcMain.handle('theme:write', async (_e, css) => {
    const res = await hub.themes.writeCustom(css);
    // Nudge the renderer so the new CSS is re-read and applied immediately.
    broadcastSetting(hub, 'ui.customCss', null);
    return res;
  });
  ipcMain.handle('theme:pickBackground', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Фон', extensions: ['mp4', 'webm', 'png', 'jpg', 'jpeg', 'webp', 'gif'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const src = picked.filePaths[0];
    const ext = path.extname(src).toLowerCase();
    const destDir = path.join(require('../utils/paths').dataDir(), 'media');
    await fs.ensureDir(destDir);
    const dest = path.join(destDir, 'custom-bg' + ext);
    await fs.copy(src, dest, { overwrite: true });
    const kind = ['.mp4', '.webm'].includes(ext) ? 'video' : 'image';
    // Apply immediately: the renderer listens for settings:changed and swaps the
    // wallpaper in place, so no restart is needed.
    await hub.settings.set('ui.backgroundFile', dest);
    await hub.settings.set('ui.backgroundKind', kind);
    broadcastSetting(hub, 'ui.backgroundFile', dest);
    broadcastSetting(hub, 'ui.backgroundKind', kind);
    return { ok: true, path: dest, kind, pending: false };
  });
  ipcMain.handle('theme:pickSplash', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Видео', extensions: ['mp4', 'webm'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const destDir = path.join(require('../utils/paths').dataDir(), 'media');
    await fs.ensureDir(destDir);
    const ext = path.extname(picked.filePaths[0]).toLowerCase();
    const dest = path.join(destDir, 'splash' + ext);
    await fs.copy(picked.filePaths[0], dest, { overwrite: true });
    await hub.settings.set('ui.splashFile', dest);
    broadcastSetting(hub, 'ui.splashFile', dest);
    return { ok: true, path: dest };
  });
  ipcMain.handle('theme:pickFurryImage', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Картинка', extensions: ['png', 'webp', 'gif', 'jpg', 'jpeg'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const destDir = path.join(require('../utils/paths').dataDir(), 'media');
    await fs.ensureDir(destDir);
    const ext = path.extname(picked.filePaths[0]).toLowerCase();
    const dest = path.join(destDir, 'furry' + ext);
    await fs.copy(picked.filePaths[0], dest, { overwrite: true });
    await hub.settings.set('ui.furryImage', fileUrl(dest));
    return { ok: true, path: dest };
  });
  ipcMain.handle('theme:pickFurrySounds', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Звук', extensions: ['mp3', 'ogg', 'wav', 'm4a'] }]
    });
    if (picked.canceled || !picked.filePaths.length) return { ok: false, cancelled: true };
    const destDir = path.join(require('../utils/paths').dataDir(), 'media', 'furry-sounds');
    await fs.ensureDir(destDir);
    const saved = [];
    for (const src of picked.filePaths.slice(0, 3)) {
      const dest = path.join(destDir, path.basename(src));
      await fs.copy(src, dest, { overwrite: true });
      saved.push(dest);
    }
    await hub.settings.set('ui.furrySounds', saved);
    return { ok: true, files: saved };
  });
  ipcMain.handle('media:playFurry', async () => {
    const custom = await hub.settings.get('ui.furrySounds');
    const list = Array.isArray(custom) && custom.length ? custom : [];
    if (!list.length) {
      const dir = path.join(__dirname, '..', '..', 'muzick');
      if (await fs.pathExists(dir)) {
        const names = (await fs.readdir(dir)).filter((n) => /\.(mp3|ogg|wav|m4a)$/i.test(n));
        for (const n of names) list.push(path.join(dir, n));
      }
    }
    if (!list.length) return { ok: false };
    const pick = list[Math.floor(Math.random() * list.length)];
    return { ok: true, url: fileUrl(pick) };
  });

  function mediaFile(...bits) {
    return path.join(__dirname, '..', '..', 'images', ...bits);
  }
  async function firstExisting(candidates) {
    for (const p of candidates) {
      if (await fs.pathExists(p)) return fileUrl(p);
    }
    return '';
  }
  ipcMain.handle('media:logoUrl', async () => firstExisting([
    mediaFile('icon', 'logo.png'),
    path.join(__dirname, '..', '..', 'assets', 'logo.png')
  ]));
  ipcMain.handle('media:splashUrl', async () => {
    const custom = await hub.settings.get('ui.splashFile');
    if (custom && await fs.pathExists(custom)) return fileUrl(custom);
    return firstExisting([
      mediaFile('splash', 'intro.mp4'),
      mediaFile('splash', 'intro.webm'),
      mediaFile('заставка', 'intro.mp4')
    ]);
  });
  ipcMain.handle('media:bgVideoUrl', async () => {
    const custom = await hub.settings.get('ui.backgroundFile');
    if (custom && await fs.pathExists(custom) && /\.(mp4|webm)$/i.test(custom)) {
      return fileUrl(custom);
    }
    return firstExisting([
      mediaFile('фон', 'bg.mp4'),
      mediaFile('фон', 'bg.webm'),
      mediaFile('background', 'bg.mp4'),
      mediaFile('video', 'bg.mp4')
    ]);
  });
  ipcMain.handle('media:bgImageUrl', async () => {
    const custom = await hub.settings.get('ui.backgroundFile');
    if (custom && await fs.pathExists(custom) && /\.(png|jpe?g|webp|gif)$/i.test(custom)) {
      return fileUrl(custom);
    }
    return firstExisting([
      mediaFile('фон', 'bg.png'),
      mediaFile('фон', 'bg.jpg'),
      mediaFile('background', 'bg.png')
    ]);
  });
  ipcMain.handle('catalog:extraMods', async () => readJson(path.join(__dirname, '..', '..', 'resources', 'extra-mods.json')));
  ipcMain.handle('catalog:comfortPacks', async () => readJson(path.join(__dirname, '..', '..', 'resources', 'comfort-packs.json')));
  ipcMain.handle('catalog:recommended', async () => readJson(path.join(__dirname, '..', '..', 'resources', 'recommended-mods.json')));

  async function readJson(file) {
    try { return await fs.readJson(file); } catch (_) { return {}; }
  }

  ipcMain.handle('screenshots:dataUrl', async (_e, filePath) => {
    if (!filePath || !(await fs.pathExists(filePath))) return null;
    const img = nativeImage.createFromPath(filePath);
    if (img.isEmpty()) {
      const buf = await fs.readFile(filePath);
      return `data:image/png;base64,${buf.toString('base64')}`;
    }
    return img.resize({ width: 480, quality: 'better' }).toDataURL();
  });

  ipcMain.handle('notes:load', async (_e, instanceId) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) return '';
    const file = path.join(inst.gameDir, 'cryndel-notes.txt');
    if (!(await fs.pathExists(file))) return '';
    return fs.readFile(file, 'utf8');
  });
  ipcMain.handle('notes:save', async (_e, instanceId, text) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Сборка не найдена');
    const file = path.join(inst.gameDir, 'cryndel-notes.txt');
    await fs.writeFile(file, String(text || ''), 'utf8');
    return { ok: true };
  });
}

module.exports = bindExtrasIpc;
module.exports.fileUrl = fileUrl;
