const { ipcMain } = require('electron');

function bindScreenshotsIpc(hub) {
  ipcMain.handle('screenshots:list', async (_e, limit) => {
    const instances = await hub.instances.list();
    return hub.shots.list(limit, instances);
  });
  ipcMain.handle('screenshots:open', async (_e, p) => hub.shots.open(p));
  ipcMain.handle('screenshots:openFolder', async (_e, p) => hub.shots.openFolder(p));
  ipcMain.handle('screenshots:copy', async (_e, p) => {
    const { clipboard, nativeImage } = require('electron');
    const img = nativeImage.createFromPath(p);
    if (img.isEmpty()) throw new Error('Не удалось прочитать фото');
    clipboard.writeImage(img);
    return { ok: true };
  });
}

module.exports = bindScreenshotsIpc;
