const { ipcMain } = require('electron');

function bindLiveNickIpc(hub) {
  ipcMain.handle('liveNick:status', async () => hub.liveNick.status());
  ipcMain.handle('liveNick:start', async (_e, port) => hub.liveNick.start(port || 21999));
  ipcMain.handle('liveNick:change', async (_e, newNick) => {
    if (!hub.liveNick.wss) {
      const all = await hub.settings.getAll();
      const port = (all.advanced && all.advanced.liveNick && all.advanced.liveNick.wsPort) || 21999;
      await hub.liveNick.start(port);
    }
    const user = await hub.auth.rename(newNick);
    const delivered = await hub.liveNick.change(newNick);
    return { ok: true, user, delivered };
  });
}

module.exports = bindLiveNickIpc;
