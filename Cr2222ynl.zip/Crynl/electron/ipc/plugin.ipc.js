const { ipcMain, dialog, shell } = require('electron');

// Plugin surface: list, install (folder or .zip), toggle, remove, and the
// accumulated warnings so the UI can show "plugin X failed" without dying.
function bindPluginIpc(hub) {
  ipcMain.handle('plugins:list', async () => hub.plugins.list());
  ipcMain.handle('plugins:reload', async () => {
    hub.plugins.loaded.clear();
    hub.plugins.hooks.clear();
    return hub.plugins.loadAll();
  });
  ipcMain.handle('plugins:warnings', async () => hub.plugins.warnings);
  ipcMain.handle('plugins:dir', async () => hub.plugins.dir());
  ipcMain.handle('plugins:openDir', async () => {
    const dir = await hub.plugins.ensure();
    const err = await shell.openPath(dir);
    return err ? { ok: false, error: err } : { ok: true, path: dir };
  });
  ipcMain.handle('plugins:install', async () => {
    const picked = await dialog.showOpenDialog(hub.window || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Плагин Cryndel', extensions: ['zip'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    const res = await hub.plugins.installFromZip(picked.filePaths[0]);
    if (res.ok) await hub.plugins.loadOne(res.id);
    return res;
  });
  ipcMain.handle('plugins:installPath', async (_e, zipPath) => {
    const res = await hub.plugins.installFromZip(zipPath);
    if (res.ok) await hub.plugins.loadOne(res.id);
    return res;
  });
  ipcMain.handle('plugins:remove', async (_e, id) => hub.plugins.remove(id));
  ipcMain.handle('plugins:emit', async (_e, hook, payload) => hub.plugins.emit(hook, payload));
}

module.exports = bindPluginIpc;
