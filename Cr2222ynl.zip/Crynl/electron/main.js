const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs-extra');
const logger = require('./utils/logger');
const CryndelPathVault = require('./utils/paths');
const vault = require('./storage/json-db');
const { runMigrations } = require('./storage/migrations');
const PaneSmith = require('./window-manager');
const DockNudge = require('./tray-manager');
const PulseRefresh = require('./auto-updater');
const wireAllIpc = require('./ipc/ipc-router');
const { installPopupGuard } = require('./popup-guard');
const ModrinthHarbor = require('./managers/modrinth-client');
const LedgerKeeper = require('./managers/lockfile-manager');
const { StreamHauler } = require('./managers/download-manager');
const WeavePlanner = require('./managers/dependency-resolver');
const CrateShepherd = require('./managers/mod-manager');
const ShadowPassKeeper = require('./managers/auth-manager');
const ForgeCluster = require('./managers/instance-manager');
const EmberFinder = require('./managers/java-detector');
const EmberPilot = require('./managers/game-launcher');
const VaultSnapshot = require('./managers/backup-manager');
const FrameLedger = require('./managers/screenshot-manager');
const EchoAliasBridge = require('./managers/live-nick-bridge');
const PresenceBeacon = require('./managers/discord-rpc-manager');
const Hourglass = require('./managers/playtime-tracker');
const DialBoard = require('./managers/settings-manager');
const PulseClinic = require('./managers/health-manager');
const TraceRibbon = require('./managers/timeline-store');
const InboxBay = require('./managers/inbox-manager');
const SkinAtelier = require('./managers/skin-manager');
const ThemeWeaver = require('./managers/theme-manager');
const SoundForge = require('./managers/sound-manager');
const GreetingLoom = require('./managers/greeting-manager');
const PluginForge = require('./managers/plugin-manager');
const PackPublisher = require('./managers/pack-publisher');
const { pingHost, queryServer } = require('./managers/server-pulse');
const { suggestMemoryMb } = require('./managers/ram-advisor');

if (process.platform === 'win32') {
  app.commandLine.appendSwitch('--disable-gpu-sandbox');
}

class CryndelKernel {
  constructor() {
    this.panes = new PaneSmith();
    this.tray = new DockNudge();
    this.updater = new PulseRefresh();
    this.hub = null;
  }

  async boot() {
    await fs.ensureDir(CryndelPathVault.dataDir());
    await fs.ensureDir(CryndelPathVault.lockfilesDir());
    await fs.ensureDir(CryndelPathVault.backupsDir());
    await fs.ensureDir(CryndelPathVault.modCacheDir());
    await fs.ensureDir(path.dirname(CryndelPathVault.timelineFile('x')));

    // Any popup (target=_blank, window.open, "download in new tab") must stay
    // inside the launcher browser instead of spawning a bare Electron window.
    // The URL is queued as well as broadcast: if the renderer is still booting
    // (or the window was hidden) the message alone would be dropped, which is
    // why the in-app browser used to open only some of the time.
    this.pendingBrowserUrls = [];
    app.on('web-contents-created', (_e, contents) => {
      contents.setWindowOpenHandler(({ url }) => {
        this.routeToBrowser(url);
        return { action: 'deny' };
      });
    });

    // Hard guarantee that no stray Electron window can appear. See
    // popup-guard.js — the ordering bug there (main window destroyed during its
    // own construction) is what made the launcher exit right after boot.
    this.allowedWindows = installPopupGuard({
      app,
      panes: this.panes,
      routeToBrowser: (url) => this.routeToBrowser(url)
    });

    await runMigrations(vault, {
      users: CryndelPathVault.usersFile(),
      instances: CryndelPathVault.instancesFile(),
      settings: CryndelPathVault.settingsFile()
    });

    const settings = new DialBoard();
    const auth = new ShadowPassKeeper();
    const modrinth = new ModrinthHarbor();
    const lockfile = new LedgerKeeper();
    const hauler = new StreamHauler();
    const mods = new CrateShepherd({ hauler, lockfile, modrinth, settings });
    const resolver = new WeavePlanner(modrinth, mods);
    const timeline = new TraceRibbon();
    const instances = new ForgeCluster({ lockfile, modrinth, resolver, timeline });
    const java = new EmberFinder();
    const backups = new VaultSnapshot();
    const shots = new FrameLedger();
    const liveNick = new EchoAliasBridge();
    const discord = new PresenceBeacon();
    const playtime = new Hourglass();
    const health = new PulseClinic({ lockfile, mods, backups, timeline });
    const inbox = new InboxBay();
    const skins = new SkinAtelier();
    const themes = new ThemeWeaver();
    const sounds = new SoundForge(settings);
    const greetings = new GreetingLoom();
    const plugins = new PluginForge({ settings });
    const publisher = new PackPublisher({ instances });
    await inbox.ensure();
    await skins.ensure();
    await themes.ensure();
    await sounds.ensure();
    await greetings.ensure();
    await plugins.ensure();
    // Generate the fallback sounds once at boot so the first click already has
    // something pleasant to play, even with an empty `muzick` folder.
    await sounds.ensureAllDefaults().catch(() => {});
    // Plugins are best-effort: a broken one is reported as a warning and the
    // launcher keeps booting.
    await plugins.loadAll().catch((err) => logger.warn('plugins load failed', { message: err.message }));

    const hub = {
      window: null,
      panes: this.panes,
      settings,
      auth,
      modrinth,
      lockfile,
      hauler,
      mods,
      resolver,
      inbox,
      skins,
      themes,
      sounds,
      greetings,
      plugins,
      publisher,
      pingHost,
      queryServer,
      suggestMemoryMb,
      timeline,
      instances,
      java,
      backups,
      shots,
      liveNick,
      discord,
      playtime,
      health,
      game: null,
      routeToBrowser: (url) => this.routeToBrowser(url),
      drainBrowserUrls: () => this.drainBrowserUrls()
    };

    hub.game = new EmberPilot({
      java,
      settings,
      onEvent: (channel, payload) => {
        if (hub.window && !hub.window.isDestroyed()) {
          hub.window.webContents.send(channel, payload);
        }
        if (channel === 'game:close' || channel === 'game:crash') {
          const mins = playtime.end(payload.instanceId);
          auth.getCurrent().then((u) => {
            if (!u) return;
            const stats = u.stats || {};
            stats.playtime = (stats.playtime || 0) + mins;
            if (mins > (stats.longestSession || 0)) stats.longestSession = mins;
            return auth.patchCurrent({ stats });
          }).catch(() => {});
          timeline.append(payload.instanceId, channel === 'game:crash' ? 'crash' : 'launch',
            channel === 'game:crash' ? `Crash code ${payload.code}` : 'Launch finished').catch(() => {});
          discord.clear().catch(() => {});
          // The launcher hid itself when the game started — bring it back once the
          // session ends, otherwise the window never returns. Either the
          // "restore after game" or the "show on exit" toggle is enough.
          settings.getAll().then((all) => {
            const L = (all && all.launcher) || {};
            if (L.showOnGameExit === false && L.restoreWindowAfterGame === false) return;
            this.revealLauncher();
          }).catch(() => this.revealLauncher());
        }
      }
    });

    this.hub = hub;
    wireAllIpc(hub);

    const win = this.panes.create();
    if (this.allowedWindows) this.allowedWindows.add(win);
    hub.window = win;
    this.panes.onOpenUrl = (url) => this.routeToBrowser(url);
    const { session } = require('electron');
    // Flush any URL that arrived before the renderer was listening.
    win.webContents.on('did-finish-load', () => {
      for (const url of this.drainBrowserUrls()) {
        try { win.webContents.send('browser:open', url); } catch (_) { /* */ }
      }
    });
    const onInboxSaved = (item) => {
      if (hub.window && !hub.window.isDestroyed()) {
        hub.window.webContents.send('inbox:saved', item);
      }
    };
    const onInboxProgress = (p) => {
      if (hub.window && !hub.window.isDestroyed()) {
        hub.window.webContents.send('inbox:progress', p);
        hub.window.webContents.send('game:progress', {
          stage: 'download',
          pct: p.pct || 0,
          loaded: p.loaded,
          total: p.total,
          message: p.filename ? `Скачиваю ${p.filename}` : 'Скачиваю файл'
        });
      }
    };
    inbox.attachSession(session.fromPartition('persist:cryndel'), onInboxSaved, onInboxProgress);
    inbox.attachSession(session.defaultSession, onInboxSaved, onInboxProgress);
    // Any session created later (a webview with its own partition, for example)
    // gets the same download handler so a file from the internet always lands
    // in the launcher's Downloads folder.
    app.on('session-created', (ses) => {
      inbox.attachSession(ses, onInboxSaved, onInboxProgress);
    });
    hauler.onProgress((p) => {
      if (hub.window && !hub.window.isDestroyed()) {
        hub.window.webContents.send('inbox:progress', p);
        hub.window.webContents.send('game:progress', {
          stage: 'download',
          pct: p.pct || 0,
          loaded: p.loaded,
          total: p.total,
          message: p.destPath ? require('path').basename(p.destPath) : 'Загрузка'
        });
      }
    });
    const allSettings = await settings.getAll();
    this.tray.attach(win, () => this.revealLauncher());
    this.attachCloseGuard(win);
    if (!allSettings.launcher || allSettings.launcher.discordRpc !== false) {
      // Honour a user-supplied Discord application id; the bundled default is a
      // placeholder and would never show presence for the real app.
      const appId = (allSettings.advanced && allSettings.advanced.discordAppId) || '';
      await discord.connect(appId || undefined);
    }
    const liveCfg = (allSettings.advanced && allSettings.advanced.liveNick) || { enabled: true, wsPort: 21999 };
    if (liveCfg.enabled !== false) {
      await liveNick.start(liveCfg.wsPort || 21999);
      liveNick.on('status', (s) => {
        if (hub.window && !hub.window.isDestroyed()) {
          hub.window.webContents.send('liveNick:statusChange', s);
        }
      });
    }
    this.updater.setup();
    logger.info('Cryndel kernel ready');
  }

  // Single funnel for "open this URL in the in-app browser". Works even while
  // the renderer is booting: the URL is queued and the renderer drains the
  // queue once it is ready, so the browser opens 100% of the time.
  routeToBrowser(url) {
    if (!/^https?:\/\//i.test(String(url || ''))) return false;
    this.pendingBrowserUrls = this.pendingBrowserUrls || [];
    if (this.pendingBrowserUrls.length > 20) this.pendingBrowserUrls.shift();
    this.pendingBrowserUrls.push(url);
    const win = this.hub && this.hub.window;
    if (win && !win.isDestroyed()) {
      try { win.webContents.send('browser:open', url); } catch (_) { /* */ }
    }
    return true;
  }

  drainBrowserUrls() {
    const list = this.pendingBrowserUrls || [];
    this.pendingBrowserUrls = [];
    return list;
  }

  // Used after the game session ends and from the tray "Open" action. If the
  // window was fully closed (closeOnLaunch) it is recreated here, otherwise the
  // launcher would never come back after Minecraft exits.
  revealLauncher() {
    if (!this.panes) return null;
    let win = this.panes.win;
    if (!win || win.isDestroyed()) {
      win = this.panes.create();
      if (this.allowedWindows) this.allowedWindows.add(win);
      if (this.hub) this.hub.window = win;
      this.panes.onOpenUrl = (url) => this.routeToBrowser(url);
      win.webContents.on('did-finish-load', () => {
        for (const url of this.drainBrowserUrls()) {
          try { win.webContents.send('browser:open', url); } catch (_) { /* */ }
        }
      });
      this.tray.attach(win, () => this.revealLauncher());
      this.attachCloseGuard(win);
      return win;
    }
    const shown = this.panes.show();
    if (this.hub) this.hub.window = shown || win;
    return this.hub ? this.hub.window : win;
  }

  // Keep the window alive while the game runs: closing it drops the launcher off
  // the taskbar instead of killing the process, so it can be revealed again on
  // exit and the game is never interrupted.
  attachCloseGuard(win) {
    win.on('close', (e) => {
      const running = this.hub && this.hub.game && this.hub.game.anyRunning();
      if (running && this.hub && this.hub.window) {
        e.preventDefault();
        try { this.hub.window.setSkipTaskbar(true); } catch (_) { /* linux */ }
        this.hub.window.hide();
      }
    });
  }
}

const kernel = new CryndelKernel();

app.whenReady().then(() => kernel.boot()).catch((err) => {
  logger.error('boot failed', { message: err.message, stack: err.stack });
});

app.on('window-all-closed', () => {
  // Never quit while a game session is live: `closeOnLaunch` closes the window
  // on purpose and the launcher has to come back when Minecraft exits. Quitting
  // here was why the launcher disappeared for good after a launch.
  if (kernel.hub && kernel.hub.game && kernel.hub.game.anyRunning()) return;
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0 && kernel.hub) {
    const w = kernel.panes.create();
    if (kernel.allowedWindows) kernel.allowedWindows.add(w);
    kernel.hub.window = w;
  }
});

module.exports = { kernel };
