import WebSocket from 'ws';
const base = 'http://127.0.0.1:9231';
const targets = await (await fetch(base + '/json/list')).json();
const page = targets.find(t => t.type === 'page');
if (!page) { console.log('no page'); process.exit(0); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
let id = 0; const pending = new Map(); const errs = [];
ws.on('message', (m) => { const msg = JSON.parse(m.toString());
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
  if (msg.method === 'Runtime.exceptionThrown') errs.push((msg.params.exceptionDetails.exception?.description||msg.params.exceptionDetails.text||'').split('\n')[0]);
  if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') errs.push('C:'+msg.params.args.map(a=>a.value??a.description??'').join(' ').split('\n')[0]);
});
await new Promise(r => ws.on('open', r));
const send = (method, params) => new Promise(res => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Runtime.enable');
const ev = async (expr) => { const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.result?.exceptionDetails) return 'EXC:'+(r.result.exceptionDetails.exception?.description||'').split('\n')[0]; return r.result?.result?.value; };
const routes = ['#/','#/modrinth','#/modrinth/settings','#/mods','#/screenshots','#/mycryndel','#/instances','#/settings','#/health','#/about','#/browser','#/build-wizard'];
for (const r of routes) {
  const before = errs.length;
  await ev(`location.hash=${JSON.stringify(r)}; 'ok'`);
  await new Promise(x=>setTimeout(x,700));
  const kids = await ev(`document.getElementById('stage').children.length`);
  console.log(r.padEnd(22), 'nodes='+kids, 'errors='+(errs.length-before), errs.slice(before).join(' | '));
}
process.exit(0);
