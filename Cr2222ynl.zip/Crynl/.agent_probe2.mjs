import WebSocket from 'ws';
const base = 'http://127.0.0.1:9231';
const t = (await (await fetch(base + '/json/list')).json()).find(x => x.type === 'page');
const ws = new WebSocket(t.webSocketDebuggerUrl);
let id = 0; const pending = new Map(); const errs = [];
ws.on('message', (m) => { const msg = JSON.parse(m.toString());
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
  if (msg.method === 'Runtime.exceptionThrown') errs.push((msg.params.exceptionDetails.exception?.description||'').split('\n')[0]);
});
await new Promise(r => ws.on('open', r));
const send = (method, params) => new Promise(res => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Runtime.enable');
const ev = async (expr) => { const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.result?.exceptionDetails) return 'EXC:'+(r.result.exceptionDetails.exception?.description||'').split('\n')[0]; return r.result?.result?.value; };

console.log('1) window buttons hit-test:', await ev(`(()=>{const o={};for(const id of ['winMin','winMax','winFull','winClose']){const e=document.getElementById(id);const r=e.getBoundingClientRect();const el=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);o[id]=(el===e||e.contains(el))?'OK':'BLOCKED';}return JSON.stringify(o);})()`));
console.log('1b) maximize click ->', await ev(`(async()=>{document.getElementById('winMax').click();await new Promise(r=>setTimeout(r,300));return JSON.stringify(await window.cryndel.window.state());})()`));
console.log('1c) fullscreen click ->', await ev(`(async()=>{document.getElementById('winFull').click();await new Promise(r=>setTimeout(r,300));const s=await window.cryndel.window.state();document.getElementById('winFull').click();await new Promise(r=>setTimeout(r,300));return JSON.stringify(s);})()`));
console.log('1d) window.show ->', await ev(`(async()=>JSON.stringify(await window.cryndel.window.show()))()`));

console.log('2) carousel present:', await ev(`!!document.querySelector('.home-carousel')`));
console.log('2b) carousel close click ->', await ev(`(()=>{const b=document.querySelector('.caro-close');if(!b)return 'no-btn';b.click();return !!document.querySelector('.home-carousel');})()`));
console.log('2c) hideCarousel persisted:', await ev(`(async()=>(await window.cryndel.settings.get('ui.hideCarousel')))()`));

console.log('3) J opens inbox:', await ev(`(()=>{window.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyJ',key:'j',bubbles:true}));return !!document.getElementById('inboxPanel');})()`));
console.log('3b) J closes inbox:', await ev(`(()=>{window.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyJ',key:'j',bubbles:true}));return !!document.getElementById('inboxPanel');})()`));

console.log('4) stat card size:', await ev(`(()=>{const s=document.querySelector('.stat');if(!s)return 'none';const r=s.getBoundingClientRect();return 'w='+Math.round(r.width)+' h='+Math.round(r.height)+' fs='+getComputedStyle(s.querySelector('b')).fontSize;})()`));

console.log('5) server pulse text:', await ev(`(()=>{const p=document.querySelector('.server-pulse');return p?p.textContent.trim():'none';})()`));

console.log('6) settings live-apply (accent):', await ev(`(async()=>{await window.cryndel.settings.set('ui.accent','#ff0000');await new Promise(r=>setTimeout(r,400));return getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();})()`));
console.log('6b) reset accent:', await ev(`(async()=>{await window.cryndel.settings.set('ui.accent','');await new Promise(r=>setTimeout(r,300));return 'ok';})()`));
console.log('7) animationDuration live:', await ev(`(async()=>{await window.cryndel.settings.set('ui.animationDuration',900);await new Promise(r=>setTimeout(r,300));return getComputedStyle(document.documentElement).getPropertyValue('--anim-dur').trim();})()`));
console.log('8) errors:', errs.join(' | ')||'(none)');
process.exit(0);
