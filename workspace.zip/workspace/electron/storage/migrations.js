const logger = require('../utils/logger');
const { DEFAULT_SETTINGS, DEFAULT_USERS, DEFAULT_INSTANCES } = require('./schemas');

function migrateUsers(doc) {
  if (!doc || typeof doc !== 'object') return JSON.parse(JSON.stringify(DEFAULT_USERS));
  if (!doc.version) doc.version = 1;
  if (!Array.isArray(doc.users)) doc.users = [];
  if (doc.version < 2) {
    for (const u of doc.users) {
      u.stats = u.stats || { playtime: 0, launches: 0, lastPlayedAt: null, totalSessions: 0, longestSession: 0 };
      u.preferences = u.preferences || { selectedInstanceId: null };
      u.onboardingCompleted = Boolean(u.onboardingCompleted);
    }
    doc.version = 2;
  }
  return doc;
}

function migrateInstances(doc) {
  if (!doc || typeof doc !== 'object') return JSON.parse(JSON.stringify(DEFAULT_INSTANCES));
  if (Array.isArray(doc)) {
    doc = { version: 1, instances: doc };
  }
  if (!Array.isArray(doc.instances)) doc.instances = [];
  if (doc.version < 2) {
    for (const inst of doc.instances) {
      inst.quickPlay = inst.quickPlay || { enabled: false, server: 'cryndel.ru', port: 25565 };
      inst.preLaunchCommands = inst.preLaunchCommands || [];
      inst.postExitCommands = inst.postExitCommands || [];
      inst.group = inst.group || 'Default';
      inst.modLoader = inst.modLoader || inst.loader || 'vanilla';
      inst.memoryMb = inst.memoryMb || 4096;
    }
    doc.version = 2;
  }
  return doc;
}

function migrateSettings(doc) {
  if (!doc || typeof doc !== 'object') return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  const base = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  const merge = (a, b) => {
    if (!b || typeof b !== 'object' || Array.isArray(b)) return a;
    const out = { ...a };
    for (const k of Object.keys(b)) {
      if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a[k] && typeof a[k] === 'object') {
        out[k] = merge(a[k], b[k]);
      } else if (b[k] !== undefined) {
        out[k] = b[k];
      }
    }
    return out;
  };
  const next = merge(base, doc);
  next.version = 3;
  return next;
}

async function runMigrations(vault, files) {
  logger.info('running storage migrations');
  const users = migrateUsers(await vault.read(files.users, DEFAULT_USERS));
  await vault.write(files.users, users);
  const instances = migrateInstances(await vault.read(files.instances, DEFAULT_INSTANCES));
  await vault.write(files.instances, instances);
  const settings = migrateSettings(await vault.read(files.settings, DEFAULT_SETTINGS));
  await vault.write(files.settings, settings);
  return { users, instances, settings };
}

module.exports = { migrateUsers, migrateInstances, migrateSettings, runMigrations };
