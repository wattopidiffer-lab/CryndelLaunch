const { BrowserWindow } = require('electron');
const path = require('path');

class PaneSmith {
  constructor() {
    this.win = null;
  }

  create() {
    this.win = new BrowserWindow({
      width: 1440,
      height: 900,
      minWidth: 900,
      minHeight: 640,
      backgroundColor: '#07080c',
      show: false,
      autoHideMenuBar: true,
      frame: false,
      titleBarStyle: 'hidden',
      title: 'Cryndel Launcher',
      icon: path.join(__dirname, '..', 'assets', 'icon.png'),
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
        webviewTag: true,
        webSecurity: true,
        partition: 'persist:cryndel'
      }
    });
    this.win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
    this.win.once('ready-to-show', () => this.win.show());
    this.win.on('closed', () => { this.win = null; });
    this.win.webContents.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//i.test(url)) {
        this.win.webContents.send('browser:open', url);
      }
      return { action: 'deny' };
    });
    if (process.argv.includes('--dev')) this.win.webContents.openDevTools({ mode: 'detach' });
    return this.win;
  }
}

module.exports = PaneSmith;
