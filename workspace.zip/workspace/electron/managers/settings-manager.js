const vault = require('../storage/json-db');
const CryndelPathVault = require('../utils/paths');
const { DEFAULT_SETTINGS } = require('../storage/schemas');

function dig(obj, key) {
  if (!key) return obj;
  const parts = String(key).split('.');
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function plant(obj, key, value) {
  const parts = String(key).split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const p = parts[i];
    if (!cur[p] || typeof cur[p] !== 'object') cur[p] = {};
    cur = cur[p];
  }
  cur[parts[parts.length - 1]] = value;
  return obj;
}

class DialBoard {
  file() {
    return CryndelPathVault.settingsFile();
  }

  async load() {
    return vault.read(this.file(), DEFAULT_SETTINGS);
  }

  async get(key) {
    const all = await this.load();
    return key ? dig(all, key) : all;
  }

  async getAll() {
    return this.load();
  }

  async set(key, value) {
    return vault.patch(this.file(), (doc) => plant(doc, key, value), DEFAULT_SETTINGS);
  }

  async reset() {
    const fresh = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
    await vault.write(this.file(), fresh);
    return fresh;
  }
}

module.exports = DialBoard;
