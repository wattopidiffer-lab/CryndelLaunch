const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const AdmZip = require('adm-zip');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');

class VaultSnapshot {
  dir(instanceId) {
    return path.join(CryndelPathVault.backupsDir(), instanceId);
  }

  async create(instance, label) {
    const id = `b-${uuidv4().replace(/-/g, '').slice(0, 10)}`;
    const dir = this.dir(instance.id);
    await fs.ensureDir(dir);
    const dest = path.join(dir, `${id}.zip`);
    const zip = new AdmZip();
    const mods = path.join(instance.gameDir, 'mods');
    const lock = CryndelPathVault.lockfile(instance.id);
    if (await fs.pathExists(mods)) zip.addLocalFolder(mods, 'mods');
    if (await fs.pathExists(lock)) zip.addLocalFile(lock, '', 'lock.json');
    const config = path.join(instance.gameDir, 'config');
    if (await fs.pathExists(config)) zip.addLocalFolder(config, 'config');
    zip.writeZip(dest);
    const meta = {
      id,
      instanceId: instance.id,
      label: label || 'snapshot',
      createdAt: new Date().toISOString(),
      file: dest,
      size: (await fs.stat(dest)).size
    };
    const index = path.join(dir, 'index.json');
    const list = (await fs.pathExists(index)) ? await fs.readJson(index) : [];
    list.push(meta);
    await fs.writeJson(index, list, { spaces: 2 });
    logger.info('backup created', { id, instanceId: instance.id });
    return meta;
  }

  async list(instanceId) {
    const index = path.join(this.dir(instanceId), 'index.json');
    if (!(await fs.pathExists(index))) return [];
    return fs.readJson(index);
  }

  async restore(instance, backupId) {
    const list = await this.list(instance.id);
    const item = list.find((b) => b.id === backupId);
    if (!item) throw new Error('Backup not found');
    const zip = new AdmZip(item.file);
    const mods = path.join(instance.gameDir, 'mods');
    await fs.ensureDir(mods);
    zip.extractAllTo(instance.gameDir, true);
    const extractedLock = path.join(instance.gameDir, 'lock.json');
    if (await fs.pathExists(extractedLock)) {
      await fs.move(extractedLock, CryndelPathVault.lockfile(instance.id), { overwrite: true });
    }
    return { ok: true };
  }

  async delete(instanceId, backupId) {
    const index = path.join(this.dir(instanceId), 'index.json');
    const list = (await fs.pathExists(index)) ? await fs.readJson(index) : [];
    const next = list.filter((b) => b.id !== backupId);
    await fs.writeJson(index, next, { spaces: 2 });
    return { ok: true };
  }
}

module.exports = VaultSnapshot;
