const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { dialog, shell } = require('electron');
const vault = require('../storage/json-db');
const CryndelPathVault = require('../utils/paths');
const { DEFAULT_INSTANCES } = require('../storage/schemas');
const { CryndelFault, FaultCodes } = require('../utils/errors');
const logger = require('../utils/logger');

class ForgeCluster {
  constructor({ lockfile, modrinth, resolver, timeline }) {
    this.lockfile = lockfile;
    this.modrinth = modrinth;
    this.resolver = resolver;
    this.timeline = timeline;
    this.builds = null;
  }

  file() {
    return CryndelPathVault.instancesFile();
  }

  async loadDoc() {
    return vault.read(this.file(), DEFAULT_INSTANCES);
  }

  async saveDoc(doc) {
    return vault.write(this.file(), doc);
  }

  async loadBuilds() {
    if (this.builds) return this.builds;
    const p = path.join(__dirname, '..', '..', 'resources', 'builds-catalog.json');
    this.builds = await fs.readJson(p);
    return this.builds;
  }

  async list() {
    const doc = await this.loadDoc();
    return doc.instances || [];
  }

  async get(id) {
    const all = await this.list();
    return all.find((i) => i.id === id) || null;
  }

  makeId() {
    return `i-${uuidv4().replace(/-/g, '').slice(0, 8)}`;
  }

  async create(dto) {
    const doc = await this.loadDoc();
    const id = dto.id || this.makeId();
    const now = new Date().toISOString();
    const gameDir = CryndelPathVault.instanceDir(id);
    await fs.ensureDir(path.join(gameDir, 'mods'));
    await fs.ensureDir(path.join(gameDir, 'resourcepacks'));
    await fs.ensureDir(path.join(gameDir, 'shaderpacks'));
    await fs.ensureDir(path.join(gameDir, 'saves'));
    const instance = {
      id,
      name: dto.name || 'New Instance',
      description: dto.description || '',
      type: dto.type || 'custom',
      sourceBuildId: dto.sourceBuildId || null,
      icon: dto.icon || 'cryndel-default.png',
      group: dto.group || 'Default',
      createdAt: now,
      updatedAt: now,
      lastPlayedAt: null,
      mcVersion: dto.mcVersion || '1.21.11',
      modLoader: dto.modLoader || 'fabric',
      modLoaderVersion: dto.modLoaderVersion || '',
      gameDir,
      assetsReady: false,
      clientJarReady: false,
      javaPath: dto.javaPath || 'auto',
      javaVersion: dto.javaVersion || 21,
      memoryMb: dto.memoryMb || 4096,
      memoryMode: dto.memoryMode || 'auto',
      jvmArgs: dto.jvmArgs || ['-XX:+UseG1GC'],
      jvmPreset: dto.jvmPreset || 'cryndel-recommended',
      resolution: dto.resolution || { width: 1280, height: 720 },
      fullscreen: Boolean(dto.fullscreen),
      extraGameArgs: dto.extraGameArgs || [],
      quickPlay: dto.quickPlay || { enabled: false, server: 'cryndel.ru', port: 25565 },
      preLaunchCommands: dto.preLaunchCommands || [],
      postExitCommands: dto.postExitCommands || [],
      theme: dto.theme || null,
      autoLang: dto.autoLang !== false,
      guiScale: dto.guiScale || (dto.gui3 ? 3 : undefined),
      toggleKeys: dto.toggleKeys !== false,
      addServer: dto.addServer !== false,
      extras: dto.extras || {},
      mods: [],
      resourcePacks: [],
      shaderPacks: []
    };
    doc.instances.push(instance);
    await this.saveDoc(doc);
    await this.lockfile.save({
      version: 1,
      instanceId: id,
      mcVersion: instance.mcVersion,
      loader: instance.modLoader,
      loaderVersion: instance.modLoaderVersion,
      updatedAt: now,
      entries: []
    });
    if (this.timeline) {
      await this.timeline.append(id, 'created', `Created ${instance.name}`);
    }
    return instance;
  }

  async createFromBuild(buildId, name) {
    const catalog = await this.loadBuilds();
    const build = (catalog.builds || []).find((b) => b.id === buildId);
    if (!build) throw new CryndelFault(FaultCodes.INSTANCE, `Unknown build ${buildId}`);
    const instance = await this.create({
      name: name || build.name,
      description: build.description,
      type: 'official',
      sourceBuildId: build.id,
      icon: build.icon,
      group: 'Cryndel',
      mcVersion: build.mcVersion,
      modLoader: build.modLoader,
      modLoaderVersion: build.modLoaderVersion,
      memoryMb: build.memoryMb,
      jvmArgs: build.jvmArgs,
      quickPlay: { enabled: true, server: 'cryndel.ru', port: 25565 }
    });
    const installed = [];
    for (const slug of build.modrinthProjects || []) {
      try {
        if (this.modrinth) {
          const versions = await this.modrinth.getProjectVersions(slug, {
            loader: build.modLoader,
            mcVersion: build.mcVersion
          });
          if (!versions || !versions.length) {
            logger.warn(`No compatible version for ${slug}`);
            continue;
          }
          const res = await this.resolver.resolveAndInstall(instance.id, versions[0].id, new Set(), {
            loader: build.modLoader,
            mcVersion: build.mcVersion
          });
          installed.push(...this.resolver.flatten(res));
        }
      } catch (err) {
        logger.warn('build mod install failed', { slug, message: err.message });
      }
    }
    if (this.timeline) {
      await this.timeline.append(instance.id, 'build', `Installed ${installed.length} mods from ${build.name}`);
    }
    return instance;
  }

  async update(id, patch) {
    const doc = await this.loadDoc();
    const idx = doc.instances.findIndex((i) => i.id === id);
    if (idx < 0) throw new CryndelFault(FaultCodes.INSTANCE, 'Instance not found');
    doc.instances[idx] = {
      ...doc.instances[idx],
      ...patch,
      id,
      updatedAt: new Date().toISOString()
    };
    await this.saveDoc(doc);
    return doc.instances[idx];
  }

  async delete(id) {
    const doc = await this.loadDoc();
    doc.instances = (doc.instances || []).filter((i) => i.id !== id);
    await this.saveDoc(doc);
    return { ok: true };
  }

  async openFolder(id) {
    const inst = await this.get(id);
    if (!inst) throw new CryndelFault(FaultCodes.INSTANCE, 'Instance not found');
    await fs.ensureDir(inst.gameDir);
    return shell.openPath(inst.gameDir);
  }

  async exportMrpack(id, parentWindow) {
    const inst = await this.get(id);
    if (!inst) throw new CryndelFault(FaultCodes.INSTANCE, 'Instance not found');
    const lock = await this.lockfile.load(id, { mcVersion: inst.mcVersion, loader: inst.modLoader });
    const picked = await dialog.showSaveDialog(parentWindow || undefined, {
      defaultPath: `${inst.name.replace(/[^\w.-]+/g, '_')}.mrpack`,
      filters: [{ name: 'Modrinth pack', extensions: ['mrpack'] }]
    });
    if (picked.canceled || !picked.filePath) return { ok: false, cancelled: true };
    await this.lockfile.exportToMrpack(inst, lock, picked.filePath);
    return { ok: true, path: picked.filePath };
  }

  async importPackFile(file, onProgress, meta = {}) {
    const { index, zip, kind } = await this.lockfile.parseMrpack(file);
    const deps = index.dependencies || {};
    const loaderKey = ['fabric', 'neoforge', 'forge', 'quilt'].find((k) => Object.prototype.hasOwnProperty.call(deps, k) && deps[k] !== undefined);
    const needsMeta = Boolean(index.needsMeta) || !(deps.minecraft || index.versionId);
    const name = (meta.name && String(meta.name).trim()) || index.name || path.basename(file, path.extname(file));
    const mcVersion = (meta.mcVersion && String(meta.mcVersion).trim())
      || deps.minecraft
      || index.versionId
      || '';
    const modLoader = (meta.modLoader && String(meta.modLoader).trim()) || loaderKey || 'fabric';
    if (needsMeta && !(meta.mcVersion && String(meta.mcVersion).trim())) {
      return {
        ok: false,
        needsMeta: true,
        kind,
        suggestedName: name,
        suggestedMcVersion: mcVersion || '1.21.11',
        suggestedLoader: modLoader,
        file
      };
    }
    const instance = await this.create({
      name,
      description: index.summary || '',
      type: 'imported',
      mcVersion: mcVersion || '1.21.11',
      modLoader,
      modLoaderVersion: loaderKey ? String(deps[loaderKey] || '') : (meta.modLoaderVersion || ''),
      group: 'Imported'
    });
    if (onProgress) onProgress({ stage: 'pack', pct: 8, message: 'Распаковываю файлы сборки…' });
    await this.lockfile.extractOverrides(zip, instance.gameDir);
    const files = index.files || [];
    let i = 0;
    for (const f of files) {
      i += 1;
      const url = (f.downloads && f.downloads[0]) || null;
      if (!url) continue;
      const filename = path.basename(f.path);
      if (onProgress) {
        onProgress({
          stage: 'pack',
          pct: 10 + Math.round((i / Math.max(1, files.length)) * 80),
          message: `Мод ${i}/${files.length}: ${filename}`
        });
      }
      try {
        const destRel = String(f.path || '').replace(/^\/+/, '');
        if (destRel && !destRel.startsWith('mods/')) {
          const dest = path.join(instance.gameDir, destRel);
          await fs.ensureDir(path.dirname(dest));
          const axios = require('axios');
          const { data } = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 120000,
            headers: { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' }
          });
          await fs.writeFile(dest, Buffer.from(data));
          continue;
        }
        await this.resolver.modManager.downloadAndPlace(
          instance.id,
          url,
          filename,
          filename,
          null,
          f.hashes && f.hashes.sha512,
          { size: f.fileSize, downloadUrl: url }
        );
      } catch (err) {
        logger.warn('mrpack file failed', { filename, message: err.message });
      }
    }
    if (this.timeline) {
      await this.timeline.append(instance.id, 'import', `Imported ${index.name || file} (${kind})`);
    }
    if (onProgress) onProgress({ stage: 'pack', pct: 100, message: 'Сборка готова' });
    return { ok: true, instance, kind };
  }

  async importMrpack(parentWindow, onProgress, meta) {
    const picked = await dialog.showOpenDialog(parentWindow || undefined, {
      properties: ['openFile'],
      filters: [{ name: 'Модпаки', extensions: ['mrpack', 'zip'] }]
    });
    if (picked.canceled || !picked.filePaths[0]) return { ok: false, cancelled: true };
    return this.importPackFile(picked.filePaths[0], onProgress, meta || {});
  }

  async importAsResourcepack(filePath, instanceId) {
    const inst = await this.get(instanceId);
    if (!inst) throw new CryndelFault(FaultCodes.INSTANCE, 'Instance not found');
    const destDir = path.join(inst.gameDir, 'resourcepacks');
    await fs.ensureDir(destDir);
    const dest = path.join(destDir, path.basename(filePath));
    await fs.copy(filePath, dest, { overwrite: true });
    return { ok: true, dest };
  }
}

module.exports = ForgeCluster;
