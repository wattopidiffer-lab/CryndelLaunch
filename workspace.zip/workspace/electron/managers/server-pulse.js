const net = require('net');

function pingHost(host, port, timeoutMs) {
  const timeout = timeoutMs || 3500;
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;
    const finish = (online) => {
      if (done) return;
      done = true;
      try { sock.destroy(); } catch (_) { /* */ }
      resolve({ online, ms: online ? Date.now() - start : null, host, port });
    };
    const sock = net.connect({ host, port: Number(port) || 25565 });
    sock.setTimeout(timeout);
    sock.on('connect', () => finish(true));
    sock.on('timeout', () => finish(false));
    sock.on('error', () => finish(false));
  });
}

module.exports = { pingHost };
