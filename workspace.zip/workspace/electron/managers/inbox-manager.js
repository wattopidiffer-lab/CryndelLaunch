const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const { session } = require('electron');
const CryndelPathVault = require('../utils/paths');
const logger = require('../utils/logger');
const { sanitizeName } = require('./download-manager');

class InboxBay {
  constructor() {
    this.ready = false;
  }

  dir() {
    return CryndelPathVault.downloadsDir();
  }

  async ensure() {
    await fs.ensureDir(this.dir());
    this.ready = true;
    return this.dir();
  }

  classify(name) {
    const n = String(name || '').toLowerCase();
    if (n.endsWith('.mrpack')) return 'modpack';
    if (n.endsWith('.zip')) return 'archive';
    if (n.endsWith('.jar')) return 'mod';
    return 'file';
  }

  async list() {
    await this.ensure();
    const names = await fs.readdir(this.dir());
    const out = [];
    for (const name of names) {
      const full = path.join(this.dir(), name);
      let st;
      try { st = await fs.stat(full); } catch (_) { continue; }
      if (!st.isFile()) continue;
      out.push({
        name,
        path: full,
        size: st.size,
        mtime: st.mtime.toISOString(),
        kind: this.classify(name)
      });
    }
    out.sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
    return out;
  }

  async saveBuffer(filename, buf) {
    await this.ensure();
    const safe = sanitizeName(filename);
    const dest = path.join(this.dir(), safe);
    await fs.writeFile(dest, buf);
    return dest;
  }

  async downloadUrl(url, filename, onProgress) {
    await this.ensure();
    const safe = sanitizeName(filename || path.basename(new URL(url).pathname) || 'download.bin');
    const dest = path.join(this.dir(), safe);
    const res = await axios.get(url, {
      responseType: 'stream',
      timeout: 180000,
      maxRedirects: 8,
      headers: { 'User-Agent': 'CryndelLauncher/1.0.0 (contact@cryndel.ru)' }
    });
    const total = Number(res.headers['content-length'] || 0);
    let loaded = 0;
    await new Promise((resolve, reject) => {
      const out = fs.createWriteStream(dest);
      res.data.on('data', (chunk) => {
        loaded += chunk.length;
        if (onProgress) onProgress({ loaded, total, pct: total ? Math.round((loaded / total) * 100) : 0, filename: safe });
      });
      res.data.on('error', reject);
      out.on('error', reject);
      out.on('finish', resolve);
      res.data.pipe(out);
    });
    logger.info('inbox saved', { dest });
    return dest;
  }

  attachSession(ses, onSaved, onProgress) {
    if (!ses) ses = session.defaultSession;
    if (onProgress) this._onProgress = onProgress;
    ses.on('will-download', (_e, item) => {
      const name = sanitizeName(item.getFilename() || 'download.bin');
      const dest = path.join(this.dir(), name);
      fs.ensureDirSync(this.dir());
      item.setSavePath(dest);
      item.on('updated', (_ev, state) => {
        if (state === 'progressing') {
          const total = item.getTotalBytes() || 0;
          const loaded = item.getReceivedBytes() || 0;
          const payload = { loaded, total, pct: total ? Math.round((loaded / total) * 100) : 0, filename: name };
          if (typeof this._onProgress === 'function') this._onProgress(payload);
        }
      });
      item.once('done', (_ev, state) => {
        if (state === 'completed' && onSaved) onSaved({ name, path: dest, kind: this.classify(name) });
      });
    });
  }

  async importIntoInstance(filePath, instance, mods) {
    const kind = this.classify(filePath);
    if (kind === 'mod') {
      const destDir = path.join(instance.gameDir, 'mods');
      await fs.ensureDir(destDir);
      const name = sanitizeName(path.basename(filePath));
      const dest = path.join(destDir, name);
      await fs.copy(filePath, dest, { overwrite: true });
      const buf = await fs.readFile(dest);
      const sha512 = crypto.createHash('sha512').update(buf).digest('hex');
      if (mods && mods.lockfile) {
        await mods.lockfile.upsertEntry(instance.id, {
          id: path.basename(name, '.jar').toLowerCase(),
          filename: name,
          sha512,
          source: 'inbox',
          enabled: true,
          size: buf.length
        });
      }
      return { ok: true, kind, dest };
    }
    return { ok: false, kind, error: 'use-import-mrpack' };
  }
}

module.exports = InboxBay;
