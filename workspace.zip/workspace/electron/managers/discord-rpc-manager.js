const logger = require('../utils/logger');

class PresenceBeacon {
  constructor() {
    this.client = null;
    this.ready = false;
    this.clientId = process.env.CRYNDEL_DISCORD_APP_ID || '1234567890123456789';
  }

  async connect() {
    try {
      const RPC = require('discord-rpc');
      if (this.client) {
        try { await this.client.destroy(); } catch (_) { /* */ }
        this.client = null;
        this.ready = false;
      }
      this.client = new RPC.Client({ transport: 'ipc' });
      this.client.on('ready', () => {
        this.ready = true;
        logger.info('discord rpc ready');
        this.client.setActivity({
          details: 'Cryndel Launcher',
          state: 'В лаунчере',
          startTimestamp: Date.now(),
          largeImageKey: 'cryndel',
          largeImageText: 'Cryndel Launcher'
        }).catch(() => {});
      });
      await this.client.login({ clientId: this.clientId }).catch((err) => {
        logger.debug('discord rpc login failed', { message: err.message });
      });
    } catch (err) {
      logger.debug('discord rpc skipped', { message: err.message });
    }
  }

  async disconnect() {
    this.ready = false;
    if (!this.client) return;
    try { await this.client.clearActivity(); } catch (_) { /* */ }
    try { await this.client.destroy(); } catch (_) { /* */ }
    this.client = null;
  }

  async setPlaying(instance, _user) {
    if (!this.ready || !this.client) return;
    try {
      await this.client.setActivity({
        details: instance ? instance.name : 'Cryndel',
        state: instance ? `${instance.mcVersion} · ${instance.modLoader}` : 'In launcher',
        startTimestamp: Date.now(),
        largeImageKey: 'cryndel',
        largeImageText: 'Cryndel Launcher',
        buttons: instance && instance.quickPlay && instance.quickPlay.enabled
          ? [{ label: 'Join Cryndel', url: 'https://cryndel.ru' }]
          : undefined
      });
    } catch (_) { /* rpc optional */ }
  }

  async clear() {
    if (!this.ready || !this.client) return;
    try { await this.client.clearActivity(); } catch (_) { /* */ }
  }
}

module.exports = PresenceBeacon;
