const path = require('path');
const os = require('os');

function resolveUserRoot() {
  if (process.env.CRYNDEL_HOME) return process.env.CRYNDEL_HOME;
  try {
    const { app } = require('electron');
    if (app && app.getPath) {
      return path.join(app.getPath('userData'), 'cryndel');
    }
  } catch (_) {
    /* jest / before ready */
  }
  return path.join(os.homedir(), '.cryndel');
}

const CryndelPathVault = {
  userRoot() {
    return resolveUserRoot();
  },
  dataDir() {
    return path.join(resolveUserRoot(), 'data');
  },
  logsDir() {
    return path.join(resolveUserRoot(), 'logs');
  },
  backupsDir() {
    return path.join(resolveUserRoot(), 'backups');
  },
  lockfilesDir() {
    return path.join(this.dataDir(), 'lockfiles');
  },
  instancesRoot() {
    return path.join(resolveUserRoot(), 'instances');
  },
  instanceDir(id) {
    return path.join(this.instancesRoot(), String(id));
  },
  cacheDir() {
    return path.join(resolveUserRoot(), 'cache');
  },
  modCacheDir() {
    return path.join(this.cacheDir(), 'mods');
  },
  versionsDir() {
    return path.join(resolveUserRoot(), 'versions');
  },
  librariesDir() {
    return path.join(resolveUserRoot(), 'libraries');
  },
  assetsDir() {
    return path.join(resolveUserRoot(), 'assets');
  },
  javaDir() {
    return path.join(resolveUserRoot(), 'runtime');
  },
  downloadsDir() {
    return path.join(resolveUserRoot(), 'CL-Downloads');
  },
  usersFile() {
    return path.join(this.dataDir(), 'users.json');
  },
  instancesFile() {
    return path.join(this.dataDir(), 'instances.json');
  },
  settingsFile() {
    return path.join(this.dataDir(), 'settings.json');
  },
  screenshotsIndex() {
    return path.join(this.dataDir(), 'screenshots-index.json');
  },
  favoritesFile() {
    return path.join(this.dataDir(), 'favorites.json');
  },
  timelineFile(id) {
    return path.join(this.dataDir(), 'timeline', `${id}.json`);
  },
  lockfile(id) {
    return path.join(this.lockfilesDir(), `${id}.lock.json`);
  }
};

module.exports = CryndelPathVault;
