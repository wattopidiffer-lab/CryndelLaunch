const { Tray, Menu, nativeImage, app } = require('electron');
const path = require('path');
const fs = require('fs');

class DockNudge {
  constructor() {
    this.tray = null;
  }

  attach(win) {
    const iconPath = path.join(__dirname, '..', 'assets', 'icon.png');
    let image = nativeImage.createEmpty();
    if (fs.existsSync(iconPath)) image = nativeImage.createFromPath(iconPath);
    if (image.isEmpty()) image = nativeImage.createFromDataURL(
      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAHklEQVQ4T2NkYGD4z0ABYBw1gGE0DBjGwDAaBgyDAQAAFvkCAeuS7aQAAAAASUVORK5CYII='
    );
    this.tray = new Tray(image.resize({ width: 16, height: 16 }));
    this.tray.setToolTip('Cryndel Launcher');
    this.tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Open', click: () => { if (win) { win.show(); win.focus(); } } },
      { type: 'separator' },
      { label: 'Quit', click: () => app.quit() }
    ]));
    this.tray.on('click', () => { if (win) { win.show(); win.focus(); } });
    return this.tray;
  }
}

module.exports = DockNudge;
