const { ipcMain } = require('electron');

function bindGameIpc(hub) {
  ipcMain.handle('game:launch', async (_e, instanceId) => {
    const inst = await hub.instances.get(instanceId);
    if (!inst) throw new Error('Instance not found');
    const user = await hub.auth.getCurrent();
    if (!user) throw new Error('No profile');
    hub.playtime.start(instanceId);
    const send = (p) => {
      if (hub.window && !hub.window.isDestroyed()) hub.window.webContents.send('game:progress', { instanceId, ...p });
    };
    send({ stage: 'start', pct: 1, message: 'Старт…' });
    let result;
    try {
      result = await hub.game.launch(inst, user);
    } catch (err) {
      hub.game.preparing = false;
      throw err;
    }
    await hub.instances.update(instanceId, { lastPlayedAt: new Date().toISOString() });
    await hub.auth.bumpLaunch();
    await hub.timeline.append(instanceId, 'launch', 'Launch started');
    const all = await hub.settings.getAll().catch(() => ({}));
    if (all.launcher && all.launcher.discordRpc !== false) {
      try { await hub.discord.setPlaying(inst, user); } catch (_) { /* */ }
    }
    if (hub.window && !hub.window.isDestroyed()) {
      if (all.launcher && all.launcher.closeOnLaunch) {
        hub.window.close();
      } else if (!all.launcher || all.launcher.minimizeToTray !== false) {
        hub.window.hide();
      }
    }
    return result;
  });
  ipcMain.handle('game:kill', async (_e, instanceId) => hub.game.kill(instanceId));
  ipcMain.handle('game:isRunning', async (_e, instanceId) => hub.game.isRunning(instanceId));
  ipcMain.handle('game:anyRunning', async () => hub.game.anyRunning());
  ipcMain.handle('game:cancel', async () => {
    hub.game.cancelJob();
    if (hub.hauler && hub.hauler.cancelAll) hub.hauler.cancelAll();
    return { ok: true };
  });
}

module.exports = bindGameIpc;
