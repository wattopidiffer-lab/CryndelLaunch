const { ipcMain } = require('electron');

function bindSettingsIpc(hub) {
  ipcMain.handle('settings:get', async (_e, key) => hub.settings.get(key));
  ipcMain.handle('settings:set', async (_e, key, v) => {
    await hub.settings.set(key, v);
    return { ok: true };
  });
  ipcMain.handle('settings:getAll', async () => hub.settings.getAll());
  ipcMain.handle('settings:reset', async () => hub.settings.reset());
}

module.exports = bindSettingsIpc;
