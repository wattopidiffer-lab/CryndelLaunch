import { el } from './utils.js';
import { svg } from './icons.js';

export function iconBtn(name, title, onclick, extraClass = '') {
  const b = el('button', { class: 'icon-btn ' + extraClass, type: 'button', onclick });
  b.innerHTML = svg(name);
  b.setAttribute('aria-label', title);
  tip(b, title);
  return b;
}

export function closeBtn(onclick) {
  return iconBtn('x', 'Закрыть', onclick, 'icon-close');
}

export function tip(node, text) {
  node.addEventListener('mouseenter', () => showTip(node, text));
  node.addEventListener('mouseleave', hideTip);
  node.addEventListener('blur', hideTip);
}

let tipEl = null;
let tipTimer = 0;
function showTip(node, text) {
  hideTip();
  tipTimer = setTimeout(() => {
    if (!tipEl) {
      tipEl = el('div', { class: 'ui-tip', id: 'uiTip' });
      document.body.appendChild(tipEl);
    }
    tipEl.textContent = text;
    tipEl.classList.add('on');
    const r = node.getBoundingClientRect();
    const tw = tipEl.offsetWidth;
    let left = r.left + r.width / 2 - tw / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
    let top = r.bottom + 8;
    if (top + 36 > window.innerHeight) top = r.top - 36;
    tipEl.style.left = left + 'px';
    tipEl.style.top = top + 'px';
  }, 80);
}
function hideTip() {
  clearTimeout(tipTimer);
  if (tipEl) tipEl.classList.remove('on');
}

export function chk(label, checked, onChange, hint) {
  const box = el('label', { class: 'chk' + (checked ? ' on' : '') });
  const mark = el('i');
  mark.innerHTML = svg('check');
  const lab = el('span', { text: label });
  box.appendChild(mark);
  box.appendChild(lab);
  if (hint) {
    const h = el('em', { class: 'chk-hint', text: hint });
    box.appendChild(h);
  }
  let on = Boolean(checked);
  box.addEventListener('click', (e) => {
    e.preventDefault();
    on = !on;
    box.classList.toggle('on', on);
    if (onChange) onChange(on);
  });
  box.isOn = () => on;
  box.setOn = (v) => { on = Boolean(v); box.classList.toggle('on', on); };
  return box;
}

export function menu(anchor, items, opts = {}) {
  closeMenus();
  const pop = el('div', { class: 'ui-menu ' + (opts.class || '') });
  for (const it of items) {
    if (it === 'sep') {
      pop.appendChild(el('div', { class: 'ui-menu-sep' }));
      continue;
    }
    const b = el('button', {
      class: 'ui-menu-item' + (it.active ? ' on' : ''),
      type: 'button',
      onclick: () => {
        closeMenus();
        if (it.onclick) it.onclick();
      }
    });
    if (it.icon) b.innerHTML = svg(it.icon) + '<span>' + escapeHtml(it.label) + '</span>';
    else b.textContent = it.label;
    pop.appendChild(b);
  }
  document.body.appendChild(pop);
  place(pop, anchor, opts.place || 'up');
  const off = (e) => {
    if (!pop.contains(e.target) && e.target !== anchor) {
      closeMenus();
      document.removeEventListener('mousedown', off);
    }
  };
  setTimeout(() => document.addEventListener('mousedown', off), 0);
  return pop;
}

export function closeMenus() {
  document.querySelectorAll('.ui-menu').forEach((n) => n.remove());
}

function place(pop, anchor, where) {
  const r = anchor.getBoundingClientRect();
  const w = pop.offsetWidth;
  const h = pop.offsetHeight;
  let left = r.left;
  let top = where === 'down' ? r.bottom + 6 : r.top - h - 6;
  if (top < 8) top = r.bottom + 6;
  if (top + h > window.innerHeight - 8) top = Math.max(8, window.innerHeight - h - 8);
  if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
  pop.style.left = left + 'px';
  pop.style.top = top + 'px';
}

export function modal(opts = {}) {
  const veil = el('div', { class: 'modal-veil' + (opts.full ? ' full' : '') });
  const box = el('div', { class: 'modal ' + (opts.class || '') });
  const head = el('div', { class: 'modal-head' });
  if (opts.kicker) head.appendChild(el('p', { class: 'kicker', text: opts.kicker }));
  const grow = el('div', { class: 'grow' });
  head.appendChild(grow);
  if (opts.extraHead) head.appendChild(opts.extraHead);
  head.appendChild(closeBtn(() => { if (opts.onClose) opts.onClose(); veil.remove(); }));
  if (opts.title) box.appendChild(el('h2', { class: 'h2', text: opts.title }));
  box.insertBefore(head, box.firstChild);
  const body = el('div', { class: 'modal-body' });
  box.appendChild(body);
  veil.appendChild(box);
  veil.addEventListener('click', (e) => {
    if (e.target === veil) {
      if (opts.onClose) opts.onClose();
      veil.remove();
    }
  });
  document.body.appendChild(veil);
  return { veil, box, body, close: () => veil.remove() };
}

export function field(label, input) {
  const w = el('label', { class: 'field-wrap' });
  w.appendChild(el('span', { class: 'field-lab', text: label }));
  w.appendChild(input);
  return w;
}

export function customSelect(options, value, onChange) {
  const wrap = el('div', { class: 'cselect' });
  const btn = el('button', { class: 'cselect-btn', type: 'button' });
  const lab = el('span');
  btn.appendChild(lab);
  const ch = el('i');
  ch.innerHTML = svg('chev');
  btn.appendChild(ch);
  wrap.appendChild(btn);
  function current() {
    return options.find((o) => o.value === wrap.value) || options[0] || { label: '', value: '' };
  }
  wrap.value = value;
  lab.textContent = current().label;
  btn.addEventListener('click', () => {
    menu(btn, options.map((o) => ({
      label: o.label,
      active: o.value === wrap.value,
      onclick: () => {
        wrap.value = o.value;
        lab.textContent = o.label;
        if (onChange) onChange(o.value);
      }
    })), { place: 'down', class: 'cselect-menu' });
  });
  wrap.setValue = (v) => {
    wrap.value = v;
    lab.textContent = current().label;
  };
  return wrap;
}

export function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

export function truncate(s, n = 28) {
  const t = String(s || '');
  return t.length > n ? t.slice(0, n - 1) + '…' : t;
}

export function paintSkinFace(img, dataUrl) {
  if (!dataUrl) return;
  const src = new Image();
  src.onload = () => {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    const sw = src.width;
    const unit = sw / 8;
    g.drawImage(src, unit, unit, unit, unit, 0, 0, 64, 64);
    g.drawImage(src, unit * 5, unit, unit, unit, 0, 0, 64, 64);
    img.src = c.toDataURL();
  };
  src.src = dataUrl;
}

export function drawSkinFront(canvas, dataUrl) {
  if (!dataUrl || !canvas) return;
  const src = new Image();
  src.onload = () => {
    const w = canvas.width;
    const h = canvas.height;
    const g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, w, h);
    const u = src.width / 8;
    const scale = Math.floor(Math.min(w / 16, h / 32));
    const ox = Math.floor((w - 16 * scale) / 2);
    const oy = Math.floor((h - 32 * scale) / 2);
    function blit(sx, sy, sw, sh, dx, dy, dw, dh) {
      g.drawImage(src, sx * u, sy * u, sw * u, sh * u, ox + dx * scale, oy + dy * scale, (dw || sw) * scale, (dh || sh) * scale);
    }
    blit(1, 1, 2, 2, 4, 0);
    blit(5, 1, 2, 2, 4, 0);
    blit(2.5, 2.5, 2, 3, 4, 8);
    blit(5.5, 2.5, 2, 3, 4, 8);
    blit(5.5, 2.5, 1, 3, 2, 8);
    blit(6.5, 2.5, 1, 3, 12, 8);
    blit(0.25, 2.5, 1, 3, 6, 20);
    blit(0.25, 2.5, 1, 3, 9, 20);
  };
  src.src = dataUrl;
}
