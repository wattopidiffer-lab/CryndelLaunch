import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { chk, customSelect, field } from '../ui.js';

const LOADERS = [
  { id: 'vanilla', name: 'Vanilla', hint: 'Чистый Minecraft' },
  { id: 'fabric', name: 'Fabric', hint: 'Моды, Sodium, сервер Cryndel' },
  { id: 'forge', name: 'Forge', hint: 'Классические моды' },
  { id: 'neoforge', name: 'NeoForge', hint: 'Новые моды 1.20+' },
  { id: 'quilt', name: 'Quilt', hint: 'Форк Fabric' }
];

const FABRIC_EXTRAS = [
  { key: 'sodium', slug: 'sodium', label: 'Автоматически скачать Sodium и Fabric API', def: true },
  { key: 'sodiumCfg', slug: null, label: 'Автоматически настроить Sodium', def: true },
  { key: 'fadeless', slug: 'fadeless', label: 'Убрать экран загрузки ресурспака', def: true },
  { key: 'svc', slug: 'simple-voice-chat', label: 'Добавить Simple Voice Chat', def: true },
  { key: 'emote', slug: 'emotecraft', label: 'Добавить Emotecraft', def: true },
  { key: 'minimap', slug: 'xaeros-minimap', label: 'Добавить мини-карту', def: true },
  { key: 'worldmap', slug: 'xaeros-world-map', label: 'Добавить большую карту', def: true },
  { key: 'iris', slug: 'iris', label: 'Добавить Iris', def: true },
  { key: 'litematica', slug: 'litematica', label: 'Добавить Litematica', def: false },
  { key: 'replay', slug: 'replaymod', label: 'Добавить Replay Mod', def: false },
  { key: 'cryem', slug: 'cryem', label: 'Добавить Cryem', def: true, hint: 'Рекомендуем' }
];

export async function mountWizard(root) {
  const st = {
    name: 'Моя сборка',
    mcVersion: '1.21.11',
    loader: 'fabric',
    memoryMb: 4096,
    memoryMode: 'auto',
    quickPlay: true,
    autoLang: true,
    gui3: true,
    toggleKeys: true,
    addServer: true,
    extras: Object.fromEntries(FABRIC_EXTRAS.map((x) => [x.key, x.def]))
  };

  const wrap = el('div', { class: 'wiz' });
  wrap.appendChild(el('p', { class: 'kicker', text: 'НОВАЯ СБОРКА' }));
  wrap.appendChild(el('h2', { class: 'h2', text: 'Новая сборка' }));

  const form = el('div', { class: 'card', style: 'max-width:680px' });
  const name = el('input', { class: 'field', value: st.name });
  name.addEventListener('input', () => { st.name = name.value; });
  form.appendChild(field('Название', name));

  form.appendChild(el('span', { class: 'field-lab', text: 'Версия Minecraft' }));
  const verSel = customSelect([{ value: '1.21.11', label: '1.21.11 (рекомендуется)' }], '1.21.11', (v) => { st.mcVersion = v; });
  form.appendChild(verSel);
  form.appendChild(el('div', { style: 'height:12px' }));

  form.appendChild(el('span', { class: 'field-lab', text: 'Загрузчик' }));
  const loaders = el('div', { class: 'grid-cards', style: 'margin:8px 0 14px' });
  function paintLoaders() {
    loaders.replaceChildren();
    for (const L of LOADERS) {
      const b = el('button', {
        class: 'btn source-opt' + (st.loader === L.id ? ' picked' : ''),
        onclick: () => { st.loader = L.id; paintLoaders(); paintAdv(); }
      });
      b.appendChild(el('strong', { text: L.name, style: 'display:block' }));
      b.appendChild(el('span', { class: 'hint', text: L.hint }));
      loaders.appendChild(b);
    }
  }
  paintLoaders();
  form.appendChild(loaders);

  const advBtn = el('button', { class: 'btn btn-ghost', type: 'button', text: 'Расширенные настройки', style: 'margin:4px 0 8px' });
  const adv = el('div', { class: 'adv-box' });
  let open = false;
  advBtn.addEventListener('click', () => {
    open = !open;
    adv.classList.toggle('open', open);
  });
  form.appendChild(advBtn);
  form.appendChild(adv);

  const extraHost = el('div');
  function paintAdv() {
    adv.replaceChildren();
    adv.appendChild(chk('Автоматически определять язык', st.autoLang, (v) => { st.autoLang = v; }));
    adv.appendChild(chk('Автоматически поставить интерфейс на 3', st.gui3, (v) => { st.gui3 = v; }));
    adv.appendChild(chk('Ctrl и Shift — нажать, а не удерживать', st.toggleKeys, (v) => { st.toggleKeys = v; }));
    adv.appendChild(chk('Автоматически добавить сервер Cryndel.ru', st.addServer, (v) => { st.addServer = v; }));
    adv.appendChild(el('p', { class: 'hint', style: 'margin:10px 0 4px', text: 'Оперативная память — автоматически' }));
    extraHost.replaceChildren();
    if (st.loader === 'fabric') {
      for (const x of FABRIC_EXTRAS) {
        extraHost.appendChild(chk(x.label, st.extras[x.key], (v) => { st.extras[x.key] = v; }, x.hint));
      }
    }
    adv.appendChild(extraHost);
  }
  paintAdv();

  form.appendChild(chk('Сразу зайти на Cryndel.ru', st.quickPlay, (v) => { st.quickPlay = v; }));

  const submit = el('button', { class: 'btn btn-sky', style: 'width:100%;margin-top:8px', text: 'Создать сборку' });
  submit.addEventListener('click', async () => {
    if (!st.name.trim()) { toast('Введи название', 'bad'); return; }
    submit.disabled = true;
    submit.textContent = 'Создаю…';
    try {
      const inst = await api.instances.create({
        name: st.name.trim(),
        mcVersion: st.mcVersion,
        modLoader: st.loader,
        memoryMb: st.memoryMb,
        memoryMode: st.memoryMode,
        group: 'Мои',
        autoLang: st.autoLang,
        guiScale: st.gui3 ? 3 : undefined,
        toggleKeys: st.toggleKeys,
        addServer: st.addServer,
        extras: st.extras,
        quickPlay: st.quickPlay
          ? { enabled: true, server: 'cryndel.ru', port: 25565 }
          : { enabled: false, server: 'cryndel.ru', port: 25565 }
      });
      store.selectedId = inst.id;
      store.instances = await api.instances.list();
      if (window.__cryndelRefresh) await window.__cryndelRefresh();
      toast('Сборка создана');
      await installPicked(inst, st);
      go('#/');
    } catch (e) {
      toast(e.message || 'Не удалось создать', 'bad');
      submit.disabled = false;
      submit.textContent = 'Создать сборку';
    }
  });
  form.appendChild(submit);
  wrap.appendChild(form);
  root.appendChild(wrap);

  api.versions.manifest().then((m) => {
    const releases = (m.versions || []).filter((v) => v.type === 'release').slice(0, 40);
    if (!releases.length) return;
    const opts = releases.map((v) => ({ value: v.id, label: v.id }));
    const prefer = releases.some((v) => v.id === '1.21.11') ? '1.21.11' : releases[0].id;
    st.mcVersion = prefer;
    verSel.setValue(prefer);
    const parent = verSel.parentNode;
    if (!parent) return;
    const fresh = customSelect(opts, prefer, (v) => { st.mcVersion = v; });
    parent.replaceChild(fresh, verSel);
  }).catch(() => {});
}

async function installPicked(inst, st) {
  if (st.loader !== 'fabric') return;
  const slugs = [];
  if (st.extras.sodium) { slugs.push('sodium'); slugs.push('fabric-api'); }
  for (const x of FABRIC_EXTRAS) {
    if (!x.slug || x.slug === 'sodium' || x.slug === 'cryem') continue;
    if (st.extras[x.key]) slugs.push(x.slug);
  }
  for (const slug of slugs) {
    try { await api.modrinth.install(inst.id, slug); } catch (_) { /* optional */ }
  }
  if (st.extras.cryem && inst.mcVersion === '1.21.11' && inst.modLoader === 'fabric') {
    try { await api.mods.installBuiltin(inst.id, 'cryem'); } catch (_) { /* */ }
  }
  if (st.extras.sodiumCfg) {
    try { await api.instances.patchSodium(inst.id); } catch (_) { /* */ }
  }
}
