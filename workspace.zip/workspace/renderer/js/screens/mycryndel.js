import { el } from '../utils.js';
import { store, bus, toast } from '../state.js';
import { api } from '../api.js';
import { modal, field, chk } from '../ui.js';

export async function mountMyCryndel(root) {
  const stage = document.getElementById('stage');
  if (stage) stage.classList.add('padless');
  const s = store.settings || {};
  const cab = s.cabinet || {};
  const zoom = Number(cab.zoom || 80) / 100;

  const wrap = el('div', { style: 'height:100%;display:flex;flex-direction:column;min-height:0' });
  const frame = window.__CRYNDEL_PREVIEW ? document.createElement('iframe') : document.createElement('webview');
  frame.setAttribute('src', 'https://my.cryndel.ru');
  frame.setAttribute('title', 'My Cryndel');
  if (!window.__CRYNDEL_PREVIEW) {
    frame.setAttribute('allowpopups', 'true');
    frame.setAttribute('partition', 'persist:cryndel');
  }
  frame.className = 'webframe';
  frame.style.flex = '1';
  frame.style.border = '0';
  frame.style.transform = 'scale(' + zoom + ')';
  frame.style.width = (100 / zoom) + '%';
  frame.style.height = (100 / zoom) + '%';
  frame.style.transformOrigin = '0 0';
  wrap.appendChild(frame);
  root.appendChild(wrap);

  const off = bus.on('cabinet-settings', () => {
    const m = modal({ kicker: 'КАБИНЕТ', title: 'Настройки страницы' });
    const z = el('input', { class: 'field', type: 'number', min: '50', max: '150', value: String(cab.zoom || 80) });
    m.body.appendChild(field('Размер страницы, %', z));
    z.addEventListener('change', async () => {
      const v = Number(z.value) || 80;
      await api.settings.set('cabinet.zoom', v);
      const zz = v / 100;
      frame.style.transform = 'scale(' + zz + ')';
      frame.style.width = (100 / zz) + '%';
      frame.style.height = (100 / zz) + '%';
      toast('Размер обновлён');
    });
    m.body.appendChild(chk('Страница в фоне (не выгружать)', cab.keepAlive !== false, async (v) => {
      await api.settings.set('cabinet.keepAlive', v);
    }));
  });
  root._offCab = off;
}
