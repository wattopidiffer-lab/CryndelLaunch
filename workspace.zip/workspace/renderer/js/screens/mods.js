import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { iconBtn, modal } from '../ui.js';

export async function mountMods(root) {
  const id = store.selectedId;
  if (!id) {
    const empty = el('div', { class: 'empty' });
    empty.appendChild(el('h3', { text: 'Сборка не выбрана' }));
    empty.appendChild(el('p', { text: 'Выбери пак внизу экрана — тогда здесь появятся моды.' }));
    empty.appendChild(el('button', { class: 'btn btn-sky', text: 'К сборкам', onclick: () => go('#/instances') }));
    root.appendChild(empty);
    return;
  }
  const inst = store.instances.find((i) => i.id === id);
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: 'МОДЫ' }));
  wrap.appendChild(el('h2', { class: 'h2', text: inst ? inst.name : id }));

  const toolbar = el('div', { class: 'row', style: 'margin-bottom:12px' });
  const search = el('input', { class: 'field', placeholder: 'Поиск' });
  const filter = el('select', { class: 'field' });
  filter.appendChild(el('option', { value: 'all', text: 'Все' }));
  filter.appendChild(el('option', { value: 'on', text: 'Включённые' }));
  filter.appendChild(el('option', { value: 'off', text: 'Отключённые' }));
  toolbar.appendChild(search);
  toolbar.appendChild(filter);
  toolbar.appendChild(iconBtn('refresh', 'Обновить', checkUp));
  toolbar.appendChild(iconBtn('export', 'Экспорт', () => api.instances.exportMrpack(id)));
  toolbar.appendChild(iconBtn('file', 'Из файла', async () => {
    const r = await api.mods.addFromFile(id);
    if (r.ok) { toast('Добавлено'); await reload(); }
  }));
  toolbar.appendChild(iconBtn('shield', 'Целостность', async () => {
    const r = await api.mods.verifyIntegrity(id).catch(() => []);
    const bad = (Array.isArray(r) ? r : []).filter((x) => !x.ok);
    toast(bad.length ? `Проблем: ${bad.length}` : 'Хеши в порядке', bad.length ? 'bad' : 'ok');
  }));
  toolbar.appendChild(iconBtn('mr', 'Модринт', () => go('#/modrinth')));
  wrap.appendChild(toolbar);

  const banner = el('div');
  wrap.appendChild(banner);
  const recHost = el('div');
  wrap.appendChild(recHost);
  const list = el('div', { class: 'card' });
  wrap.appendChild(list);
  root.appendChild(wrap);

  api.catalog.recommended().then((rec) => {
    const loader = (inst && inst.modLoader) || 'fabric';
    const items = ((rec.byLoader && rec.byLoader[loader]) || []).concat(rec.common || []).slice(0, 6);
    if (!items.length) return;
    recHost.appendChild(el('p', { class: 'kicker', text: 'СОВЕТУЕМ', style: 'margin:4px 0 8px' }));
    const row = el('div', { class: 'row', style: 'margin-bottom:14px' });
    for (const it of items) {
      row.appendChild(el('button', { class: 'btn btn-ghost', text: it.title, onclick: async () => {
        try {
          await api.modrinth.install(id, it.slug);
          toast('Поставили ' + it.title);
          await reload();
        } catch (e) { toast(e.message || 'Не вышло', 'bad'); }
      } }));
    }
    recHost.appendChild(row);
  }).catch(() => {});

  let mods = [];
  let selected = new Set();

  async function reload() {
    mods = await api.mods.listInstalled(id);
    const conflicts = await api.mods.detectConflicts(id).catch(() => []);
    banner.replaceChildren();
    if (conflicts && conflicts.length) {
      const b = el('div', { class: 'conflict-banner', text: `Найдено конфликтов: ${conflicts.length}` });
      banner.appendChild(b);
    }
    render();
  }

  function render() {
    const q = search.value.toLowerCase();
    const f = filter.value;
    list.replaceChildren();
    if (!mods.length) {
      const empty = el('div', { class: 'empty', style: 'border:0;padding:18px 8px' });
      empty.appendChild(el('h3', { text: 'Модов пока нет' }));
      empty.appendChild(el('p', { text: 'Открой Модринт и поставь Sodium, Fabric API, голосовой чат.' }));
      empty.appendChild(el('button', { class: 'btn btn-sky', text: 'Открыть Модринт', onclick: () => go('#/modrinth') }));
      list.appendChild(empty);
      return;
    }
    const head = el('div', { class: 'row', style: 'margin-bottom:8px' });
    head.appendChild(iconBtn('check', 'Выбрать все', () => {
      selected = new Set(mods.map((m) => m.id));
      render();
    }));
    head.appendChild(iconBtn('on', 'Вкл', () => bulk(true)));
    head.appendChild(iconBtn('off', 'Выкл', () => bulk(false)));
    head.appendChild(iconBtn('trash', 'Удалить', () => bulkDel(), 'btn-danger'));
    list.appendChild(head);
    for (const m of mods) {
      if (q && !(`${m.name} ${m.id} ${m.filename}`).toLowerCase().includes(q)) continue;
      if (f === 'on' && !m.enabled) continue;
      if (f === 'off' && m.enabled) continue;
      const row = el('div', { class: 'mod-row' + (m.enabled ? '' : ' off') });
      const cb = el('input', { type: 'checkbox' });
      cb.checked = selected.has(m.id);
      cb.addEventListener('change', () => {
        if (cb.checked) selected.add(m.id); else selected.delete(m.id);
      });
      const mid = el('div');
      mid.appendChild(el('strong', { text: `${m.name} ${m.versionNumber || ''}` }));
      mid.appendChild(el('div', { class: 'mr-meta', text: `${m.loader || ''} · ${m.source || ''} ${m.enabled ? '' : '(отключён)'}` }));
      const right = el('div', { class: 'row' });
      const tog = el('input', { type: 'checkbox' });
      tog.checked = m.enabled;
      tog.addEventListener('change', async () => {
        await api.mods.toggle(id, m.id, tog.checked);
        await reload();
      });
      right.appendChild(tog);
      right.appendChild(iconBtn('pin', m.pinned ? 'Открепить' : 'Закрепить', async () => {
        await api.mods.pin(id, m.id, !m.pinned);
        await reload();
      }));
      right.appendChild(iconBtn('trash', 'Удалить', async () => {
        await api.mods.remove(id, m.id);
        await reload();
      }, 'btn-danger'));
      row.appendChild(cb);
      row.appendChild(mid);
      row.appendChild(right);
      list.appendChild(row);
    }
  }

  async function bulk(en) {
    for (const mid of selected) await api.mods.toggle(id, mid, en);
    await reload();
  }
  async function bulkDel() {
    if (selected.size > 3) {
      const m = modal({ kicker: 'МОДЫ', title: `Удалить ${selected.size} модов?` });
      const row = el('div', { class: 'row', style: 'margin-top:12px' });
      row.appendChild(el('button', { class: 'btn btn-danger', text: 'Удалить', onclick: async () => {
        m.close();
        for (const mid of selected) await api.mods.remove(id, mid);
        selected.clear();
        await reload();
      } }));
      m.body.appendChild(row);
      return;
    }
    for (const mid of selected) await api.mods.remove(id, mid);
    selected.clear();
    await reload();
  }
  async function checkUp() {
    const ups = await api.mods.checkUpdates(id).catch(() => []);
    if (!ups || !ups.length) { toast('Обновлений нет'); return; }
    const m = modal({ kicker: 'ОБНОВЛЕНИЯ', title: `Обновления: ${ups.length}` });
    for (const u of ups) {
      m.body.appendChild(el('p', { text: `${u.id}: ${u.currentVersion} → ${u.latestVersion}` }));
    }
    m.body.appendChild(el('button', { class: 'btn btn-ember', text: 'Применить все', onclick: async () => {
      await api.mods.applyUpdates(id, ups);
      toast('Обновлено');
      m.close();
      await reload();
    } }));
  }

  search.addEventListener('input', render);
  filter.addEventListener('change', render);
  await reload();
}
