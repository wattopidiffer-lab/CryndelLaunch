import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { iconBtn, modal, drawSkinFront } from '../ui.js';
import { t } from '../i18n.js';

const SLIDES = [
  {
    id: 'start',
    title: 'Как начать играть',
    text: 'Выбери сборку внизу, нажми ИГРАТЬ. Моды — в Модринте, папка и загрузки — иконками справа вверху.',
    art: 'radial-gradient(120% 90% at 90% 10%, #7c9cff 0%, transparent 50%), linear-gradient(160deg, #1a2240, #07080c)'
  },
  {
    id: 'power',
    title: 'Ух, сколько у нас возможностей',
    text: 'Сборки, Модринт, кадры, сеть, кабинет, починка. Виджеты можно двигать, J открывает загрузки.',
    art: 'radial-gradient(100% 80% at 10% 80%, #3ee0a2 0%, transparent 45%), linear-gradient(200deg, #123028, #07080c)'
  },
  {
    id: 'fix',
    title: 'Если что-то сломалось',
    text: 'Вкладка Починка читает краш-логи, ставит Fabric API и отключает подозрительные моды.',
    art: 'radial-gradient(110% 80% at 80% 80%, #ff6b7a 0%, transparent 48%), linear-gradient(200deg, #2a1018, #07080c)'
  }
];

export async function mountHome(root) {
  const selected = store.instances.find((i) => i.id === store.selectedId) || store.instances[0];
  const s = store.settings || {};
  const ui = s.ui || {};

  const plus = iconBtn('plus', 'Загрузить обои', async () => {
    const m = modal({ kicker: 'ОБОИ', title: 'Новый фон' });
    m.body.appendChild(el('p', { class: 'hint', text: 'Подожди чуть-чуть. Фон применится при следующем запуске лаунчера.' }));
    const row = el('div', { class: 'row', style: 'margin-top:12px' });
    row.appendChild(el('button', { class: 'btn btn-sky', text: 'Выбрать файл', onclick: async () => {
      const r = await api.theme.pickBackground();
      if (r && r.ok) {
        toast('Обои сохранены. Применятся при следующем запуске.');
        m.close();
      }
    } }));
    m.body.appendChild(row);
  });
  plus.classList.add('home-plus');
  plus.style.position = 'absolute';
  plus.style.top = '14px';
  plus.style.left = '18px';
  plus.style.zIndex = '7';
  root.appendChild(plus);

  const wrap = el('div', { class: 'hero' });
  const left = el('div', { class: 'hero-card' });
  left.appendChild(el('p', { class: 'kicker', text: t('home.kicker', 'CRYNDEL.RU') }));
  left.appendChild(el('h2', { class: 'home-title', text: selected ? selected.name : 'Cryndel' }));
  if (!selected) {
    left.appendChild(el('p', { class: 'home-sub', text: t('home.empty', 'Создай сборку — дальше одна кнопка.') }));
  }

  const meta = el('div', { class: 'home-meta' });
  if (selected) {
    meta.appendChild(el('span', { text: selected.mcVersion }));
    meta.appendChild(el('span', { text: labelLoader(selected.modLoader) }));
    meta.appendChild(el('span', { text: (selected.memoryMb || 4096) + ' МБ' }));
  }
  const pulse = el('span', { class: 'server-pulse' });
  pulse.appendChild(el('i', { class: 'status-dot' }));
  pulse.appendChild(document.createTextNode(' cryndel.ru…'));
  meta.appendChild(pulse);
  left.appendChild(meta);

  api.server.ping('cryndel.ru', 25565).then((p) => {
    pulse.replaceChildren();
    const d = el('i', { class: 'status-dot' + (p.online ? ' on' : '') });
    pulse.appendChild(d);
    pulse.appendChild(document.createTextNode(' ' + (p.online
      ? t('home.online', 'Онлайн') + ' · ' + p.ms + ' мс'
      : t('home.offline', 'Сервер молчит'))));
    pulse.classList.toggle('on', Boolean(p.online));
  }).catch(() => {
    pulse.replaceChildren();
    pulse.appendChild(el('i', { class: 'status-dot' }));
    pulse.appendChild(document.createTextNode(' ' + t('home.pingfail', 'Пинг недоступен')));
  });

  const stats = el('div', { class: 'stat-grid' });
  const playMin = store.user && store.user.stats ? store.user.stats.playtime || 0 : 0;
  const launches = store.user && store.user.stats ? store.user.stats.launches || 0 : 0;
  stats.appendChild(statBox(store.instances.length, 'Сборок'));
  stats.appendChild(statBox(launches, 'Запусков'));
  stats.appendChild(statBox(fmtMin(playMin), 'В игре'));
  left.appendChild(stats);

  const actions = el('div', { class: 'row home-actions' });
  if (!selected) {
    actions.appendChild(el('button', { class: 'btn btn-sky', text: t('home.create', 'Создать сборку'), onclick: () => go('#/build-wizard') }));
  } else {
    actions.appendChild(el('button', { class: 'btn btn-sky', text: t('home.mods', 'Моды'), onclick: () => go('#/mods') }));
    actions.appendChild(el('button', { class: 'btn', text: t('home.new', 'Новая сборка'), onclick: () => go('#/build-wizard') }));
    actions.appendChild(el('button', { class: 'btn btn-ghost', text: 'Починка', onclick: () => go('#/health') }));
  }
  left.appendChild(actions);
  wrap.appendChild(left);

  const right = el('div');
  if (ui.showSkin3d && store.user && store.user.skin && store.user.skin.path) {
    const canvas = document.createElement('canvas');
    canvas.className = 'skin-3d';
    canvas.width = 180;
    canvas.height = 280;
    right.appendChild(canvas);
    api.skins.preview(store.user.skin.path).then((u) => { if (u) drawSkinFront(canvas, u); }).catch(() => {});
  } else if (ui.hideCarousel !== true) {
    right.appendChild(makeCarousel());
  }
  wrap.appendChild(right);
  root.appendChild(wrap);
}

function statBox(value, label) {
  const n = el('div', { class: 'stat' });
  n.appendChild(el('b', { text: String(value) }));
  n.appendChild(el('span', { text: label }));
  return n;
}

function fmtMin(m) {
  const n = Number(m) || 0;
  if (n < 60) return n + ' м';
  return Math.floor(n / 60) + ' ч';
}

function makeCarousel() {
  const box = el('div', { class: 'home-carousel' });
  let i = 0;
  const slides = SLIDES.map((s) => {
    const n = el('div', { class: 'home-slide' });
    const art = el('div', { class: 'slide-art' });
    art.style.background = s.art;
    n.appendChild(art);
    const copy = el('div', { class: 'slide-copy' });
    copy.appendChild(el('h3', { text: s.title }));
    copy.appendChild(el('p', { class: 'hint', text: s.text }));
    n.appendChild(copy);
    box.appendChild(n);
    return n;
  });
  const nav = el('div', { class: 'caro-nav' });
  const dots = SLIDES.map((_, idx) => {
    const d = el('button', { class: 'caro-dot', type: 'button', onclick: () => show(idx) });
    nav.appendChild(d);
    return d;
  });
  const close = iconBtn('x', 'Закрыть', () => { box.remove(); }, 'caro-close');
  nav.appendChild(close);
  box.appendChild(nav);

  function show(n) {
    i = (n + slides.length) % slides.length;
    slides.forEach((sl, k) => sl.classList.toggle('on', k === i));
    dots.forEach((d, k) => d.classList.toggle('on', k === i));
  }
  show(0);
  const tmr = setInterval(() => show(i + 1), 10000);
  const obs = new MutationObserver(() => {
    if (!document.body.contains(box)) { clearInterval(tmr); obs.disconnect(); }
  });
  obs.observe(document.body, { childList: true, subtree: true });
  return box;
}

function labelLoader(v) {
  const m = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
  return m[(v || '').toLowerCase()] || v || 'Vanilla';
}
