import { api } from '../api.js';
import { store, toast } from '../state.js';
import { el } from '../utils.js';
import { go } from '../router.js';
import { iconBtn, modal, field, chk } from '../ui.js';

export async function mountInstances(root) {
  store.instances = await api.instances.list();
  const wrap = el('div');
  const head = el('div', { class: 'page-head' });
  const titles = el('div');
  titles.appendChild(el('p', { class: 'kicker', text: 'СБОРКИ' }));
  titles.appendChild(el('h2', { class: 'h2', text: 'Твои миры и модпаки' }));
  head.appendChild(titles);
  const tools = el('div', { class: 'row' });
  tools.appendChild(iconBtn('plus', 'Новая сборка', () => go('#/build-wizard')));
  tools.appendChild(iconBtn('folder', 'Импорт', async () => {
    let r = await api.instances.importMrpack();
    if (r && r.needsMeta && window.__cryndelAskImport) {
      const meta = await window.__cryndelAskImport(r);
      if (!meta) return;
      r = await api.inbox.importMrpackPath(r.file, meta);
    }
    if (r && r.ok) { toast('Импорт ок'); await mountInstances(root); }
  }));
  tools.appendChild(el('button', { class: 'btn', text: 'Версии Minecraft', onclick: () => openVersions() }));
  head.appendChild(tools);
  wrap.appendChild(head);

  const catalog = await api.instances.catalog().catch(() => ({ builds: [] }));
  if (catalog && catalog.builds && catalog.builds.length && !store.instances.length) {
    wrap.appendChild(el('p', { class: 'hint', style: 'margin:-8px 0 16px', text: 'Готовые официальные паки Cryndel — одна кнопка.' }));
    const rec = el('div', { class: 'grid-cards', style: 'margin-bottom:22px' });
    for (const b of catalog.builds) {
      const c = el('div', { class: 'card inst-card' });
      c.appendChild(el('span', { class: 'badge gold', text: 'Официально' }));
      c.appendChild(el('strong', { text: b.name }));
      c.appendChild(el('p', { class: 'hint', text: b.description || (b.mcVersion + ' · ' + b.modLoader) }));
      c.appendChild(el('button', { class: 'btn btn-sky', text: 'Создать из пака', onclick: async () => {
        try {
          const inst = await api.instances.createFromBuild(b.id, b.name);
          store.selectedId = inst.id;
          if (window.__cryndelRefresh) await window.__cryndelRefresh();
          toast('Сборка «' + inst.name + '» готова');
          go('#/instance/' + inst.id);
        } catch (e) { toast(e.message || 'Не вышло', 'bad'); }
      } }));
      rec.appendChild(c);
    }
    wrap.appendChild(rec);
  }

  const grid = el('div', { class: 'grid-cards' });
  const groups = {};
  for (const i of store.instances) {
    const g = i.group || 'Default';
    if (!groups[g]) groups[g] = [];
    groups[g].push(i);
  }
  for (const [g, items] of Object.entries(groups)) {
    grid.appendChild(el('div', { class: 'kicker', text: g, style: 'grid-column:1/-1;margin-top:8px' }));
    for (const inst of items) {
      const c = el('div', { class: 'card inst-card' + (inst.id === store.selectedId ? ' selected' : '') });
      const top = el('div', { class: 'top' });
      top.appendChild(el('strong', { text: inst.name }));
      if (inst.id === store.selectedId) top.appendChild(el('span', { class: 'badge ok', text: 'Выбрана' }));
      c.appendChild(top);
      c.appendChild(el('div', { class: 'mr-meta', text: inst.mcVersion + ' · ' + labelLoader(inst.modLoader) + ' · ' + (inst.memoryMb || 4096) + ' МБ' }));
      if (inst.lastPlayedAt) c.appendChild(el('div', { class: 'hint', text: 'Играли: ' + String(inst.lastPlayedAt).replace('T', ' ').slice(0, 16) }));
      const row = el('div', { class: 'row', style: 'margin-top:auto' });
      row.appendChild(iconBtn('play', 'Выбрать и открыть', () => {
        store.selectedId = inst.id;
        api.instances.select(inst.id).catch(() => {});
        go('#/instance/' + inst.id);
      }));
      row.appendChild(iconBtn('edit', 'Изменить', () => editInst(inst, root)));
      row.appendChild(iconBtn('folder', 'Папка', () => api.instances.openFolder(inst.id)));
      row.appendChild(iconBtn('trash', 'Удалить', async () => {
        const m = modal({ kicker: 'СБОРКА', title: 'Удалить «' + inst.name + '»?' });
        m.body.appendChild(el('p', { class: 'hint', text: 'Сборка пропадёт из списка. Файлы на диске лаунчер не трогает без подтверждения в папке.' }));
        m.body.appendChild(el('button', { class: 'btn btn-danger', style: 'margin-top:12px', text: 'Удалить', onclick: async () => {
          m.close();
          await api.instances.delete(inst.id);
          if (store.selectedId === inst.id) store.selectedId = null;
          if (window.__cryndelRefresh) await window.__cryndelRefresh();
          await mountInstances(root);
        } }));
      }, 'btn-danger'));
      c.appendChild(row);
      c.addEventListener('dblclick', async () => {
        store.selectedId = inst.id;
        await api.instances.select(inst.id).catch(() => {});
        go('#/instance/' + inst.id);
      });
      grid.appendChild(c);
    }
  }
  if (!store.instances.length) {
    const empty = el('div', { class: 'empty' });
    empty.appendChild(el('h3', { text: 'Пока пусто' }));
    empty.appendChild(el('p', { text: 'Собери Fabric под Cryndel или импортируй .mrpack.' }));
    empty.appendChild(el('button', { class: 'btn btn-sky', text: 'Создать сборку', onclick: () => go('#/build-wizard') }));
    grid.appendChild(empty);
  }
  wrap.appendChild(grid);
  wrap.appendChild(el('button', { class: 'btn btn-sky fab-create', text: 'Создать сборку', onclick: () => go('#/build-wizard') }));
  root.replaceChildren(wrap);
}

function labelLoader(v) {
  const m = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };
  return m[(v || '').toLowerCase()] || v || 'Vanilla';
}

function editInst(inst, root) {
  const m = modal({ kicker: 'СБОРКА', title: 'Изменить' });
  const name = el('input', { class: 'field', value: inst.name });
  const ver = el('input', { class: 'field', value: inst.mcVersion });
  const loader = el('select', { class: 'field' });
  for (const [id, t] of [['vanilla', 'Vanilla'], ['fabric', 'Fabric'], ['forge', 'Forge'], ['neoforge', 'NeoForge'], ['quilt', 'Quilt']]) {
    loader.appendChild(el('option', { value: id, text: t }));
  }
  loader.value = inst.modLoader || 'fabric';
  const mem = el('input', { class: 'field', type: 'number', min: '2048', step: '256', value: String(inst.memoryMb || 4096) });
  m.body.appendChild(field('Название', name));
  m.body.appendChild(field('Версия', ver));
  m.body.appendChild(field('Загрузчик', loader));
  m.body.appendChild(field('RAM, МБ', mem));
  m.body.appendChild(el('button', { class: 'btn btn-sky', text: 'Сохранить', onclick: async () => {
    await api.instances.update(inst.id, {
      name: name.value.trim(),
      mcVersion: ver.value.trim(),
      modLoader: loader.value,
      memoryMb: Number(mem.value) || inst.memoryMb
    });
    toast('Сохранено');
    m.close();
    if (window.__cryndelRefresh) await window.__cryndelRefresh();
    if (/^\/instance\//.test(store.route || '')) await mountInstance(root, { id: inst.id });
    else await mountInstances(root);
  } }));
}

async function openVersions() {
  const m = modal({ kicker: 'MINECRAFT', title: 'Версии', class: 'mr-page' });
  let manifest = { versions: [] };
  try { manifest = await api.versions.manifest(); } catch (e) {
    m.body.appendChild(el('p', { text: e.message }));
    return;
  }
  const kind = el('select', { class: 'field' });
  kind.appendChild(el('option', { value: 'release', text: 'Release' }));
  kind.appendChild(el('option', { value: 'snapshot', text: 'Snapshot' }));
  const loader = el('select', { class: 'field' });
  for (const v of [['vanilla', 'Vanilla'], ['fabric', 'Fabric'], ['neoforge', 'NeoForge'], ['forge', 'Forge'], ['quilt', 'Quilt']]) {
    loader.appendChild(el('option', { value: v[0], text: v[1] }));
  }
  const row = el('div', { class: 'row', style: 'margin-bottom:10px' });
  row.appendChild(kind); row.appendChild(loader);
  m.body.appendChild(row);
  const list = el('div', { class: 'grid-cards' });
  m.body.appendChild(list);
  function render() {
    list.replaceChildren();
    const items = (manifest.versions || []).filter((v) => v.type === kind.value).slice(0, 40);
    for (const v of items) {
      const c = el('div', { class: 'card' });
      c.appendChild(el('strong', { text: v.id }));
      c.appendChild(el('button', { class: 'btn btn-sky', style: 'margin-top:8px', text: 'Создать', onclick: async () => {
        const inst = await api.instances.create({ name: loader.options[loader.selectedIndex].text + ' ' + v.id, mcVersion: v.id, modLoader: loader.value, group: 'Custom' });
        store.selectedId = inst.id;
        toast('Сборка создана');
        m.close();
        if (window.__cryndelRefresh) await window.__cryndelRefresh();
        go('#/instances');
      } }));
      list.appendChild(c);
    }
  }
  kind.addEventListener('change', render);
  loader.addEventListener('change', render);
  render();
}

export async function mountInstance(root, params) {
  const inst = await api.instances.get(params.id);
  if (!inst) {
    root.appendChild(el('div', { class: 'empty' }));
    root.firstChild.appendChild(el('h3', { text: 'Сборка не найдена' }));
    root.firstChild.appendChild(el('button', { class: 'btn', text: 'К списку', onclick: () => go('#/instances') }));
    return;
  }
  store.selectedId = inst.id;
  try { await api.instances.select(inst.id); } catch (_) { /* */ }
  const wrap = el('div');
  wrap.appendChild(el('p', { class: 'kicker', text: inst.group || 'INSTANCE' }));
  const title = el('div', { class: 'row' });
  title.appendChild(el('h2', { class: 'h2', text: inst.name }));
  title.appendChild(iconBtn('play', 'Играть', async () => {
    try { await api.game.launch(inst.id); toast('Запускаю…'); }
    catch (e) { toast(e.message, 'bad'); }
  }));
  title.appendChild(iconBtn('edit', 'Изменить', () => editInst(inst, root)));
  wrap.appendChild(title);
  wrap.appendChild(el('p', { class: 'hint', style: 'margin:-8px 0 14px', text: inst.mcVersion + ' · ' + labelLoader(inst.modLoader) + ' · ' + (inst.memoryMb || 4096) + ' МБ' }));

  const tabs = el('div', { class: 'tabs' });
  tabs.appendChild(el('button', { class: 'on', text: 'Обзор' }));
  tabs.appendChild(el('button', { text: 'Моды', onclick: () => go('#/mods') }));
  tabs.appendChild(el('button', { text: 'Починка', onclick: () => go('#/health') }));
  wrap.appendChild(tabs);

  const qp = el('div', { class: 'card' });
  qp.appendChild(el('strong', { text: 'Quick Play' }));
  qp.appendChild(el('p', { class: 'hint', text: 'Сразу зайти на сервер при запуске.' }));
  const srv = el('input', { class: 'field', value: (inst.quickPlay && inst.quickPlay.server) || 'cryndel.ru' });
  qp.appendChild(chk('Сразу на сервер', inst.quickPlay && inst.quickPlay.enabled, async (v) => {
    await api.instances.update(inst.id, { quickPlay: { enabled: v, server: srv.value, port: 25565 } });
    toast('Quick Play обновлён');
  }));
  qp.appendChild(field('Адрес', srv));
  srv.addEventListener('change', async () => {
    await api.instances.update(inst.id, { quickPlay: { enabled: inst.quickPlay && inst.quickPlay.enabled, server: srv.value.trim(), port: 25565 } });
  });
  wrap.appendChild(qp);

  wrap.appendChild(el('h3', { text: 'Заметки', style: 'margin:16px 0 8px' }));
  const notes = el('textarea', { class: 'field', style: 'min-height:90px' });
  notes.value = await api.notes.load(inst.id).catch(() => '');
  wrap.appendChild(notes);
  wrap.appendChild(el('button', { class: 'btn', style: 'margin-top:8px', text: 'Сохранить заметку', onclick: async () => {
    await api.notes.save(inst.id, notes.value);
    toast('Заметка сохранена');
  } }));

  try {
    const lock = await api.lockfile.load(inst.id);
    if (lock && lock.entries) {
      wrap.appendChild(el('h3', { text: 'Lockfile', style: 'margin:16px 0 8px' }));
      const box = el('div', { class: 'card' });
      box.appendChild(el('strong', { text: 'lock v' + (lock.version || 1) + ' · ' + (lock.loader || '') + ' ' + (lock.mcVersion || '') }));
      const n = (lock.entries || []).length;
      box.appendChild(el('p', { class: 'hint', text: n ? n + ' записей' : 'Пока пусто — моды появятся после установки.' }));
      wrap.appendChild(box);
    }
  } catch (_) { /* */ }

  root.replaceChildren(wrap);
}
