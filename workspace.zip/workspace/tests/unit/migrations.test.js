const { migrateUsers, migrateInstances, migrateSettings } = require('../../electron/storage/migrations');

describe('migrations', () => {
  test('users v1 to v2', () => {
    const next = migrateUsers({ version: 1, users: [{ nick: 'A' }] });
    expect(next.version).toBe(2);
    expect(next.users[0].stats).toBeTruthy();
  });

  test('instances array to doc', () => {
    const next = migrateInstances([{ id: 'i', name: 'x' }]);
    expect(next.version).toBe(2);
    expect(next.instances[0].quickPlay).toBeTruthy();
  });

  test('settings merge keeps unknown', () => {
    const next = migrateSettings({ ui: { language: 'en' } });
    expect(next.version).toBe(3);
    expect(next.ui.language).toBe('en');
    expect(next.modrinth.enabled).toBe(true);
  });
});
